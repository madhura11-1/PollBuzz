package co.revidly.android;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.SyncStateContract;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.crashlytics.android.Crashlytics;
import com.crashlytics.android.BuildConfig;
import com.danikula.videocache.HttpProxyCacheServer;
import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.LoopingMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;
import com.jaeger.library.StatusBarUtil;
import com.onesignal.OneSignal;
import com.squareup.picasso.Picasso;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerCallback;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerFullScreenListener;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import co.revidly.android.helpers.InternetConnector_Checker;
import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.Utils;
import io.fabric.sdk.android.Fabric;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;
import static java.lang.Math.abs;

import uk.co.deanwild.materialshowcaseview.MaterialShowcaseSequence;
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseView;
import uk.co.deanwild.materialshowcaseview.ShowcaseConfig;

public class HomeFeed extends AppCompatActivity {

    /* Code from Ques and Answer Class Start */
    static int fvi;
    inviteSheet invitesheet;
    public static boolean inqanda=false;
    public static JSONObject[] quanswers;
    private ShimmerFrameLayout mShimmerFrameLayout;
    EditText writeFeed;


    private static final String SHOWCASE_ID_QnA = "Simple Showcase Question and Answer Page";
    /* Code from Ques and Answer Class Ends */

    /* Code from FullscreenActivity Class Starts */
    /*** main is boolean which is used to check if we are in homefeed***/

    public static final String PARAM_TOKEN = "pid";
    public static final String PARAM_TOKEN_ProfileID = "profileId";
    public static final String PARAM_ISCOMMENT = "iscomment";
    public static final String COMMUNITY_TOKEN = "COMMUNITY_FEED";
    public static boolean changed = false, main = true, frmain = false, qaup = false;
    private static final int RECOVERY_REQUEST = 1;

    //YouTubePlayer youTubePlayer;
    String VIDEO_KIND_SELF = "self";
    String VIDEO_KIND_YOUTUBE = "youtube";
    private static final String SHOWCASE_ID = "Simple Showcase";

    /** In this activity, many static variables are defined which are used to pass data between all the activities *****/


    /** Changed is boolean variable checking if the question(or answer) that has to be displayed in homefeed has been changed***/
    /** YouTubePlayerView is the view that handles YouTubePlayer and YouTubePlayer is the player that plays youtube url's***/

    //YouTubePlayerView youTubePlayerView;
    public static String auth_token=null,vurl = "",ques,nqurl,naurl,tqurl;
    public static int qno = 0,ano=0,qu,nextqno,sqno;
    public static String  qa_ques_id,qaquestion,uplquestion,commans_id,tques_id,tans_id,uplque_id,invite_ques_id;
    int sp;
    int nupvotes,ndownvotes,user_vote,ncomments,nshares;
    float x1, x2, y1, y2;

    private VideoView vid,nq,na;
    MediaController controller;

    //Code for ExoPlayer///
    private SimpleExoPlayer mSimpleExoPlayer;

    private SimpleExoPlayerView mSimpleExoPlayerView;

    private Handler mMainHandler;
    private AdaptiveTrackSelection.Factory mAdaptiveTrackSelectionFactory;
    private TrackSelector mTrackSelector;
    private LoadControl mLoadControl;
    private DefaultBandwidthMeter mBandwidthMeter;
    private DataSource.Factory mDataSourceFactory;
    private SimpleCache mSimpleCache;
    private DataSource.Factory mFactory;
    private MediaSource mVideoSource;
    private LoopingMediaSource mLoopingMediaSource;
    private ProgressBar mProgressBar;

    private boolean exoplayer_action_up = false;

    public static AskQuestion fragment;
    public static CommentSheet commentfragment;
    ExecutorService service = Executors.newFixedThreadPool(4);
    BottomNavigationView bottomNavigationView;
    public String username, password;
    public static ArrayList<String> quesbookmarks = new ArrayList<>();
    public static ArrayList<String> ansbookmarks = new ArrayList<>();

    //for temporary profile page purpose
    public static boolean prof = false;
    //ProgressDialog progDialog;
    private ImageView progloader;

    JSONObject[] questions, answers;

    //AddAnswer addAnswer; //addAnswer was already defined in QuesAndAns hence removed from here
    public static boolean infullscreen=false;

    SeekBar seekbar;
    MediaController mediaController;

    public static HttpProxyCacheServer proxyserver, proxyserver1, proxyserver2;
    String pid;
    String followerid;
    Boolean iscomment;
    String communityTopics;

    ImageButton shr;
    TextView upvotes;
    TextView downvotes;
    ImageButton upvt;
    ImageButton dnvt;
    ImageButton cmnt;
    Button answer;

    String url;

    static PostFeed postFeed;
    JSONArray topics;

    //String nextCachedFileUrl;

    //public static boolean FullscreenActivityVisible; // Variable that will check the current activity state
    //public static boolean isOnline; // Variable that will have the current state of internet connectivity

    //public static boolean interentOkbuttonpressed = true;

    private final BroadcastReceiver internetConnector = new InternetConnector_Checker();

    private static HomeFeed mInstance;

    private boolean checkGetAns;

    /* Code from FullscreenActivity Class Ends */

    ItemTouchHelper itemTouchHelper;
    Button invite;
    RecyclerView recyclerViewUserClans;
    ShimmerRecyclerView recyclerView;
    Fragment fragmentUserClans;

    ProgressDialog progressDialog;

    //boolean checkVerUpdateOnce = false;

    //public static String userId = "5dee4ecb6548617591b628ea";

    TextView question;
    ImageView profilePic;

    SwipeRefreshLayout swipeRefreshLayout;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        Log.d("function call QandA", "inside onCreate");
        Log.d("LOG_MSG", "inside onCreate");
        StatusBarUtil.setTransparent(this);


        //Setting view and top bar//
        setContentView(R.layout.qanda);

        Intent intent1 = getIntent();
        Log.d("NewHomeFeed",String.valueOf(intent1.getBooleanExtra("newHomeFeed",false)));
        String action = intent1.getAction();
        String type = intent1.getType();



        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {
                Intent i = new Intent(this,Add_Answer.class); // Handle text being sent
                i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                i.putExtra("EXTRA_TEXT",intent1.getStringExtra(Intent.EXTRA_TEXT));
                Log.d("SHARED_TEXT",""+intent1.getStringExtra(Intent.EXTRA_TEXT));
                startActivity(i);
            } else if (type.startsWith("image/")) {
                Toast.makeText(mInstance, "Image ia also there", Toast.LENGTH_SHORT).show();
                //    handleSendImage(intent); // Handle single image being sent
            }
        } else {
            // Handle other intents, such as being started from the home screen
        }


        // Obtain the FirebaseAnalytics instance.

        Fabric.with(this, new Crashlytics());

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        mFirebaseAnalytics.setCurrentScreen(this, "Home", null /* class override */);
        StatusBarUtil.setColor(this, Color.LTGRAY, 2);
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        ConstraintLayout flo = findViewById(R.id.constraintLayout);
        flo.setPadding(0, result, 0, 0);
        // progressDialog = ProgressDialog.show(HomeFeed.this,
        //       "Loading Awesomeness..",
        //    "Your internet is a bit slow..But don\'t worry we got your back.\n Please Wait...");

        JSONArrayTesting obj = new JSONArrayTesting();
        obj.getHomeFeedList();

        setGlobals();
        setViews();

//        AsyncTask.execute(new Runnable() {
//            @Override
//            public void run(){
//                Log.d("CheckForUpdate()", "running");
//                CheckForUpdate();
//            }
//
//        });


        //initExoPlayer();
        //initYoutubePlayer();
        BottomNavigationBar();
        setOnClickListeners();
        //initItemTouchHelper();

        /* Hard coding question id for temp purpose */
        qa_ques_id = "5def4549137d6f1fea101eec";

        findViewById(R.id.search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeFeed.this,SearchActivity.class));
            }
        });
        //getans(qa_ques_id);
        //getTopics();
        //getPosts();
        //setOnClickListeners();

        //setProperties();

        initOneSignal();

        /* Hard coding question id for temp purpose */
        qa_ques_id = "5def4549137d6f1fea101eec";

        if(auth_token == null) {
            startActivity(new Intent(this, HomeScreen_Activity.class));
            finish();
        }



        //UserClans userClansFragment = new UserClans(HomeFeed.this, auth_token);
        //userClansFragment.show(getSupportFragmentManager(),"UserClans");

        //HomeFeed.(new UserClans(HomeFeed.this, auth_token));

        findViewById(R.id.search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomeFeed.this,SearchActivity.class));
            }
        });

        //AsyncTaskRunner runner = new AsyncTaskRunner();
        //String sleepTime = time.getText().toString();
        //runner.execute();

        //main=false;


        //App ShowCase Tutorial Starts Here

        /* Tutorial Sequence commented out */
        //showTutorSequenceQuesAndAns(500);

        //getUserDetails();


        if(!UserDetails.userDetailsExecuted)
        {
            Log.d("NewHomeFeedif",String.valueOf(intent1.getBooleanExtra("newHomeFeed", false)));
            getUserDetails();
            Intent intent=new Intent(HomeFeed.this,newHomeFeed.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }

        else if(LoggedInUser.userTopics == null)
        {
            Log.d("NewHomeFeed1stelseif",String.valueOf(intent1.getBooleanExtra("newHomeFeed", false)));
            Log.d("HomeFeed  --->", "I am in second if before everything");
            setUserTopics();
            setProfilePic();
        }
        else if(LoggedInUser.userTopics.length() == 0){
            Log.d("NewHomeFeed2ndelseif",String.valueOf(intent1.getBooleanExtra("newHomeFeed", false)));
            Log.d("HomeFeed  --->", "I am in second if before everything");
            setUserTopics();
            setProfilePic();
        }
        else{
            checkNotificationStatus();
            Log.d("NewHomeFeedBool",String.valueOf(intent1.getBooleanExtra("newHomeFeed", false)));
            if(!intent1.getBooleanExtra("newHomeFeed", false)){
                setProfilePic();
                setHomeFeed();
            }else {
                Log.d("HomeFeed  --->", "I am in else before everything");
                hideViews();
//                FragmentManager fm = getSupportFragmentManager();
//                fm.beginTransaction().replace(R.id.user_clans_fragment_manager, new newHomeFeed()).commit();
                Intent intent=new Intent(HomeFeed.this,newHomeFeed.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
//            setProfilePic();
//            setHomeFeed();
            }
        }
        if(intent1.hasExtra("NotifClicked")){
            Log.d("LOG_MSG","Inside Notif");
            String uniqueId = intent1.getStringExtra("NotifClicked");
            markAsRead(uniqueId);
        }
        if(pid!=null)
        {
            Log.d("HomeFeed calling call()","pid = " + pid);
            call(pid,iscomment);
            //Toast.makeText(this, "Answer ID : "+aid, Toast.LENGTH_SHORT).show();
        }
        else if(followerid!=null)
        {
            Log.d("HomeFeedcallto profile","followerid = " + followerid);
            Intent intent = new Intent(this, ProfilePage.class);
            intent.putExtra("USER_ID", followerid);
            startActivity(intent);
        }

    }
    public void getUserDetails()
    {
        Log.d("HomeFeed  --->", "I am in first if before everything");
        UserDetails userDetails = new UserDetails(this, Utils.getAuthToken(this), true);
        Log.d("HomeFeed  --->", "I am in first if after constructor call");
        userDetails.getUserDetails();
        Log.d("HomeFeed  --->", "I am in first if after getUserDetails profile = " + LoggedInUser.userProfileImage);
            /*
            setProfilePic();
            if(LoggedInUser.userTopics.length() == 0)
                setUserTopics();
            else
                setHomeFeed();

             */
        Log.d("HomeFeed  --->", "I am in first if after everything pic = " + LoggedInUser.userProfileImage);
    }

    public void setUserTopics()
    {
        new Handler().post(new Runnable() {
            public void run() {
                // Begin the transaction
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                // Replace the contents of the container with the new fragment
                ft.replace(R.id.user_clans_fragment_manager, UserClans.newInstance1(auth_token));
                // or ft.add(R.id.your_placeholder, new FooFragment());
                // Complete the changes added above
                ft.commit();
            }
        });
        hideViews();
    }

    public void setHomeFeed() {
        unHideViews();
        Log.d("setHomeFeed", "Before UserClans is called");
        //new UserClans(HomeFeed.this, auth_token, true);
        new Handler().post(new Runnable() {
            public void run() {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                // Replace the contents of the container with the new fragment
                ft.replace(R.id.homefeed_user_clan, UserClans.newInstance2(auth_token, true),"homefeed_user_clan");
                // or ft.add(R.id.your_placeholder, new FooFragment());
                // Complete the changes added above
                ft.commit();
            }
        });


        Log.d("setHomeFeed", "After UserClans is called");
        if(PostFeed.timer!=null)    PostFeed.timer.cancel();
        postFeed = new PostFeed(HomeFeed.this, auth_token, null);
        postFeed.setRecyclerView();
        //String topicsString = "[{\"name\":\"politics\",\"description\":\"Indian Politics\",\"priorityRank\":1,\"popularityRank\":1,\"status\":\"1\",\"_id\":\"5e2ca5e11c85d118de420121\",\"createdBy\":\"5e0f352212817d409d9a596f\"}]";
        String topicsString = LoggedInUser.userTopics.toString();
        postFeed.setTopics(topicsString);
        Log.d("setHomeFeed Topics --> ", "User Topics -----> " + topicsString);
        //getPosts("[{\"name\":\"politics\",\"description\":\"Indian Politics\",\"priorityRank\":1,\"popularityRank\":1,\"status\":\"1\",\"_id\":\"5e2ca5e11c85d118de420121\",\"createdBy\":\"5e0f352212817d409d9a596f\"}]");
        postFeed.getPosts();
        postFeed.setViews();
    }
    private void hideViews() {
        Log.d("HomeFeed", "hideView() I am running");
        writeFeed.setVisibility(View.GONE);
        findViewById(R.id.search).setVisibility(View.GONE);
        //question.setVisibility(View.GONE);
        profilePic.setVisibility(View.GONE);
        bottomNavigationView.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        //fragmentUserClans.setVisibility(View.GONE);
    }
    private void unHideViews()
    {
        writeFeed.setVisibility(View.VISIBLE);
        findViewById(R.id.search).setVisibility(View.VISIBLE);
        //question.setVisibility(View.VISIBLE);
        profilePic.setVisibility(View.VISIBLE);
        bottomNavigationView.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.VISIBLE);
        //fragmentUserClans.setVisibility(View.VISIBLE);
    }

    private void initOneSignal() {
        // OneSignal Initialization
        OneSignal.startInit(this)
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .init();
    }
    private void setGlobals() {
        auth_token = null;
        auth_token = Utils.getAuthToken(this);
        if(auth_token == null) {
            startActivity(new Intent(this, HomeScreen_Activity.class));
            finish();
        }
        pid = null;
        pid = getIntent().getStringExtra(PARAM_TOKEN);
        followerid = null;
        followerid= getIntent().getStringExtra(PARAM_TOKEN_ProfileID);
        iscomment=getIntent().getBooleanExtra(PARAM_ISCOMMENT,Boolean.FALSE);
        mInstance = this;

        View decorView = getWindow().getDecorView();
        // Hide both the navigation bar and the status bar.
        // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
        // a general rule, you should design your app to hide the status bar whenever you
        // hide the navigation bar.
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);

        setSwipeRefresh();

    }
    private void setSwipeRefresh()
    {
        // init SwipeRefreshLayout and TextView
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.simpleSwipeRefreshLayout);
        // implement setOnRefreshListener event on SwipeRefreshLayout
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                if(recyclerView.getVisibility() == View.VISIBLE)
                {
                    // implement Handler to wait for 3 seconds and then update UI means update value of TextView
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // cancel the Visual indication of a refresh
                            swipeRefreshLayout.setRefreshing(false);
                            // Generate a random integer number
                            setHomeFeed();

                        }
                    }, 1000);
                }
                else
                {
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }

    private void setViews()
    {
        try {
            mShimmerFrameLayout = findViewById(R.id.shimmer_qanda);
            mShimmerFrameLayout.setVisibility(View.GONE);
            //mShimmerFrameLayout.startShimmer();
            bottomNavigationView = findViewById(R.id.bottom_navigation);
            question = findViewById(R.id.textView7);
            findViewById(R.id.nullanswers).setVisibility(View.INVISIBLE);
            //if (communityTopics == null)
            question.setText("Home Feed");
            /*
            else {

                JSONArray topicsArray = new JSONArray(communityTopics);
                String topics="";
                for (int i = 0; i <= topicsArray.length() - 1; i++) {
                    JSONObject topicsItem = topicsArray.getJSONObject(i);
                    if (i == 0)
                        topics = topics + topicsItem.optString("name");
                    else
                        topics = topics + ", " + topicsItem.optString("name");
                }
                question.setText(topics);
            }
            */
            writeFeed = findViewById(R.id.writeFeed);
            //recyclerView = findViewById(R.id.recvw);
            answer = findViewById(R.id.qandaanswerbtn);
            invite = findViewById(R.id.qandainvite);
            profilePic = findViewById(R.id.propic);
            recyclerView = findViewById(R.id.recvw);
            //fragmentUserClans = findViewById(R.id.homefeed_user_clan);
        }catch(Exception e)
        {
            e.printStackTrace();
            Crashlytics.logException(e);
        }

    }
    private void setOnClickListeners()
    {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "on Click Listener");

        writeFeed.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                // show interest in events resulting from ACTION_DOWN
                if (event.getAction() == MotionEvent.ACTION_DOWN)
                    return true;

                // don't handle event unless its ACTION_UP so "doSomething()" only runs once.
                if (event.getAction() != MotionEvent.ACTION_UP)
                    return false;

                Log.d("HomeFeed -->", "writeFeed Touched");

                startActivity(new Intent(getApplicationContext(),Add_Answer.class));
                return true;
            }
        });


        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uplque_id=qa_ques_id;
                uplquestion=qaquestion;
                inqanda=true;
                //addAnswer= new AddAnswer();
                //addAnswer.show(getSupportFragmentManager(),"Answer");

                mShimmerFrameLayout.stopShimmer();
                mShimmerFrameLayout.setVisibility(View.GONE);
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"answer");
                mFirebaseAnalytics.logEvent("Answer",bundle);

            }
        });
        invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                invite_ques_id = qa_ques_id;
                invitesheet = new inviteSheet();
                invitesheet.show(getSupportFragmentManager(), "Invite");

                mShimmerFrameLayout.stopShimmer();
                mShimmerFrameLayout.setVisibility(View.GONE);

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"invite");
                mFirebaseAnalytics.logEvent("invite",bundle);
            }
        });

        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeFeed.this, ProfilePage.class);
                intent.putExtra("USER_ID", LoggedInUser.userId);
                startActivityForResult(intent, 0);
            }
        });
    }


    static  PostFeed getPostFeedClass()
    {
        return postFeed;
    }


//    private void CheckForUpdate() {
//        /* Executing class to check app update */
//        if(!LoggedInUser.checkVerUpdateOnce){
//            String latestVersion = "";
//            String currentVersion = getCurrentVersion();
//            Log.d("Home Feed -->", "inside CheckForUpdate Current version = " + currentVersion);
//            try {
//
//                /* Get version Code */
//                String newVersion = null;
//
//                try {
//                    Log.d("HomeFeed -->", "I am inside CheckForUpdate before response");
//                    String response = Jsoup.connect("https://api.revidly.co/api/app/current-version")
//                            .timeout(3000)
//                            .ignoreContentType(true)
//                            .get()
//                            .body()
//                            .text();
//                    if (response != null) {
//                        Log.d("HomeFeed -->", "I am inside CheckForUpdate inside if statement");
//                        Log.d("prashant", "Got response: "+response);
//                        JSONObject jsonObject = new JSONObject(response);
//                        newVersion = jsonObject.getString("version");
//                        Log.d("prashant", "newVersion: "+ newVersion);
//
//                    }
//                    Log.d("HomeFeed -->", "I am inside CheckForUpdate after if statement");
//                }
//                catch (org.json.JSONException e){
//                    e.printStackTrace();
//                    Crashlytics.logException(e);
//                }
//                catch (IOException e) {
//                    e.printStackTrace();
//                    Crashlytics.logException(e);
//                }
//                latestVersion = newVersion;
//                LoggedInUser.checkVerUpdateOnce = true;
//                //////////////////////
//
//                Log.d("prashant -->", "I am inside CheckfForUpdate before GetVersionCode");
//                //latestVersion = new GetVersionCode().execute().get();
//                Log.d("prashant", "Latest version = " + latestVersion);
//            }
//            catch (Exception e) {
//                e.printStackTrace();
//                Crashlytics.logException(e);
//            }
//            //catch (ExecutionException e) {
//            //  e.printStackTrace();
//            //}
//
//            //If the versions are not the same & app is available on PlayStore
//            if (!currentVersion.equals(latestVersion) && latestVersion != null) {
//                HomeFeed.this.runOnUiThread(new Runnable() {
//                    public void run() {
//                        final AlertDialog.Builder builder = new AlertDialog.Builder(HomeFeed.this);
//                        builder.setTitle("A new version of the app is available with added features");
//                        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                //Click button action
//                                logout();
//                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(("https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "&hl=en"))));
//                                dialog.dismiss();
//                                Bundle bundle = new Bundle();
//                                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"update");
//                                mFirebaseAnalytics.logEvent("UpdateClicked",bundle);
//                            }
//                        });
//
//                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                //Cancel button action
//                                Bundle bundle = new Bundle();
//                                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"updateCancelled");
//                                mFirebaseAnalytics.logEvent("UpdateCancelled",bundle);
//                            }
//                        });
//
//                        builder.setCancelable(false);
//                        builder.show();
//                    }
//                });
//            }
//        }
//        /* Code to check app version and show dialogue box ends*/
//    }
//    private String getCurrentVersion(){
//        PackageManager pm = this.getPackageManager();
//        PackageInfo pInfo = null;
//
//        try {
//            pInfo =  pm.getPackageInfo(this.getPackageName(),0);
//
//        } catch (PackageManager.NameNotFoundException e1) {
//            e1.printStackTrace();
//            Crashlytics.logException(e1);
//        }
//        String currentVersion = pInfo.versionName;
//
//        return currentVersion;
//    }
    private void BottomNavigationBar() {
        bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                View view = findViewById(R.id.constraintLayout);
                switch (item.getItemId()) {
                    case R.id.action_new_home:
                        bottomNavigationView.getMenu().findItem(R.id.action_new_home).setChecked(true);
                        Intent intent = new Intent(HomeFeed.this, newHomeFeed.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        break;
                    case R.id.action_home:
                        //finish();
                        break;
                    /*case R.id.action_discover:
                        finish();
                        Intent discover = new Intent(view.getContext(), searchView.class);
                        startActivityForResult(discover, 0);
                        break;

                     */
                    /*
                    case R.id.action_video:
                        //bottomNavigationView.getMenu().findItem(R.id.action_video).setEnabled(true);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        Intent videoScreen = new Intent(view.getContext(), FullscreenActivity.class);
                        startActivityForResult(videoScreen, 0);
                        break;

                     */
                    /*
                    case R.id.action_answer:
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(false);
                        finish();
                        Intent myIntent = new Intent(view.getContext(), quesandansreq.class);
                        startActivityForResult(myIntent, 0);
                        break;
                     */
                    case R.id.action_post:
                        //bottomNavigationView.getMenu().findItem(R.id.action_post).setEnabled(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        //fragment.show(getSupportFragmentManager(), "TAG");
                        startActivity(new Intent(getApplicationContext(),Add_Answer.class));
                        bottomNavigationView.getMenu().findItem(R.id.action_post).setCheckable(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setCheckable(true);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
                        //addAnswer= new AddAnswer();
                        //addAnswer.show(getSupportFragmentManager(),"Answer");
                        break;
                    /*
                    case R.id.action_ask_ques:
                        qaup = true;
                        finish();
                        //fragment.show(getSupportFragmentManager(), "TAG");
                        break;
                     */
                    case R.id.action_notif:
                        startActivityForResult(new Intent(getApplicationContext(), NotificationActivity.class),0);
                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "notificationActivity");
                        mFirebaseAnalytics.logEvent("notificationIntent", bundle);
                        break;
                    case R.id.action_profile:
                        //bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        Intent intent1 = new Intent(view.getContext(), ProfilePage.class);
                        intent1.putExtra("USER_ID", LoggedInUser.userId);
                        startActivityForResult(intent1, 0);

                        break;

                }
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("function call: ", "onResume");

        /* Registering Broadcast receiver */
        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        this.registerReceiver(internetConnector, intentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(internetConnector);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if(profilePic.getVisibility()==View.GONE) {
            outState.putBoolean("updateClans", true);
        }
        else
            outState.putBoolean("updateClans",LoggedInUser.updateClans);
    }
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if(savedInstanceState.getBoolean("updateClans")) {
            findViewById(R.id.nopost).setVisibility(View.GONE);
            LoggedInUser.updateClans = false;
            setUserTopics();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        BottomNavigationBar();
        if(LoggedInUser.updateClans) {
            findViewById(R.id.nopost).setVisibility(View.GONE);
            LoggedInUser.updateClans = false;
            setUserTopics();
        }

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        //Toast.makeText(this, "onDestroy "+aid, Toast.LENGTH_LONG).show();
        Log.d("function call: ", "onDestroy");
        clearApplicationData();
        //youTubePlayerView.release();
    }
    public void clearApplicationData() {
        Log.d("function call ", "clearApplicationData");
        File cache = getCacheDir();
        //File appDir = new File(cache.getParent());
        File appDir = new File(cache.getPath());
        if (appDir.exists()) {
            String[] children = appDir.list();
            for (String s : children) {
                if (!s.equals("lib")) {
                    deleteDir(new File(appDir, s));
                    Log.i("EEERRRRRRROOOOOOOR", "**************** File /data/data/APP_PACKAGE/" + s + " DELETED *******************");
                }
            }
        }
    }
    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }

        return dir.delete();
    }

    /* Tutorial Sequence commented out */
    /*
    private void showTutorSequenceQuesAndAns(int millis) {

        Log.d("showtutor", "In showTutorSequence function");
        ShowcaseConfig config = new ShowcaseConfig(); //create the showcase config
        config.setDelay(millis); //set the delay of each sequence using millis variable

        MaterialShowcaseSequence sequence = new MaterialShowcaseSequence(this, SHOWCASE_ID_QnA); // create the material showcase sequence

        sequence.setConfig(config); //set the showcase config to the sequence.

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.textView7))
                        .setTitleText("Question asked by user")
                        .setDismissText("Click Here : Next")
                        //.setDismissOnTargetTouch(false)
                        //.setContentText("Click on Next")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withRectangleShape(true)
                        .build()
        );

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.nullanswers))
                        .setTitleText("\nList of video answers")
                        .setDismissText("Click Here : Next")
                        //.setContentText("This video is uploaded by another user in response to the Question")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape(true)
                        //.withoutShape()
                        .setShapePadding(-300)
                        .build()
        ); // add view for the second sequence, in this case it is a textview.
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.qandaanswerbtn))
                        .setTitleText("Upload your Video Opinion from here")
                        .setDismissText("Click Here : Next")
                        //.setDismissOnTargetTouch(false)
                        .setContentText("")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape()
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.qandainvite))
                        .setTitleText("Want to ask others for an answer?")
                        .setDismissText("Click Here : End Tutorial")
                        //.setDismissOnTargetTouch(false)
                        .setContentText("Ask from here")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape(true)
                        .build()
        );

        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.propic))
                        .setTitleText("Profile Picture")
                        .setDismissText("Click Here : Next")
                        //.setContentText("The DP of the person who has uploaded the Video")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        ); // add view for the third sequence, in this case it is a checkbox.
         */
        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.upvote))
                        .setTitleText("UpVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Like the video? UpVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.downvote))
                        .setTitleText("DownVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Did not like the video? DownVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.comment))
                        .setTitleText("Comment on the Video")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Provide your views by commenting on the video")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.share))
                        .setTitleText("Share this video with your Friends")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Share this video with your friends.")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_home))
                        .setTitleText("Home Feed")
                        .setDismissText("Click Here : Next")
                        .setContentText("See videos uploaded by users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_discover))
                        .setTitleText("Search for Questions")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Search for questions asked by other users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_answer))
                        .setTitleText("Questions Tabs")
                        .setDismissText("Click Here : Next")
                        .setContentText("More Questions for you to browse")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_ask_ques))
                        .setTitleText("Want to ask a Question?")
                        .setDismissText("Click Here : Next")
                        .setContentText("Ask it from here")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Scroll Down")
                        .setDismissText("Click Here : Next")
                        .setContentText("Scroll down for more videos on questions")
                        //.withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Swipe Right for list of videos")
                        .setDismissText("Click Here : End Tutorial & Swipe Right")
                        //.setContentText("Swipe right for list of videos for the same question")
                        //.withCircleShape()
                        //.setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );
        */
        /*
        sequence.start(); //start the sequence showcase
        Log.d("showtutor", "at end of ShowTutor Function");
    }
    */

    /* Remove comments to show Tutorial */

    void call(String post_id,Boolean iscomment){
        Log.d("HomeFeed Call ", "Inside Call before finish");
        //changed=true;
        //ques=qaquestion;
        //qno=sqno;
        //ano=ans_no;
        //nextQue();
        //Utils.moveToFullscreenActivity(this,post_id);

        getSharedPost(post_id,iscomment);

        //finish();
        Log.d("Inside QuesAndAns ", "Inside Call after finish");
    }

    void getSharedPost(String post_id, final Boolean iscomment)
    {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(BASE_URL+"/api/post/getPostById/" + post_id)
                .get()
                .addHeader("Authorization", auth_token)
                .addHeader("Host", BASE_HOST)
                .addHeader("Connection", "keep-alive")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    throw new IOException("Unexpected code " + response);
                } else {
                    final String resp = response.body().string();
                    //mlist.clear();
                    try {
                        JSONObject resultObject = new JSONObject(resp);
                        Log.d("HomeFeed", "GetPostById respose = " +resultObject.toString());
                        JSONObject postObject = resultObject.getJSONObject("post");
                        JSONObject postAction = resultObject.getJSONObject("postAction");

                        Intent i=new Intent(HomeFeed.this,DescribedPostsActivity.class);
                        i.putExtra("jason_pos",postObject.toString());
                        i.putExtra("post_action",postAction.toString());
                        i.putExtra("iscomment",iscomment);
                        // i.putExtra("length","0");
                        //i.putExtra("post",);
                        startActivity(i);
                        response.body().close();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", resp);
//                    Log.i("Response message:", response.message());
                }
            }
        });

    }
    /*
    void propicClick(int ans_no) throws JSONException {
        Toast.makeText(HomeFeed.this,"Profile of "+quanswers[ans_no].getString("ans_auth_id"),Toast.LENGTH_SHORT).show();
    }
    void followClick(int ans_no) throws JSONException {
        Toast.makeText(HomeFeed.this,"Followed "+quanswers[ans_no].getString("ans_auth_id"),Toast.LENGTH_SHORT).show();
    }
    void upvoteClick(int ans_no){
        Toast.makeText(HomeFeed.this,"Upvoted",Toast.LENGTH_SHORT).show();
    }

     */


    /* On Touch Events to goto FullscreenActivity */
    /*
    public boolean onTouchEvent(MotionEvent touchEvent) {
        switch (touchEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2 = touchEvent.getX();
                y2 = touchEvent.getY();
                if (x1>x2 && abs(x1-x2)>200 && (abs(x1 - x2) > abs(y1 - y2))){
                    finish();
                }

                break;
        }
        return false;
    }
    */
    @Override
    public void finish() {
        super.finish();
        //youTubePlayerView.release();
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
    }
    public static synchronized HomeFeed getInstance() {
        return mInstance;
    }
    public void displayInternetDialogue(){
        try {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();

            alertDialog.setTitle("No Conncetion");
            alertDialog.setMessage("Internet not available, Cross check your internet connection and try again");
            alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Log.d("FullScreenActivity", "I am finishing");
                    finish();
                    //new FullscreenActivity().isOnline();
                }
            });

            alertDialog.show();
        } catch (Exception e) {
            Log.d(SyncStateContract.Constants._ID, "Show Dialog: " + e.getMessage());
            Crashlytics.logException(e);
        }
    }
    public void setProfilePic(){
        Glide.with(getApplicationContext())
                .load(BASE_URL + "/app/profilePic/" +  LoggedInUser.userId + ".jpg")
                .placeholder(R.drawable.propic1)
                .into(profilePic);
        profilePic.setPadding(0, 0, 0, 0);
    }
//    private void logout(){
//        Utils.removeLoginAuthToken(getApplicationContext());
//        Bundle bundle = new Bundle();
//        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"logout");
//        mFirebaseAnalytics.logEvent("logoutClicked",bundle);
//        startActivity(new Intent(getApplicationContext(), HomeScreen_Activity.class));
//        Log.d("HomeActivity", "logout Called");
//        AccessToken fbAccessToken = AccessToken.getCurrentAccessToken();
//        if(fbAccessToken != null){
//            Log.d("LOG_DATA", "Logged out");
//            LoginManager.getInstance().logOut();
//        }
//    }

    private void markAsRead(String notifId) {
        String url = BASE_URL + "/api/pushnotif/markReadByUniqueId/" + notifId;
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        Request request = new Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Authorization", Utils.getAuthToken(this))
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("LOG_MSG", e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                try {
                    String resp = response.body().string();
                    Log.d("LOG_MSG", "Marked: " + resp);
                } catch (Exception e) {
                    Log.e("LOG_MSF", e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }
    private void checkNotificationStatus() {
        String url = BASE_URL + "/api/pushnotif/unreadStatus";
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Authorization", LoggedInUser.auth_token_global)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("LOG_MSG", e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull okhttp3.Response response) throws IOException {
                try {
                    JSONObject data = new JSONObject();
                    String resp = response.body().string();
                    JSONObject resultObject = new JSONObject(resp);
                    Log.d("LOG_MSG", "Result: " + resultObject);
                    Log.d("LOG_MSGS", "Unread: " + resultObject.optBoolean("unread_notification_exist"));
                    final Boolean isUnRead = resultObject.optBoolean("unread_notification_exist");
                    Handler mainHandler;
                    mainHandler = new Handler(getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if (isUnRead) {
                                    bottomNavigationView.getMenu().getItem(3).setIcon(R.drawable.notification_blank_dot);
                                } else {
                                    bottomNavigationView.getMenu().getItem(3).setIcon(R.drawable.ic_notifications);
                                }
                            } catch (Exception e) {
                                Log.e("LOG_DATA", e.getMessage());
                                e.printStackTrace();
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("LOG_MSG", e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }

}

