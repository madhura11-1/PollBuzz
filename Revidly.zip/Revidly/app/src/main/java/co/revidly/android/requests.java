package co.revidly.android;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.crashlytics.android.Crashlytics;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static co.revidly.android.FullscreenActivity.auth_token;
import static co.revidly.android.helpers.Config.BASE_URL;
import static co.revidly.android.helpers.Config.BASE_HOST;
public class requests extends Fragment {

    static RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private queslistforyouadapter mAdapter;
    private Context context;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //recyclerView= ((QuesAndAns) context)
        return inflater.inflate(R.layout.for_you, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((TextView)view.findViewById(R.id.textView2)).setText("ANSWER REQUESTS");
        recyclerView = view.findViewById(R.id.qfurv);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        final List<JSONObject> mlist = new ArrayList<>();
        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "/api/app/quesinvited";
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("Authorization", auth_token)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "016e2113-f4c8-418d-8ee1-70ecf99586cf,23520088-e657-45ce-8f1e-77daab8e993e")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp = response.body().string();
                    try {
                        //JSONObject result=new JSONObject(response);
                        JSONArray result = new JSONArray(resp);
                        for (int i = 0; i < result.length(); i++) {
                            final JSONObject obj = new JSONObject(result.get(i).toString());
                            Handler mainHandler;
                            //ans[0] =get_no_of_answers(obj.getString("_id"));
                            final int noans;
                            noans =obj.getJSONArray("answered").length();
                            try {
                                mainHandler = new Handler(getContext().getMainLooper());
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        mlist.add(obj);
                                        if (!FullscreenActivity.main)
                                            mAdapter.notifyDataSetChanged();
                                        System.out.println(mlist);
                                    }
                                });
                            }catch (NullPointerException e){Log.i("Null exception",e.getStackTrace().toString());
                                Crashlytics.logException(e);
                            }
                            System.out.println("Question id is : " + obj.getString("_id"));
                            //System.out.println("topic is : " + obj.getString("topic"));
                            System.out.println("Question is : " + obj.getString("title"));
                            System.out.println("description is : " + obj.getString("description"));
                            //System.out.println("url is : " + obj.getString("url"));
                            System.out.println("date is : " + obj.getString("date"));
                        }
                        response.body().close();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", resp);
//                    Log.i("Response message:", response.message());
                    //mAdapter1.notifyDataSetChanged();

                }
            }
        });
        mAdapter = new queslistforyouadapter(getActivity(), mlist);
        recyclerView.setAdapter(mAdapter);
    }
    /*
    static RecyclerView recyclerView1;
    private RecyclerView.LayoutManager layoutManager1;
    private queslistsearchadapter mAdapter1;
    private Context context;
    Context mContext;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.requests, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView1 = (RecyclerView)view.findViewById(R.id.requests);
        layoutManager1 = new LinearLayoutManager(getActivity());
        recyclerView1.setLayoutManager(layoutManager1);
        List<questions> mlist = new ArrayList<>();
        mAdapter1 = new queslistsearchadapter(getActivity(), mlist);
        recyclerView1.setAdapter(mAdapter1);

    }*/
}
