package co.revidly.android;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class RulesArrayAdapter extends ArrayAdapter {

    Context context;
    int resource;
    ArrayList<String> topics, rules;
    public RulesArrayAdapter(@NonNull Context context, int resource, ArrayList<String> topics, @NonNull ArrayList<String> rules) {
        super(context, resource, rules);
        this.context = context;
        this.resource = resource;
        this.rules = rules;
        this.topics = topics;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        convertView = layoutInflater.inflate(resource,null);
        TextView topicName,ruleName;
        topicName = convertView.findViewById(R.id.topicName);
        ruleName = convertView.findViewById(R.id.ruleName);
        topicName.setText(topics.get(position));
        ruleName.setText(rules.get(position));
        return convertView;
    }
}
