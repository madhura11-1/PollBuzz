package co.revidly.android;



import android.content.Context;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;


import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.crashlytics.android.Crashlytics;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static co.revidly.android.helpers.Config.API_MEDIA_URL;
import static co.revidly.android.helpers.Config.BASE_URL;
import static co.revidly.android.helpers.Config.VIDEO_THUMB;

public class MediaAdapter extends RecyclerView.Adapter<MediaAdapter.SingleItemRowHolder> {
    FirebaseAnalytics mFirebaseAnalytics;
    Context mContext;
    //List<JSONObject> mData;
    JSONArray mData;
    String communityName,postaction;

    public MediaAdapter(Context context, JSONArray mData) {
        this.mData = mData;
        this.mContext = context;
        this.postaction=postaction;
        communityName="";
        Log.d("MediaAdapter->", "Constructor called");
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(mContext);
    }

    @Override
    public SingleItemRowHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.media_item, null);
        SingleItemRowHolder mh = new SingleItemRowHolder(v);
        Log.d("MediaAdapter->", "onCreateViewHolder called");
        return mh;
    }

    @Override
    public void onBindViewHolder(final SingleItemRowHolder holder, int position) {

        //SingleItemModel singleItem = itemsList.get(i);

        //holder.tvTitle.setText(singleItem.getName());

       /* Glide.with(mContext)
                .load(feedItem.getImageURL())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .centerCrop()
                .error(R.drawable.bg)
                .into(feedListRowHolder.thumbView);*/
        Log.d("MediaAdapter->", "onBindViewHolder called");
        String mediaUrl="", urlKind="";

        try {
            mediaUrl = mData.getJSONObject(position).optString("loc");
            urlKind = mData.getJSONObject(position).optString("kind");
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
        //holder.mediaItemImage.getLayoutParams().height = new Random().nextInt((250-75)+75)+75;
        if(urlKind.equals("self_video") || urlKind.equals("youtube")){
            holder.greyView.setVisibility(View.VISIBLE);
            try {
                //holder.mediaItemImage.setImageResource(R.drawable.video_thumbnail);
                //https://blog.axelradclinic.com/wp-content/uploads/2015/06/video-thumbnail.jpg
//                Picasso.get().load(""+API_MEDIA_URL+VIDEO_THUMB).into(holder.mediaItemImage);
                RequestOptions requestOptions=new RequestOptions()
//                  .centerInside()
                        .centerCrop()
                        .fitCenter()
                        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                        .format(DecodeFormat.PREFER_RGB_565)
                        .dontAnimate();
//                  .skipMemoryCache(true);
                Glide.with(mContext)
                        .load(""+API_MEDIA_URL+VIDEO_THUMB)
                        .apply(requestOptions)
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                holder.greyView.setVisibility(View.GONE);
                                return false;
                            }
                        })
                        .into(holder.mediaItemImage);
            }
            catch(Exception e)
            {
                e.printStackTrace();
                Crashlytics.logException(e);
            }
        }
        else if(urlKind.equals("image"))
        try {
            holder.greyView.setVisibility(View.VISIBLE);

//            Picasso.get()
//                    .load(mediaUrl)
//                    .into(holder.mediaItemImage);
            RequestOptions requestOptions=new RequestOptions()
//                  .centerInside()
                    .centerCrop()
                    .fitCenter()
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .format(DecodeFormat.PREFER_RGB_565)
                    .dontAnimate();
//                  .skipMemoryCache(true);
            Glide.with(mContext)
                    .load(mediaUrl)
                    .apply(requestOptions)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            holder.greyView.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .into(holder.mediaItemImage);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
        Log.d("MediaAdapter->", "onBindViewHolder called loc-->" + mediaUrl);
    }

    @Override
    public int getItemCount() {
        return mData.length();
    }

    public class SingleItemRowHolder extends RecyclerView.ViewHolder {

        //protected TextView tvTitle;

        protected ImageView mediaItemImage, play;
        View greyView;
        /*
        protected VideoView mediaItemVideoView;
        protected YouTubePlayerView mediaYouTubePlayerView;
        protected YouTubePlayer mediaYouTubePlayer;
        */

        public SingleItemRowHolder(View view) {
            super(view);

            //this.tvTitle = (TextView) view.findViewById(R.id.tvTitle);
            this.mediaItemImage = (ImageView) view.findViewById(R.id.media_item_image);
            this.greyView=view.findViewById(R.id.greyView);
            /*this.mediaItemVideoView = view.findViewById(R.id.media_vdv);
            this.mediaYouTubePlayerView = view.findViewById(R.id.media_youtube_player);
            this.play = (ImageView) view.findViewById(R.id.media_play);

            mediaYouTubePlayerView.setEnableAutomaticInitialization(true);

             */

            /*
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    Bundle bundle = new Bundle();
                    bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"mediaAdapterView");
                    mFirebaseAnalytics.logEvent("mediaAdapterViewClicked",bundle);

                    //Toast.makeText(v.getContext(), "I am clicked", Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(mContext,DescribedPostsActivity.class);
//                    i.putExtra("length","2");
//                    i.putExtra("media_url",mData.toString());
                    i.putExtra("jason_pos",communityName);
                    i.putExtra("post_action",postaction);
                    mContext.startActivity(i);
                }
            });

             */


        }

    }

}