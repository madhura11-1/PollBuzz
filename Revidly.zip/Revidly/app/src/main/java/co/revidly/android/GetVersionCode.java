package co.revidly.android;

import android.os.AsyncTask;
import android.util.Log;

import com.crashlytics.android.Crashlytics;

import co.revidly.android.BuildConfig;

import org.json.JSONObject;
import org.jsoup.Jsoup;
//import org.jsoup.nodes.Document;
//import org.jsoup.nodes.Element;
//import org.jsoup.select.Elements;

import java.io.IOException;

class GetVersionCode extends AsyncTask<Void, String, String> {

    @Override
    protected String doInBackground(Void... voids) {

        String newVersion = null;

        try {
            Log.d("GetVersionCode -->", "I am inside doInBackground before response");
            String response = Jsoup.connect("https://api.revidly.co/api/app/current-version")
                    .timeout(3000)
                    .ignoreContentType(true)
                    .get()
                    .body()
                    .text();
            if (response != null) {
                Log.d("GetVersionCode -->", "I am inside doInBackground inside if statement");
                Log.d("prashant", "Got response: "+response);
                JSONObject jsonObject = new JSONObject(response);
                newVersion = jsonObject.getString("version");
                Log.d("prashant", "newVersion: "+newVersion);

            }
            Log.d("GetVersionCode -->", "I am inside doInBackground after if statement");
        }
        catch (org.json.JSONException e){
            e.printStackTrace();
            Crashlytics.logException(e);
        }
        catch (IOException e) {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
        return newVersion;

    }


    @Override
    protected void onPostExecute(String onlineVersion) {

        super.onPostExecute(onlineVersion);

        int currentVersion = BuildConfig.VERSION_CODE;
        Log.d("prashant", "got version: "+onlineVersion);

        try {
            if (onlineVersion != null && !onlineVersion.isEmpty()) {

                if (Float.valueOf(currentVersion) < Float.valueOf(onlineVersion)) {
                    //show anything
                }

            }
        }
        catch(Exception ex){
            Log.d("prashant", "Exception in checking version code."+onlineVersion);
            Crashlytics.logException(ex);
        }

        Log.d("update", "Current version " + currentVersion + " playstore version " + onlineVersion);

    }

}