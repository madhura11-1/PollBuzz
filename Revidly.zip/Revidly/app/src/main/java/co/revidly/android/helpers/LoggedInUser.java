package co.revidly.android.helpers;

import org.json.JSONArray;

public class LoggedInUser {

    static public String userName;
    static public String userProfileImage;
    static public String userId;
    static public JSONArray userTopics;
    static public JSONArray topicAdmin;
    static public String auth_token_global;
    static public int followers;
    static public int following;
    static public int totalUpvotes;
    static public boolean checkVerUpdateOnce = false;
    static public boolean updateClans = false;
    static public boolean isTopicAdmin = false;
}

