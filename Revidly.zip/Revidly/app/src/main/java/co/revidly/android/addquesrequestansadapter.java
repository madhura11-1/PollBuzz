package co.revidly.android;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.FullscreenActivity.auth_token;
import static co.revidly.android.FullscreenActivity.invite_ques_id;
import static co.revidly.android.helpers.Config.BASE_URL;


public class addquesrequestansadapter extends RecyclerView.Adapter<addquesrequestansadapter.MyViewHolder> implements Filterable {
    Context mContext;
    List<JSONObject> mData;
    List<JSONObject> mDataFull;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView username_credentials,answers_in;
        ImageButton adduser;
        ImageView dp;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            username_credentials=itemView.findViewById(R.id.username_credentials);
            dp=itemView.findViewById(R.id.propic);
            adduser=itemView.findViewById(R.id.imageButton3);
            answers_in=itemView.findViewById(R.id.textView6);


        }
    }


    public addquesrequestansadapter(Context mContext, List<JSONObject> mData) {
        this.mContext = mContext;
        this.mData = mData;
        mDataFull = new ArrayList<>(mData);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View vw = inflater.inflate(R.layout.addques_request_item,parent,false);
        return new MyViewHolder(vw);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        Picasso.get().load(R.drawable.propic1).placeholder(R.drawable.propic1).into(holder.dp);
        holder.username_credentials.setText(mData.get(position).optString("name"));
        holder.answers_in.setText("x Answers in X Field");
        holder.adduser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                invite(invite_ques_id,mData.get(position).optString("_id"));
                mDataFull.remove(mData.get(position));
                Toast.makeText(mContext.getApplicationContext(),"Requested "+mData.get(position).optString("name"),Toast.LENGTH_SHORT).show();
                removeItem(holder.getAdapterPosition());
            }
        });
    }


    @Override
    public int getItemCount() {
        return mData.size();
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    private void removeItem(int position){
        mData.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,mData.size());
    }
    void invite(String ques_id,String user_id){
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "user_id="+user_id+"&ques_id="+ques_id);
        Request request = new Request.Builder()
                .url(BASE_URL+"/api/app/inviteuser")
                .post(body)
                .addHeader("Authorization", auth_token)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("cache-control", "no-cache")
                .addHeader("Postman-Token", "085da102-f3b1-430b-9967-76485ec012a8")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ", response.toString());

                    throw new IOException("Unexpected code " + response);
                } else {
                    Log.i("Response Success ", response.toString());
                    response.body().close();
                }

            }
        });
    }

    @Override
    public Filter getFilter() {
        return myFilter;
    }

    private Filter myFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            final List<JSONObject> filteredList = new ArrayList<>();

            if(constraint==null || constraint.length() == 0){
                filteredList.addAll(mDataFull);
            }else{
                String filterPattern = constraint.toString().toLowerCase().trim();

                for(JSONObject item : mDataFull){
                    if(item.optString("name").toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }
                }

            }
            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            mData.clear();
            mData.addAll((List)results.values);
            notifyDataSetChanged();
        }
    };
}
