package co.revidly.android;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.media.Image;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.provider.SyncStateContract;
import android.text.Layout;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.crashlytics.android.Crashlytics;
import com.danikula.videocache.HttpProxyCacheServer;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.LoopingMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.upstream.cache.SimpleCache;
import com.google.android.exoplayer2.util.Util;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.jaeger.library.StatusBarUtil;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerCallback;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerFullScreenListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import co.revidly.android.helpers.InternetConnector_Checker;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.Utils;
import io.fabric.sdk.android.Fabric;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.API_MEDIA_URL;
import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;
import static java.lang.Math.abs;

import uk.co.deanwild.materialshowcaseview.MaterialShowcaseSequence;
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseView;
import uk.co.deanwild.materialshowcaseview.ShowcaseConfig;

public class FullscreenActivity extends AppCompatActivity {

    /*** main is boolean which is used to check if we are in homefeed***/

    public static final String PARAM_TOKEN = "aid";

    public static boolean changed = false, main = true, frmain = false, qaup = false;
    private static final int RECOVERY_REQUEST = 1;

    YouTubePlayer youTubePlayer;
    String VIDEO_KIND_SELF = "self";
    String VIDEO_KIND_YOUTUBE = "youtube";
    private static final String SHOWCASE_ID = "Simple Showcase";

    /** In this activity, many static variables are defined which are used to pass data between all the activities *****/


    /** Changed is boolean variable checking if the question(or answer) that has to be displayed in homefeed has been changed***/
    /** YouTubePlayerView is the view that handles YouTubePlayer and YouTubePlayer is the player that plays youtube url's***/

    YouTubePlayerView youTubePlayerView;
    public static String auth_token=null,vurl = "",ques,nqurl,naurl,tqurl;
    public static int qno = 0,ano=0,qu,nextqno,sqno;
    public static String  qa_ques_id,qaquestion,uplquestion,commans_id,tques_id,tans_id,uplque_id,invite_ques_id;
    int sp;
    int nupvotes,ndownvotes,user_vote,ncomments,nshares;
    float x1, x2, y1, y2;

    private VideoView vid,nq,na;
    MediaController controller;

    //Code for ExoPlayer///
    private SimpleExoPlayer mSimpleExoPlayer;

    private SimpleExoPlayerView mSimpleExoPlayerView;

    private Handler mMainHandler;
    private AdaptiveTrackSelection.Factory mAdaptiveTrackSelectionFactory;
    private TrackSelector mTrackSelector;
    private LoadControl mLoadControl;
    private DefaultBandwidthMeter mBandwidthMeter;
    private DataSource.Factory mDataSourceFactory;
    private SimpleCache mSimpleCache;
    private DataSource.Factory mFactory;
    private MediaSource mVideoSource;
    private LoopingMediaSource mLoopingMediaSource;
    private ProgressBar mProgressBar;

    private boolean exoplayer_action_up = false;
    private FirebaseAnalytics mFirebaseAnalytics;
    public static AskQuestion fragment;
    public static CommentSheet commentfragment;
    ExecutorService service = Executors.newFixedThreadPool(4);
    BottomNavigationView bottomNavigationView;
    public String username, password;
    public static ArrayList<String> quesbookmarks = new ArrayList<>();
    public static ArrayList<String> ansbookmarks = new ArrayList<>();

    //for temporary profile page purpose
    public static boolean prof = false;
    //ProgressDialog progDialog;
    private ImageView progloader;

    JSONObject[] questions, answers;

    AddAnswer addAnswer;
    public static boolean infullscreen=false;

    SeekBar seekbar;
    MediaController mediaController;

    public static HttpProxyCacheServer proxyserver, proxyserver1, proxyserver2;
    String aid;

    ImageButton shr;
    TextView upvotes;
    TextView downvotes;
    ImageButton upvt;
    ImageButton dnvt;
    ImageButton cmnt;
    Button answer;

    String url;

    //String nextCachedFileUrl;

    //public static boolean FullscreenActivityVisible; // Variable that will check the current activity state
    //public static boolean isOnline; // Variable that will have the current state of internet connectivity

    //public static boolean interentOkbuttonpressed = true;

    //private final BroadcastReceiver internetConnector = new InternetConnector_Checker();

    private static FullscreenActivity mInstance;

    private boolean checkGetAns;

    //private boolean firstTimeQandA;

    protected void onCreate(Bundle savedInstanceState) {
        Log.d("function call ", "onCreate");
        super.onCreate(savedInstanceState);
        Log.d("function call ", "afterSuper Call");
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        //Checking memory//
        Log.d("Memory :", "Heap Size Total Memory=" + Runtime.getRuntime().totalMemory());
        Log.d("Memory :", "Allocated VM Memory=" + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
        Log.d("Memory :", "VM Heap Size=" + Runtime.getRuntime().maxMemory());
        Log.d("Memory :", "Native Allocated Memory=" + Debug.getNativeHeapAllocatedSize());
        //Log.d("Memory :", "Total Memo=" + Runtime.getRuntime().totalMemory());

        StatusBarUtil.setTransparent(this);
        Log.d("function call ", "afterStatusBarUtil");
        setContentView(R.layout.activity_fullscreen);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        /*
        if(main) loadHome();

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        */

        setGlobals();
        SetID();
        //CheckForUpdate();
        initExoPlayer();
        initYoutubePlayer();
        BottomNavigationBar();


        if(auth_token == null) {
            startActivity(new Intent(this, HomeScreen_Activity.class));
            finish();
        }
        else {
            Log.d("function call ","aid = " + aid);
            LoadHomeUI(aid);
            //Toast.makeText(this, "Answer ID : "+aid, Toast.LENGTH_SHORT).show();
        }
       /*
       Log.d("onCreate", "\n \n aid = " + aid);
       if(aid == null) {
           main = false;
           qa_ques_id = tques_id;
           qaquestion = ques;
           Log.d("onCreate", "Going to Ques&Ans");

           try {
               firstTimeQandA = true;
               qanda();
               finish();
           } catch (Exception e)
           {
               e.printStackTrace();
           }

       }

        */

    }
    private void setGlobals()
    {
        //PARAM_TOKEN = "aid";
        /** Changed is boolean variable checking if the question(or answer) that has to be displayed in homefeed has been changed***/
        //changed = false; main = true; frmain = false; qaup = false;
        //RECOVERY_REQUEST = 1;

        VIDEO_KIND_SELF = "self";
        VIDEO_KIND_YOUTUBE = "youtube";

        aid = null;
        aid = getIntent().getStringExtra(PARAM_TOKEN);

        auth_token = null;
        auth_token = Utils.getAuthToken(this);

        /** YouTubePlayerView is the view that handles YouTubePlayer and YouTubePlayer is the player that plays youtube url's***/

        //if(aid!=null) {
        vurl = "";
        qno = 0;
        ano = 0;
        //}

        exoplayer_action_up = false;

        quesbookmarks = new ArrayList<>();
        ansbookmarks = new ArrayList<>();

        //for temporary profile page purpose
        prof = false;

        infullscreen = false;


        mInstance = this;

        checkGetAns = false;

        proxyserver = new HttpProxyCacheServer(this);
        proxyserver1 = new HttpProxyCacheServer(this);
        proxyserver2 = new HttpProxyCacheServer(this);



    }
    private void CheckForUpdate() {
        /* Executing class to check app update */
        if(main) {
            String latestVersion = "";
            String currentVersion = getCurrentVersion();
            Log.d("prashant", "Current version = " + currentVersion);
            try {
                latestVersion = new GetVersionCode().execute().get();
                Log.d("prashant", "Latest version = " + latestVersion);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
                Crashlytics.logException(e);
            }
            catch (ExecutionException e) {
                e.printStackTrace();
                Crashlytics.logException(e);
            }

            //If the versions are not the same & app is available on PlayStore
            if (!currentVersion.equals(latestVersion) && latestVersion != null) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("A new version of the app is available with added features");
                builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Click button action
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(("https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "&hl=en"))));
                        dialog.dismiss();

                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"update");
                        mFirebaseAnalytics.logEvent("updateClicked",bundle);
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Cancel button action

                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"updateCancelled");
                        mFirebaseAnalytics.logEvent("updateCancelled",bundle);
                    }
                });

                builder.setCancelable(false);
                builder.show();
            }
        }
        /* Code to check app version and show dialogue box ends*/
    }

    private void LoadHomeUI(String aid) {
        if(main)
            loadHome(aid);

        nq = findViewById(R.id.bgvdVwnq);
        na = findViewById(R.id.bgvdVwna);
        fragment = new AskQuestion();

        nq.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.d("video", "setOnErrorListener ");
                return true;
            }
        });
        na.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.d("video", "setOnErrorListener ");
                return true;
            }
        });

        /*
        vid = findViewById(R.id.vdVw);

        controller = new MediaController(this,false);
        controller.setPadding(0, 0, 0, 120);
        initVideoViewListeners();
         */

        AddYourAnswer();
        AddComment();
        UpvoteAndDownvoteLogic();
        ShareAnswer();

        //App ShowCase Tutorial Starts Here
        //showTutorSequenceFullScreen(500);

        Log.d("isShown", "" + findViewById(R.id.question).isShown());
    }
    private void initYoutubePlayer()
    {
        youTubePlayerView = findViewById(R.id.youtube_player);
        //youTubePlayerView.initialize(API_KEY, this);
        youTubePlayerView.requestDisallowInterceptTouchEvent(true);
        youTubePlayerView.setEnableAutomaticInitialization(true);
        youTubePlayerView.getPlayerUiController().showVideoTitle(false);
        youTubePlayerView.getPlayerUiController().showMenuButton(false);
        youTubePlayerView.getPlayerUiController().showYouTubeButton(false);
        youTubePlayerView.addFullScreenListener(new YouTubePlayerFullScreenListener() {
            @Override
            public void onYouTubePlayerEnterFullScreen() {
                ConstraintLayout clt=findViewById(R.id.clt);
                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(clt);
                constraintSet.connect(R.id.youtube_player, ConstraintSet.TOP, R.id.clt, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.youtube_player, ConstraintSet.BOTTOM, R.id.clt, ConstraintSet.BOTTOM, 0);
                clt.setPadding(0,200,0,200);
                constraintSet.applyTo(clt);

            }

            @Override
            public void onYouTubePlayerExitFullScreen() {

                ConstraintLayout clt=findViewById(R.id.clt);
                ConstraintSet constraintSet = new ConstraintSet();
                constraintSet.clone(clt);
                constraintSet.connect(R.id.youtube_player, ConstraintSet.TOP, R.id.clt, ConstraintSet.TOP, 0);
                constraintSet.connect(R.id.youtube_player, ConstraintSet.BOTTOM, R.id.clt, ConstraintSet.BOTTOM, 0);
                clt.setPadding(0,0,0,0);
                constraintSet.applyTo(clt);
            }
        });
        youTubePlayerView.getYouTubePlayerWhenReady(new YouTubePlayerCallback() {
            @Override
            public void onYouTubePlayer(@NotNull YouTubePlayer youTubePlayer1) {
                youTubePlayer = youTubePlayer1;
            }
        });
    }
    private void BottomNavigationBar() {
        //bottomNavigationView.getMenu().findItem(R.id.action_video).setChecked(true);
        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(false);
        final View viewprof = findViewById(R.id.rv);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_home:
                        //Toast.makeText(FullscreenActivity.this, "Home", Toast.LENGTH_SHORT).show();
                        ////bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_video).setEnabled(true);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(false);
                        if(aid != null)
                        {
                            Intent homeFeed = new Intent(viewprof.getContext(), HomeFeed.class);
                            Log.d("NewHomeFeed","FullScreen");
                            startActivityForResult(homeFeed, 0);
                        }
                        finish();
                        //viewprof = findViewById(R.id.rv);
                        //Intent homeFeed = new Intent(viewprof.getContext(), HomeFeed.class);
                        //startActivityForResult(homeFeed, 0);
                        break;

                    //case R.id.action_video:
                    //  break;
                    /*
                    case R.id.action_discover:
                        main=false;
                        View viewdi = findViewById(R.id.rv);
                        Intent discover = new Intent(viewdi.getContext(), searchView.class);
                        startActivityForResult(discover, 0);
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        bottomNavigationView.getMenu().findItem(R.id.action_discover).setEnabled(false);
                        break;
                    case R.id.action_answer:
                        main=false;
                        View viewask = findViewById(R.id.rv);
                        Intent answer = new Intent(viewask.getContext(), quesandansreq.class);
                        startActivityForResult(answer, 0);
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(false);
                        break;
                    case R.id.action_ask_ques:
                        fragment.show(getSupportFragmentManager(), "TAG");
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        break;

                     */
                    case R.id.action_post:
                        bottomNavigationView.getMenu().findItem(R.id.action_post).setCheckable(false);
                        addAnswer= new AddAnswer();
                        addAnswer.show(getSupportFragmentManager(),"Answer");
                        break;
                    case R.id.action_profile:
                        main=false;
                        //viewprof = findViewById(R.id.rv);
                        prof=true;
                        finish();
                        Intent profile = new Intent(viewprof.getContext(), ProfilePage.class);
                        startActivity(profile);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(false);
                        break;
                }
                return true;
            }
        });
    }

    //region Home UI
    private void SetID() {

        upvotes = findViewById(R.id.nupv);
        downvotes = findViewById(R.id.ndnv);
        upvt = findViewById(R.id.upvote);
        dnvt = findViewById(R.id.downvote);
        cmnt = findViewById(R.id.comment);
        shr = findViewById(R.id.share);
        answer = findViewById(R.id.addanswerbttn);

        //Code for ExoPlayer
        mSimpleExoPlayerView = findViewById(R.id.ExoPlayerView);
        mProgressBar = findViewById(R.id.my_spinner);

        bottomNavigationView = findViewById(R.id.bottom_navigation);

    }

    private void AddYourAnswer(){
        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uplque_id=tques_id;
                infullscreen=true;
                Log.d("AnswerOnClick", "I am running");

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"addYourAnswer");
                mFirebaseAnalytics.logEvent("addYourAnswerClicked",bundle);

                startActivity(new Intent(getApplicationContext(),Add_Answer.class));
            }
        });
    }

    private void AddComment() {
        cmnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //vid.pause();
                commans_id=tans_id;
                commentfragment=new CommentSheet();
                commentfragment.show(getSupportFragmentManager(),"Comments");

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"addYourComment");
                mFirebaseAnalytics.logEvent("addYourCommentClicked",bundle);

                pausePlayer();
                youTubePlayer.pause();
            }
        });
    }

    private void UpvoteAndDownvoteLogic() {
        upvt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user_vote==0)
                {user_vote=1; nupvotes+=1;}
                else if(user_vote==-1)
                {user_vote=1; ndownvotes-=1; nupvotes+=1;}
                else if(user_vote==1){user_vote=0; nupvotes-=1;}
                upvotes.setText(String.format("%d Upvotes",nupvotes));
                downvotes.setText(String.format("%d Downvotes",ndownvotes));
                if(user_vote==1){
                    upvt.setImageResource(R.drawable.home_upvote_clicked);
                    dnvt.setImageResource(R.drawable.home_downvote);
                    upvt.setBackgroundResource(R.drawable.votes_pressed);
                    dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                } else if(user_vote==-1){
                    dnvt.setImageResource(R.drawable.home_downvote_clicked);
                    upvt.setImageResource(R.drawable.home_upvote);
                    upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    dnvt.setBackgroundResource(R.drawable.votes_pressed);


                } else {
                    dnvt.setImageResource(R.drawable.home_downvote);
                    upvt.setImageResource(R.drawable.home_upvote);
                    upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                }

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"upvote");
                mFirebaseAnalytics.logEvent("upvoteClicked",bundle);
                upvote(tans_id);
            }
        });

        dnvt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user_vote==0){user_vote=-1; ndownvotes+=1;} else if(user_vote==-1){user_vote=0; ndownvotes-=1;} else if(user_vote==1){user_vote=-1; nupvotes-=1; ndownvotes+=1;}
                upvotes.setText(String.format("%d Upvotes",nupvotes));
                downvotes.setText(String.format("%d Downvotes",ndownvotes));
                if(user_vote==1){
                    upvt.setImageResource(R.drawable.home_upvote_clicked);
                    dnvt.setImageResource(R.drawable.home_downvote);
                    upvt.setBackgroundResource(R.drawable.votes_pressed);
                    dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                } else if(user_vote==-1){
                    dnvt.setImageResource(R.drawable.home_downvote_clicked);
                    upvt.setImageResource(R.drawable.home_upvote);
                    upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    dnvt.setBackgroundResource(R.drawable.votes_pressed);

                } else {
                    dnvt.setImageResource(R.drawable.home_downvote);
                    upvt.setImageResource(R.drawable.home_upvote);
                    upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                }

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"downvote");
                mFirebaseAnalytics.logEvent("downvoteClicked",bundle);
                downvote(tans_id);
            }
        });
    }

    private void ShareAnswer() {
        shr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                //Use the below line to share revidly link with ans id

                //String shareBody = "http://revidly.co/share?"+"qid="+tques_id+"&"+"aid="+tans_id;
                String shareBody = "http://revidly.co/share?"+"aid="+tans_id;

                //Currently Sending it to Google Play Store to download app
                //String shareBody = "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +  "&hl=en";

                //sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"shareAnswer");
                mFirebaseAnalytics.logEvent("shareAnswerClicked",bundle);
            }
        });
    }
    //endregion

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("function call: ", "onResume");

        /* Registering Broadcast receiver */
        ////IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        ////this.registerReceiver(internetConnector, intentFilter);


        //Toast.makeText(this, "AID in OnResume is null", Toast.LENGTH_SHORT).show();
        if (main) {
            makevisible();
            //VideoView videoView = findViewById(R.id.vdVw);
            try {
                //videoView.setVideoPath(vurl);
                //videoView.start();
                //playvideoExoPlayer(vurl);
                if(mSimpleExoPlayerView.getVisibility()== View.VISIBLE)
                    resumePlayer();
                else
                    youTubePlayer.play();
                Log.d("kamalurl",vurl);
            }catch (Exception e){
                nextAns();
                System.out.println(e.getStackTrace());
                Crashlytics.logException(e);
            }
        }


    }

    //region Code for ExoPlayer Starts
    private void initExoPlayer() {
        Log.d("function call ", "initExoPlayer");
        mBandwidthMeter = new DefaultBandwidthMeter();
        mAdaptiveTrackSelectionFactory = new AdaptiveTrackSelection.Factory(mBandwidthMeter);
        mTrackSelector = new DefaultTrackSelector(mAdaptiveTrackSelectionFactory);

        mLoadControl = new DefaultLoadControl();

        mSimpleExoPlayer = ExoPlayerFactory.newSimpleInstance(this, mTrackSelector, mLoadControl);

        mSimpleExoPlayerView.setPlayer(mSimpleExoPlayer);
    }

    private void playvideoExoPlayer(String playUrl) {

        Log.d("function call ", "playvideoExoPlayer");
        // Produces DataSource instances through which media data is loaded.
        DefaultBandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(FullscreenActivity.this,
                Util.getUserAgent(FullscreenActivity.this, "com.exoplayerdemo"), bandwidthMeter);

        // Produces Extractor instances for parsing the media data.
        ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();

        // This is the MediaSource representing the media to be played.
        MediaSource videoSource = new ExtractorMediaSource(Uri.parse(playUrl),
                dataSourceFactory, extractorsFactory, null, null);

        // Prepare the player with the source.
        mLoopingMediaSource = new LoopingMediaSource(videoSource);

        mSimpleExoPlayer.prepare(videoSource);

        mSimpleExoPlayer.setPlayWhenReady(true);

        mSimpleExoPlayerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent touchEvent) {
                //vid.pause();
                //x1 = 0;
                //y1= 0;
                View view = findViewById(R.id.question);
                Log.d("ExoPlayer", "I am touched");
                switch (touchEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        x1 = touchEvent.getX();
                        y1 = touchEvent.getY();
                        Log.d("ExoPlayer", "Action Down \nx1:" + x1 +"\ny1:" + y1);
                        exoplayer_action_up = true;
                        break;


                    case MotionEvent.ACTION_UP:
                        x2 = touchEvent.getX();
                        y2 = touchEvent.getY();

                        final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                        final ConstraintLayout clt = findViewById(R.id.clt);

                        if (abs(x1 - x2) < 200 && abs(y1 - y2) < 200) {
                            toggle();
                            Log.d("touch event", "Action Up : Toggle \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);

                        }
                        if (y1 < y2 && abs(x1 - x2) < abs(y1 - y2) && abs(y1 - y2) > 200) {

                            qno -= 1;
                            if (view.getVisibility() == View.INVISIBLE) toggle();
                            Log.d("touch event", "Action Up Next Ques 1 \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);
                            nextQue();

                            Animator translationAnimatorRV = ObjectAnimator
                                    .ofFloat(rv, View.TRANSLATION_Y, rv.getHeight(), 0f)
                                    .setDuration(500);
                            Animator translationAnimatorCLT = ObjectAnimator
                                    .ofFloat(clt, View.TRANSLATION_Y, clt.getHeight(), 0f)
                                    .setDuration(500);

                            final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                                    R.anim.slide_down);
                            slide_up.setDuration(500);
                            rv.startAnimation(slide_up);
                            ////clt.startAnimation(slide_up);

                            final AnimatorSet animatorSet = new AnimatorSet();
                            //animatorSet.playSequentially(translationAnimatorRV);
                            ////animatorSet.playTogether(translationAnimatorRV, translationAnimatorCLT);


                        } else if ((y1 > y2) && (abs(x1 - x2) < abs(y1 - y2) && abs(y1 - y2) > 200)) {
                            qno += 1;
                            //final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                            Animator translationAnimatorRV = ObjectAnimator
                                    .ofFloat(rv, View.TRANSLATION_Y, rv.getHeight(), 0f)
                                    .setDuration(500);

                            Animator translationAnimatorCLT = ObjectAnimator
                                    .ofFloat(clt, View.TRANSLATION_Y, clt.getHeight(), 0f)
                                    .setDuration(500);

                            if (view.getVisibility() == View.INVISIBLE) toggle();

                            Log.d("touch event", "Action Up Next Ques 2 \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);

                            nextQue();

                            final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                                    R.anim.slide_up);
                            rv.startAnimation(slide_up);
                            ////clt.startAnimation(slide_up);

                            final AnimatorSet animatorSet = new AnimatorSet();
                            ////animatorSet.playTogether(translationAnimatorRV, translationAnimatorCLT);

                        } else if (x1 > x2 && abs(x1 - x2) > 200) {
                            ano = ano + 1;
                            //final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                            final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                                    R.anim.slide_in_right);
                            slide_up.setDuration(500);
                            rv.startAnimation(slide_up);
                            ////clt.startAnimation(slide_up);
                            Log.d("touch event", "Action Up Next Ans \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);
                            nextAns();
                            makevisible();
                        } else if (x2 > x1 && abs(x1 - x2) > 200) {
                            main = false;
                            //vid.stopPlayback();
                            //vid.suspend();
                            mSimpleExoPlayer.stop();
                            qa_ques_id = tques_id;
                            qaquestion = ques;
                            Log.d("touch event", "Action Up Ques and Ans \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);
                            try{
                                qanda();
                            }catch (Exception e)
                            { Crashlytics.logException(e);}
                        }
                        break;

                }
                return false;
            }
        });

        mSimpleExoPlayer.addListener(new ExoPlayer.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest, int i) {

            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

            }

            @Override
            public void onLoadingChanged(boolean isLoading) {

            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {

                if (playbackState == ExoPlayer.STATE_BUFFERING) {
                    mProgressBar.setVisibility(View.VISIBLE);
                } else {
                    mProgressBar.setVisibility(View.GONE);
                }
                if (playbackState == ExoPlayer.STATE_ENDED)
                {
                    qno = qno + 1;
                    final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                    final ConstraintLayout clt = findViewById(R.id.clt);
                    nextQue();
                    final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_up);
                    rv.startAnimation(slide_up);
                    clt.startAnimation(slide_up);
                }
            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {

            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {

            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {
                //Toast.makeText(FullscreenActivity.this, "Error = " + error.getMessage(), Toast.LENGTH_SHORT).show();

                try {

                    if(checkGetAns) {
                        if (answers[ano].getString("ans_url").contains(API_MEDIA_URL))
                            //vid.setVideoPath(answers[ano].getString("ans_url"));
                            playvideoExoPlayer(answers[ano].getString("ans_url"));
                        else
                            //vid.setVideoPath(API_MEDIA_URL + answers[ano].getString("ans_url"));
                            playvideoExoPlayer(API_MEDIA_URL + answers[ano].getString("ans_url"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Crashlytics.logException(e);
                }
                //vid.start();
                Log.d("video", "setOnErrorListener ");


            }

            @Override
            public void onPositionDiscontinuity(int reason) {

            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

            }

            @Override
            public void onSeekProcessed() {

            }


            public void onPositionDiscontinuity() {

            }

        });
    }

    /*
    @Override
    protected void onStop() {
        super.onStop();
        stopMedia();
    }
     */

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("function call ", "onPause");
        //Toast.makeText(this, "OnPause Called "+aid, Toast.LENGTH_SHORT).show();
        if(mSimpleExoPlayerView.getVisibility() == View.VISIBLE)
            pausePlayer();
        if(youTubePlayerView.getVisibility() == View.VISIBLE)
            youTubePlayer.pause();
        //stopMedia();
        //activityPaused();
        ////unregisterReceiver(internetConnector);
    }
    /*
        @Override
        protected void onRestart() {
            super.onRestart();
            Log.d("function call ", "onRestart");

            aid = getIntent().getStringExtra(PARAM_TOKEN);

            Toast.makeText(this, "onRestart "+aid, Toast.LENGTH_SHORT).show();

            if (aid != null) {
                loadHome(aid);
                //Toast.makeText(this, "AID in OnRestart "+aid , Toast.LENGTH_SHORT).show();
            }
            else {
                if (main) {
                    makevisible();
                    //VideoView videoView = findViewById(R.id.vdVw);
                    try {
                        //videoView.setVideoPath(vurl);
                        //videoView.start();
                        playvideoExoPlayer(vurl);
                        Log.d("kamalurl",vurl);
                    }catch (Exception e){
                        nextAns();
                        System.out.println(e.getStackTrace()); }
                }
            }
        }
    */
    @Override
    protected void onStop() {
        super.onStop();
        Log.d("function call: ", "onStop");
        //Toast.makeText(this, "onStop "+aid, Toast.LENGTH_LONG).show();

        pausePlayer();
        //vid.stopPlayback();
        //stopMedia();
        //if(main) clearApplicationData();
    }

    private void stopMedia() {
        mSimpleExoPlayer.stop();

        //mSimpleExoPlayer.release();
        Log.d("function call ", "stopMedia");
    }
    private void pausePlayer(){
        mSimpleExoPlayer.setPlayWhenReady(false);
        //mSimpleExoPlayer.getPlaybackState();
    }
    public void resumePlayer(){

        mSimpleExoPlayer.setPlayWhenReady(true);
        //mSimpleExoPlayer.seekTo(mSimpleExoPlayer.getCurrentPosition());
        mSimpleExoPlayer.getPlaybackState();
    }

    //endregion Code for ExoPlayer Ends
    private void showTutorSequenceFullScreen(int millis) {

        Log.d("showtutor", "In showTutorSequence function");
        ShowcaseConfig config = new ShowcaseConfig(); //create the showcase config
        config.setDelay(millis); //set the delay of each sequence using millis variable

        MaterialShowcaseSequence sequence = new MaterialShowcaseSequence(this, SHOWCASE_ID); // create the material showcase sequence

        sequence.setConfig(config); //set the showcase config to the sequence.

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.question))
                        .setTitleText("Question asked by a user")
                        .setDismissText("Click Here : Next")
                        //.setDismissOnTargetTouch(false)
                        //.setContentText("Click on Next")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withRectangleShape()
                        .build()
        );

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.my_spinner))
                        .setTitleText("Video Uploaded")
                        .setDismissText("Click Here : Next")
                        //.setContentText("This video is uploaded by another user in response to the Question")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape(true)
                        .setShapePadding(100)
                        .build()
        ); // add view for the second sequence, in this case it is a textview.

        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.propic))
                        .setTitleText("Profile Picture")
                        .setDismissText("Click Here : Next")
                        //.setContentText("The DP of the person who has uploaded the Video")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        ); // add view for the third sequence, in this case it is a checkbox.
         */

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.upvote))
                        .setTitleText("UpVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Like the video? UpVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.downvote))
                        .setTitleText("DownVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Did not like the video? DownVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.comment))
                        .setTitleText("Comment on the Video")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Provide your views by commenting on the video")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.share))
                        .setTitleText("Share this video with your Friends")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Share this video with your friends.")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.addanswerbttn))
                        .setTitleText("Want to Upload your own Video?")
                        .setDismissText("Click Here : Next")
                        .setContentText("Upload it from here")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_home))
                        .setTitleText("Home Feed")
                        .setDismissText("Click Here : Next")
                        .setContentText("See videos uploaded by users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_discover))
                        .setTitleText("Search for Questions")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Search for questions asked by other users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_answer))
                        .setTitleText("Question Tabs")
                        .setDismissText("Click Here : Next")
                        .setContentText("More Questions for you to browse")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_ask_ques))
                        .setTitleText("Want to ask a Question?")
                        .setDismissText("Click Here : Next")
                        .setContentText("Ask it from here")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        */
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Scroll Down")
                        .setDismissText("Click Here : Next")
                        .setContentText("Scroll down for more videos on questions")
                        //.withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Swipe Right for list of videos")
                        .setDismissText("Click Here : End Tutorial & Swipe Right")
                        //.setContentText("Swipe right for list of videos for the same question")
                        //.withCircleShape()
                        //.setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );

        sequence.start(); //start the sequence showcase
        Log.d("showtutor", "at end of ShowTutor Function");
    }

    /*** This method is used to initialize and set the listeners to VideoView
     * @param aid***/

    /*
    private void initVideoViewListeners(){
        vid.setMediaController(controller);
        final ProgressBar spinnerView = findViewById(R.id.my_spinner);

        vid.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                try {

                    if (answers[ano].getString("ans_url").contains(API_MEDIA_URL))
                        vid.setVideoPath(answers[ano].getString("ans_url"));
                    else
                        vid.setVideoPath(API_MEDIA_URL + answers[ano].getString("ans_url"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                vid.start();
                Log.d("video", "setOnErrorListener ");
                return true;
            }
        });

        //mediaController = new MediaController(this);
        vid.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                makevisible();
                //vid.start();
                //vid.resume();
                //mediaController.setMediaPlayer(mp);
                int topContainerId = getResources().getIdentifier("mediacontroller_progress", "id", "android");
                seekbar = (SeekBar) controller.findViewById(topContainerId);
                //seekbar.setMax(mp.getDuration());
                mp.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
                    @Override
                    public void onBufferingUpdate(MediaPlayer mp, int percent) {
                        if (percent<seekbar.getMax()) {
                            seekbar.setSecondaryProgress(percent);

                            Log.d("seekbar", "percent : " + String.valueOf(percent));
                            Log.d("seekbar", "percentage : " + String.valueOf(percent/100));
                        }
                    }
                });
            }
        });

        vid.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                qno = qno + 1;
                final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                nextQue();
                final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_up);
                rv.startAnimation(slide_up);
            }
        });

        vid.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                if (MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START == what) {
                    spinnerView.setVisibility(View.GONE);

                }

                if (MediaPlayer.MEDIA_INFO_BUFFERING_START == what) {
                    spinnerView.setVisibility(View.VISIBLE);
                    //vid.start();
                }

                if (MediaPlayer.MEDIA_INFO_BUFFERING_END == what) {
                    spinnerView.setVisibility(View.VISIBLE);
                }

                return false;
            }
        });
    }
*/

    private void loadHome(String aid){
        Log.d("function call ", "loadHome");
        getques(aid);
        getbookmarks();
    }

    /*** This method is used to interact with touch and swipe events ***/

    public boolean onTouchEvent(MotionEvent touchEvent) {
        Log.d("function call ", "onTouchEvent");
        View view = findViewById(R.id.question);
        //VideoView videoView = findViewById(R.id.vdVw);
        switch (touchEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                Log.d("touch event", "Action Down \nx1:" + x1 +"\ny1:" + y1);
                exoplayer_action_up = false;
                break;

            case MotionEvent.ACTION_UP:
                if (!exoplayer_action_up) {
                    x2 = touchEvent.getX();
                    y2 = touchEvent.getY();

                    final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                    final ConstraintLayout clt = findViewById(R.id.clt);

                    if (abs(x1 - x2) < 200 && abs(y1 - y2) < 200) {
                        toggle();
                        Log.d("touch event", "Action Up : Toggle \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);

                    }
                    if (y1 < y2 && abs(x1 - x2) < abs(y1 - y2) && abs(y1 - y2) > 200) {
                    /*videoView.stopPlayback();
                    videoView.setVisibility(View.GONE);
                    videoView.setVisibility(View.VISIBLE);
                    videoView.suspend();
                    service.submit(new Runnable() {
                        @Override
                        public void run() {
                            clearApplicationData();
                            getques();
                        }
                    });
                    qno = 0;
                    ano = 0;
                    nq.stopPlayback();
                    na.stopPlayback();

                    final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                    final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                            R.anim.slide_down);
                    slide_up.setDuration(200);
                    makeinvisible();
                    rv.startAnimation(slide_up);
                    //makevisible();*/
                        qno -= 1;
                        //final ConstraintLayout rv = findViewById(R.id.relativeLayout);


                        if (view.getVisibility() == View.INVISIBLE) toggle();
                        Log.d("touch event", "Action Up Next Ques 1 \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);

                        nextQue();

                        Animator translationAnimatorRV = ObjectAnimator
                                .ofFloat(rv, View.TRANSLATION_Y, rv.getHeight(), 0f)
                                .setDuration(500);

                        Animator translationAnimatorCLT = ObjectAnimator
                                .ofFloat(clt, View.TRANSLATION_Y, clt.getHeight(), 0f)
                                .setDuration(500);

                        final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                                R.anim.slide_down);
                        slide_up.setDuration(500);
                        rv.startAnimation(slide_up);
                        ////clt.startAnimation(slide_up);

                        final AnimatorSet animatorSet = new AnimatorSet();
                        //animatorSet.playSequentially(translationAnimatorRV);
                        ////animatorSet.playTogether(translationAnimatorRV, translationAnimatorCLT);


                    } else if ((y1 > y2) && (abs(x1 - x2) < abs(y1 - y2) && abs(y1 - y2) > 200)) {
                        qno += 1;
                        //final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                        Animator translationAnimatorRV = ObjectAnimator
                                .ofFloat(rv, View.TRANSLATION_Y, rv.getHeight(), 0f)
                                .setDuration(500);

                        Animator translationAnimatorCLT = ObjectAnimator
                                .ofFloat(clt, View.TRANSLATION_Y, clt.getHeight(), 0f)
                                .setDuration(500);

                        if (view.getVisibility() == View.INVISIBLE) toggle();

                        Log.d("touch event", "Action Up Next Ques 2 \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);

                        nextQue();

                        final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                                R.anim.slide_up);
                        rv.startAnimation(slide_up);
                        ////clt.startAnimation(slide_up);

                        final AnimatorSet animatorSet = new AnimatorSet();
                        ////animatorSet.playTogether(translationAnimatorRV, translationAnimatorCLT);

                    } else if (x1 > x2 && abs(x1 - x2) > 200) {
                        ano = ano + 1;
                        //final ConstraintLayout rv = findViewById(R.id.relativeLayout);
                        final Animation slide_up = AnimationUtils.loadAnimation(getApplicationContext(),
                                R.anim.slide_in_right);
                        slide_up.setDuration(500);
                        rv.startAnimation(slide_up);
                        ////clt.startAnimation(slide_up);
                        Log.d("touch event", "Action Up Next Ans \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);
                        nextAns();
                        makevisible();
                    } else if (x2 > x1 && abs(x1 - x2) > 200) {
                        main = false;
                        //vid.stopPlayback();
                        //vid.suspend();
                        //mSimpleExoPlayer.stop();
                        qa_ques_id = tques_id;
                        qaquestion = ques;
                        Log.d("touch event", "Action Up Ques and Ans \nx1:" + x1 + "\nx2:" + x2 + "\ny1:" + y1 + "\ny2:" + y2);

                        try{
                            qanda();

                        }catch (Exception e){
                            e.printStackTrace();
                            Crashlytics.logException(e);
                        }

                    }
                }
                break;
        }
        return false;
    }


    /*** This method is used to initialize and and play the video ***/

    private void playVideo(String kind, final String ansUrl){
        Log.d("function call ", "playVideo");
        //final ProgressBar spinnerView = findViewById(R.id.my_spinner);

        if(youTubePlayerView.getVisibility() == View.VISIBLE)
            youTubePlayerView.setVisibility(View.GONE);

        if(youTubePlayer!=null)
            youTubePlayer.pause();

        //if(vid.getVisibility() == View.VISIBLE) vid.setVisibility(View.GONE);

        if(mSimpleExoPlayerView.getVisibility() == View.VISIBLE)
            mSimpleExoPlayerView.setVisibility(View.GONE);
        /*
        if(vid.isPlaying()) {
            vid.stopPlayback();
            vid.suspend();
        }
         */
        if(mSimpleExoPlayer!=null) {
            //mSimpleExoPlayer.stop();
            pausePlayer();
        }

        if(kind.equals(VIDEO_KIND_SELF)) {
            /*
            vid.setVideoPath(proxyserver1.getProxyUrl(API_MEDIA_URL + ansUrl));
            vid.setVisibility(View.VISIBLE);
            spinnerView.setVisibility(View.VISIBLE);
            vid.start();
             */
            /* Loader on Home Feed Logic */
            //final ProgressBar spinnerView2 = (ProgressBar) findViewById(R.id.my_spinner2);
            //spinnerView2.setVisibility(View.GONE);

            playvideoExoPlayer(proxyserver1.getProxyUrl(API_MEDIA_URL + ansUrl));
            mSimpleExoPlayerView.setVisibility(View.VISIBLE);
            mProgressBar.setVisibility(View.VISIBLE);

            /* Code for loader ends */

        }
        else if(kind.equals(VIDEO_KIND_YOUTUBE)) {
            Log.d("ANSURL", ansUrl );
            if(youTubePlayer == null){
                Log.d("ANSURL", "youtubeplayer is not initialised");
            }

            youTubePlayerView.getYouTubePlayerWhenReady(new YouTubePlayerCallback() {
                @Override
                public void onYouTubePlayer(@NotNull YouTubePlayer youTubePlayer1) {
                    Log.d("ANSURL", "youtubeplayer is now initialised");
                    youTubePlayer1.loadVideo(ansUrl,0);
                    youTubePlayerView.setVisibility(View.VISIBLE);
                }
            });
        }

    }

    /*** Unlike the name suggests, This method is used to instantiate a new question in homefeed which is denoted by qno, not necessarily the next question ***/

    @SuppressLint("SetTextI18n")
    void nextQue()  {
        Log.d("function call ", "nextQue");
        try {
            if (questions.length > 0) {

                if (qno >= questions.length) qno = 0;
                if (qno < 0) qno = questions.length - 1;

                //get answers
                getans(questions[qno].getString("_id"));

                tques_id = questions[qno].getString("_id");
                tans_id = questions[qno].getString("ans_id");

                TextView question = findViewById(R.id.question);
                TextView username = findViewById(R.id.username);
                TextView hashtags = findViewById(R.id.hashtags);

                try {
                    ((TextView) findViewById(R.id.ansno)).setText(questions[qno].getString("ans_desc"));
                }catch(Exception e)
                {Crashlytics.logException(e);}

                SpannableString usernamestr = new SpannableString("@" + questions[qno].getJSONObject("ans_user").getString("name"));
                usernamestr.setSpan(new UnderlineSpan(), 1, usernamestr.length(), 0);
                username.setText(usernamestr);

                ImageView propic = findViewById(R.id.propic);
                /*** Change the Below url to the url of the dp of user who posted the answer***/
                //Picasso.get().load(R.drawable.propic1).placeholder(R.drawable.propic1).into(propic);
                System.gc();
                ques = questions[qno].getJSONObject("question").getString("title");
                question.setText(questions[qno].getJSONObject("question").getString("title"));
                hashtags.setText("#firstTag #secondTag #thirdTag...");
                System.out.println("Answer Link " + questions[qno].getString("ans_url"));

                String videoKind = questions[qno].getString("kind");

                String ansUrl = questions[qno].getString("ans_url").trim();
//                vid.stopPlayback();
//                vid.setVisibility(View.GONE);
//                vid.setVisibility(View.VISIBLE);
                mSimpleExoPlayer.stop();
                mSimpleExoPlayerView.setVisibility(View.GONE);
                mSimpleExoPlayerView.setVisibility(View.VISIBLE);

                playVideo(videoKind, ansUrl);
                nextqno=qno+1;

                //Caching starts with video view//
                if(nextqno==questions.length)nextqno=0;
                if(questions[qno].getString("kind").equals(VIDEO_KIND_SELF)) {
                    /*
                    try {
                        if (questions[nextqno].getString("ans_url").contains(BASE_URL + "/media/"))
                            nq.setVideoPath(proxyserver1.getProxyUrl(questions[qno].getString("ans_url")));
                        else
                            nq.setVideoPath(proxyserver1.getProxyUrl(BASE_URL + "/media/" + questions[qno].getString("ans_url")));
                        //nq.setVideoPath(proxyserver1.getProxyUrl(questions[nextqno].getString("ans_url")));
                        nq.start();
                    } catch (Exception e) {
                        //nq.setVideoPath(questions[nextqno].getString("ans_url"));
                        nq.start();
                        System.out.println(e.getStackTrace());
                    }

                    nq.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            mp.setVolume(0f,0f);
                            Handler handler =new Handler();
                            handler.postDelayed(new Runnable() {
                                public void run() {
                                    nq.stopPlayback();
                                }
                            }, 5000);
                        }
                    });
                     */
                }

                final TextView upvotes = findViewById(R.id.nupv);
                final TextView downvotes = findViewById(R.id.ndnv);
                final TextView comments = findViewById(R.id.ncmt);
                final TextView shares = findViewById(R.id.nshr);
                final ImageButton upvt = findViewById(R.id.upvote);
                final ImageButton dnvt = findViewById(R.id.downvote);
                final ImageButton cmnt = findViewById(R.id.comment);
                final ImageButton shr = findViewById(R.id.share);

                upvotes.setText(String.format("Upvotes"));
                downvotes.setText(String.format("Downvotes"));
                //shares.setText(String.format("Shares"));
                //comments.setText(String.format("Comments"));
                dnvt.setImageResource(R.drawable.home_downvote);
                upvt.setImageResource(R.drawable.home_upvote);
                setdata(tans_id);
            }
        } catch(JSONException ex){Crashlytics.logException(ex); }
    }

    /*** Unlike the name suggests,
     * This method is used to instantiate a new answer in home feed which is denoted by ano,
     * which is usually the next answer but not necessarily as when coming back from list of answers through selecting a question,
     * This method will be used to set the desired answer through ano
     ***/

    void nextAns() {
        Log.d("function call ", "nextAns");
        try {
            ImageView propic = findViewById(R.id.propic);
            service.submit(new Runnable() {
                @Override
                public void run() {

                }
            });
            try {
                if (main)
                    set_ans();
            } catch (JSONException e) {
                e.printStackTrace();
                Crashlytics.logException(e);
            }

            String videoKind = answers[ano].getString("kind");
            String ansUrl = answers[ano].getString("ans_url");

            playVideo(videoKind, ansUrl);
            /*** Change the Below url to the url of the dp of user who posted the answer***/
            //Picasso.get().load(R.drawable.propic1).placeholder(R.drawable.propic1).into(propic);

            //Caching starts//
            nextqno=qno+1;
            if(nextqno==questions.length)nextqno=0;
            if(questions[qno].getString("kind").equals(VIDEO_KIND_SELF)) {
                /*
                try {
                    if (questions[nextqno].getString("ans_url").contains(BASE_URL + "/media/"))
                        nq.setVideoPath(proxyserver1.getProxyUrl(questions[qno].getString("ans_url")));
                    else
                        nq.setVideoPath(proxyserver1.getProxyUrl(BASE_URL + "/media/" + questions[qno].getString("ans_url")));
                    //nq.setVideoPath(proxyserver1.getProxyUrl(questions[nextqno].getString("ans_url")));
                    nq.start();
                } catch (Exception e) {
                    //nq.setVideoPath(questions[nextqno].getString("ans_url"));
                    nq.start();
                    System.out.println(e.getStackTrace());
                }
                nq.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        mp.setVolume(0f,0f);
                        Handler handler =new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                nq.stopPlayback();
                            }
                        }, 5000);
                    }
                });

                 */
            }
            int nano=ano+1;
            if(nano==answers.length) nano=0;
            if(answers[nano].getString("kind").equals(VIDEO_KIND_SELF)){
                /*

                try{
                    if(answers[nano].getString("ans_url").contains(BASE_URL + "/media/"))
                        naurl=proxyserver.getProxyUrl(answers[nano].getString("ans_url"));
                    else
                        naurl=proxyserver.getProxyUrl(BASE_URL + "/media/"+answers[nano].getString("ans_url").trim());
                }catch (Exception e){
                    if(answers[nano].getString("ans_url").contains(BASE_URL + "/media/"))
                        naurl=answers[nano].getString("ans_url");
                    else
                        naurl=BASE_URL + "/media/"+answers[ano].getString("ans_url").trim();
                    System.out.println(e.getStackTrace());
                }
                na.setVideoPath(naurl);
                na.start();
                na.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        mp.setVolume(0f, 0f);
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                na.stopPlayback();
                            }
                        }, 5000);
                    }
                });
                nq.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        Log.d("video", "setOnErrorListener ");
                        return true;
                    }
                });

                */
            }
        }
        catch(Exception ex){Crashlytics.logException(ex);}
    }

    /*** This method is used to set the information on current answer ***/
    void set_ans() throws JSONException {
        Log.d("function call ", "set_ans");
        if (ano == answers.length) ano = 0;
        Log.d("set_ans ", "line 1682");
        tans_id = answers[ano].getString("_id");
        Log.d("set_ans ", "line 1630");
        TextView tv = findViewById(R.id.ansno);
        final TextView upvotes = findViewById(R.id.nupv);
        final TextView downvotes = findViewById(R.id.ndnv);
        final TextView comments = findViewById(R.id.ncmt);
        final TextView shares = findViewById(R.id.nshr);
        final ImageButton upvt = findViewById(R.id.upvote);
        final ImageButton dnvt = findViewById(R.id.downvote);
        final ImageButton cmnt = findViewById(R.id.comment);
        final ImageButton shr = findViewById(R.id.share);
        upvotes.setText(String.format("Upvotes"));
        downvotes.setText(String.format("Downvotes"));
        //shares.setText(String.format("Shares"));
        //comments.setText(String.format("Comments"));
        dnvt.setImageResource(R.drawable.home_downvote);
        upvt.setImageResource(R.drawable.home_upvote);
        setdata(tans_id);
        tv.setText(answers[ano].getString("ans_desc"));
        SpannableString usernamestr = new SpannableString("@" + answers[ano].getString("name"));
        usernamestr.setSpan(new UnderlineSpan(), 1, usernamestr.length(), 0);
        ((TextView) findViewById(R.id.username)).setText(usernamestr);
        Log.d("function call ", "set_ans finished" + answers[ano].getString("_id"));
    }

    /*** This method makes an intent and launches the ques with list of answers activity ***/
    void qanda() {
        Log.d("function call ", "qanda");
        frmain=true;
        //VideoView videoView = findViewById(R.id.vdVw);
        //sp = videoView.getCurrentPosition();
        sp = (int)(mSimpleExoPlayer.getCurrentPosition());
        //videoView.stopPlayback();
        if(mSimpleExoPlayerView.getVisibility() == View.VISIBLE)
            mSimpleExoPlayer.stop();
        if(youTubePlayerView.getVisibility() == View.VISIBLE)
            youTubePlayer.pause();
        View view = findViewById(R.id.rv);
        main=false;
        sqno=qno;
        //Log.d("function call ", "qanda :" + answers[ano]);
        //startActivity(new Intent(this, HomeFeed.class));
        ////Intent myIntent = new Intent(view.getContext(), QuesAndAns.class);
        //startActivityForResult(myIntent, 0);
        ////overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        finish();
    }
    @Override
    public void onBackPressed() {

        qanda();
    }
    /*** This method makes an intent and launches the ques with list of answers activity(when clicked on a question in some other activity like the add question sheet) ***/
    void qandats(){
        Log.d("function call ", "qandats");
        frmain=true;
        qaup=false;
        //if(fragment.isVisible())
        fragment.dismiss();
        //VideoView videoView = findViewById(R.id.vdVw);

        //sp = videoView.getCurrentPosition();
        //videoView.stopPlayback();

        sp = (int)(mSimpleExoPlayer.getCurrentPosition());
        //videoView.stopPlayback();
        if(mSimpleExoPlayerView.getVisibility() == View.VISIBLE)
            mSimpleExoPlayer.stop();
        if(youTubePlayerView.getVisibility() == View.VISIBLE)
            youTubePlayer.pause();

        View view = findViewById(R.id.rv);
        main=false;
        Intent myIntent = new Intent(view.getContext(), QuesAndAns.class);
        startActivityForResult(myIntent, 0);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }

    /*** This method is used to go to Profile (or) Your Questions section after posting a question ***/

    public void quesPosted() {
        Log.d("function call ", "quesPosted");
        main=false;
        View viewprof = findViewById(R.id.rv);
        prof=true;
        Intent profile = new Intent(viewprof.getContext(), quesandansreq.class);
        startActivityForResult(profile, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        Log.d("function call ", "onActivityResult");
        if (requestCode == RECOVERY_REQUEST) {
            //getYouTubePlayerProvider().initialize(API_KEY, this);
        }

        if(requestCode==0) {
            main = true;
            //bottomNavigationView.getMenu().findItem(R.id.action_video).setChecked(true);
            //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
            //bottomNavigationView.getMenu().findItem(R.id.action_post).setEnabled(true);
            //bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(true);
            if (qaup) {
                qaup = false;
                fragment.show(getSupportFragmentManager(), "TAG");
                Log.d("onActivityResult", "I am inside qaup");
            }
            if(changed) {
                tques_id = qa_ques_id;
                answers = QuesAndAns.quanswers;
                TextView question =  findViewById(R.id.question);
                question.setText(ques);
                Log.d("onActivityResult", "I am inside changed");
            }
            System.gc();
            if (main) {
                try {
                    //Log.d("onActivityResult", "I am inside main nextAns()" + answers[ano].getString("ans_desc"));
                }
                catch(Exception e)
                {
                    e.printStackTrace();
                    Crashlytics.logException(e);
                }
                nextAns();
            }
            TextView tv= findViewById(R.id.ansno);

            try {
                tv.setText(""+answers[ano].getString("ans_desc"));
            } catch (JSONException e) {
                e.printStackTrace();
                Crashlytics.logException(e);
            }
        }
    }

    /*** This method is used to define changes on config change such as Screen Orientation ***/
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d("function call ", "onConfigurationChanged");
        //vid = findViewById(R.id.vdVw);
        ConstraintLayout clt = findViewById(R.id.clt);
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            //Toast.makeText(this, currentScreenOrientation, Toast.LENGTH_LONG).show();
            //ViewGroup.LayoutParams params = vid.getLayoutParams();
            ViewGroup.LayoutParams params = mSimpleExoPlayerView.getLayoutParams();
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.clone(clt);
            //constraintSet.connect(R.id.vdVw, ConstraintSet.TOP, R.id.clt, ConstraintSet.TOP, 0);
            //constraintSet.connect(R.id.vdVw, ConstraintSet.BOTTOM, R.id.clt, ConstraintSet.BOTTOM, 0);

            constraintSet.connect(R.id.ExoPlayerView, ConstraintSet.TOP, R.id.clt, ConstraintSet.TOP, 0);
            constraintSet.connect(R.id.ExoPlayerView, ConstraintSet.BOTTOM, R.id.clt, ConstraintSet.BOTTOM, 0);


            mSimpleExoPlayerView.setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            mSimpleExoPlayerView.setForegroundGravity(Gravity.CENTER_VERTICAL);
            constraintSet.applyTo(clt);

        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            //ViewGroup.LayoutParams params = vid.getLayoutParams();
            ViewGroup.LayoutParams params = mSimpleExoPlayerView.getLayoutParams();
            params.height = ViewGroup.LayoutParams.MATCH_PARENT;
            params.width = ViewGroup.LayoutParams.WRAP_CONTENT;
            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.clone(clt);
            //constraintSet.connect(R.id.vdVw, ConstraintSet.LEFT, R.id.clt, ConstraintSet.LEFT, 0);
            //constraintSet.connect(R.id.vdVw, ConstraintSet.RIGHT, R.id.clt, ConstraintSet.RIGHT, 0);

            constraintSet.connect(R.id.ExoPlayerView, ConstraintSet.LEFT, R.id.clt, ConstraintSet.LEFT, 0);
            constraintSet.connect(R.id.ExoPlayerView, ConstraintSet.RIGHT, R.id.clt, ConstraintSet.RIGHT, 0);

            mSimpleExoPlayerView.setLayoutParams(new ConstraintLayout.LayoutParams(params));
            mSimpleExoPlayerView.setForegroundGravity(Gravity.CENTER_HORIZONTAL);
            constraintSet.applyTo(clt);
        }
    }

    /*** The next three methods are used to show and hide various elements throughout the homefeed ***/
    //region Make Visible And InVisible
    void toggle() {
        Log.d("function call ", "toggle");
        View question = findViewById(R.id.question);
        if (question.getVisibility() == View.VISIBLE) {
            makeinvisible();
        } else {
            makevisible();
        }
    }

    void makevisible() {
        Log.d("function call ", "makevisible");
        View question = findViewById(R.id.question);
        View answer = findViewById(R.id.ansno);
        View pro = findViewById(R.id.propic);
        View upv = findViewById(R.id.upvote);
        View dnv = findViewById(R.id.downvote);
        View cmnt = findViewById(R.id.comment);
        View share = findViewById(R.id.share);
        View usr = findViewById(R.id.username);
        View hsh = findViewById(R.id.hashtags);
        View gra = findViewById(R.id.gradient);
        View nupv = findViewById(R.id.nupv);
        View ndnv = findViewById(R.id.ndnv);
        View ncmnt = findViewById(R.id.ncmt);
        View nshr = findViewById(R.id.nshr);
        View answerButton = findViewById(R.id.addanswerbttn);
        question.setVisibility(View.VISIBLE);
        answer.setVisibility(View.VISIBLE);
        pro.setVisibility(View.VISIBLE);
        upv.setVisibility(View.VISIBLE);
        dnv.setVisibility(View.VISIBLE);
        cmnt.setVisibility(View.VISIBLE);
        share.setVisibility(View.VISIBLE);
        usr.setVisibility(View.VISIBLE);
        //hsh.setVisibility(View.VISIBLE);
        gra.setVisibility(View.VISIBLE);
        nupv.setVisibility(View.VISIBLE);
        ndnv.setVisibility(View.VISIBLE);
        //ncmnt.setVisibility(View.VISIBLE);
        //nshr.setVisibility(View.VISIBLE);
        answerButton.setVisibility(View.VISIBLE);
    }

    void makeinvisible() {
        Log.d("function call ", "makeinvisible");
        View question = findViewById(R.id.question);
        View answer = findViewById(R.id.ansno);
        View pro = findViewById(R.id.propic);
        View upv = findViewById(R.id.upvote);
        View dnv = findViewById(R.id.downvote);
        View cmnt = findViewById(R.id.comment);
        View share = findViewById(R.id.share);
        View usr = findViewById(R.id.username);
        View hsh = findViewById(R.id.hashtags);
        View gra = findViewById(R.id.gradient);
        View nupv = findViewById(R.id.nupv);
        View ndnv = findViewById(R.id.ndnv);
        View ncmnt = findViewById(R.id.ncmt);
        View nshr = findViewById(R.id.nshr);
        View answerbutton = findViewById(R.id.addanswerbttn);
        question.setVisibility(View.INVISIBLE);
        answer.setVisibility(View.INVISIBLE);
        pro.setVisibility(View.INVISIBLE);
        upv.setVisibility(View.INVISIBLE);
        dnv.setVisibility(View.INVISIBLE);
        cmnt.setVisibility(View.INVISIBLE);
        share.setVisibility(View.INVISIBLE);
        usr.setVisibility(View.INVISIBLE);
        //hsh.setVisibility(View.INVISIBLE);
        gra.setVisibility(View.INVISIBLE);
        nupv.setVisibility(View.INVISIBLE);
        ndnv.setVisibility(View.INVISIBLE);
        //ncmnt.setVisibility(View.INVISIBLE);
        //nshr.setVisibility(View.INVISIBLE);
        answerbutton.setVisibility(View.INVISIBLE);

    }
    //endregion

    /***
     * These two methods delete the cache directory of our app, please configure this properly upon completion of the app
     * This has been made for the sole reason of deleting the cached video files which might take up a lot of space,
     * Please utilize this just for that and configure it so that it only does just that
     ***/

    //region Clear App Data
    public void clearApplicationData() {
        Log.d("function call ", "clearApplicationData");
        File cache = getCacheDir();
        //File appDir = new File(cache.getParent());
        File appDir = new File(cache.getPath());
        if (appDir.exists()) {
            String[] children = appDir.list();
            for (String s : children) {
                if (!s.equals("lib")) {
                    deleteDir(new File(appDir, s));
                    Log.i("EEERRRRRRROOOOOOOR", "**************** File /data/data/APP_PACKAGE/" + s + " DELETED *******************");
                }
            }
        }
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }

        return dir.delete();
    }
    //endregion

    //region Internet Connection Checkup
    @Override
    protected void onStart() {
        super.onStart();
        Log.d("function call ", "onStart");
        //isOnline();
        //displayInternetDialogue();
    }
    public void displayInternetDialogue(){
        try {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();

            alertDialog.setTitle("No Conncetion");
            alertDialog.setMessage("Internet not available, Cross check your internet connection and try again");
            alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Log.d("FullScreenActivity", "I am finishing");
                    finish();
                    //new FullscreenActivity().isOnline();
                }
            });

            alertDialog.show();
        } catch (Exception e) {
            Log.d(SyncStateContract.Constants._ID, "Show Dialog: " + e.getMessage());
            Crashlytics.logException(e);
        }
    }
/*
    public boolean isOnline() {
        ConnectivityManager conMgr = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conMgr.getActiveNetworkInfo();
        return isOnline = netInfo != null && netInfo.isConnected() && netInfo.isAvailable();
    }


 */
 /*
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("function call ", "onRestart");
        if (main) {
            makevisible();
            //VideoView videoView = findViewById(R.id.vdVw);
            try {
                //videoView.setVideoPath(vurl);
                //videoView.start();
                playvideoExoPlayer(vurl);
            }catch (Exception e){ nextAns(); System.out.println(e.getStackTrace()); }
        }
    }

  */
    //endregion

    //region API Calls

    void getques(String aid){
        Log.d("function call ", "getQues");
        OkHttpClient client = new OkHttpClient();

        if (aid != null) {
            url = BASE_URL + "/api/app/getallques?page=1&answerId="+aid;
        }
        else {
            url = BASE_URL + "/api/app/getallques?page=1";
        }

        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("Authorization", auth_token)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "8d094b19-eb9e-4af9-84d5-577d6aede2d1,ffd25515-039b-4562-aba9-6d0ece735f21")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());

                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                }else {
                    String resp = response.body().string();
                    try {
                        JSONArray result = new JSONArray(resp);
                        questions = new JSONObject[result.length()];

                        for (int i = 0; i < result.length(); i++) {
                            questions[i] = new JSONObject(result.get(i).toString());
                        }

                        Handler mainHandler;
                        try {
                            mainHandler = new Handler(FullscreenActivity.this.getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    nextQue();
                                }
                            });
                        } catch (NullPointerException e)
                        {Log.i("Null exception", e.getStackTrace().toString());
                            Crashlytics.logException(e);
                        }
                        response.body().close();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }

//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", resp);
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    void getans(String ques_id){
        Log.d("function call ", "getAns");
        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "/api/app/getallans";
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ques_id="+ques_id);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", auth_token)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "ce11070e-e3fa-47b5-8508-910a7ed44ab6,f723d7a6-ae6e-4132-add7-592aaed85850")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "32")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());

                System.out.println("Success getans: " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp = response.body().string();
                    try {
                        //JSONObject result=new JSONObject(response);
                        JSONArray result = new JSONArray(resp);
                        answers = new JSONObject[result.length()];

                        for (int i = 0; i < result.length(); i++) {

                            final JSONObject obj = new JSONObject(result.get(i).toString());

                            answers[i] = new JSONObject(result.get(i).toString());
                            if(answers[i].get("_id").equals(questions[qno].get("ans_id")))
                                ano=i;

                            Handler mainHandler;
                            checkGetAns = true;
                            try {
                                mainHandler = new Handler(FullscreenActivity.this.getMainLooper());
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {

                                    }
                                });
                            }
                            catch (NullPointerException e){Log.i("Null exception",e.getStackTrace().toString());
                                Crashlytics.logException(e);
                            }

                            Log.i("Question id "+i,obj.getString("ques_id"));
                            Log.i("Answer Id",obj.getString("_id"));
                            Log.i("Answer Description",obj.getString("ans_desc"));
                            Log.i("Answer URL",obj.getString("ans_url"));
                            Log.i("Answer Auth id",obj.getString("ans_auth_id"));
                            Log.i("Question Auth id",obj.getString("ques_auth_id"));
                        }
                        response.body().close();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", resp);
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    void upvote(final String ans_id){

        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "/api/app/upvote";
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ans_id="+ans_id);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token)
                .addHeader("cache-control", "no-cache")
                .addHeader("Postman-Token", "62f68963-bad1-4ed2-adf1-6d275e647694")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    setdata(ans_id);
                    Handler mainHandler;
                    try {
                        mainHandler = new Handler(FullscreenActivity.this.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                            }
                        });
                        response.body().close();
                    } catch (NullPointerException e) {
                        Log.i("Null exception", e.getStackTrace().toString());
                        Crashlytics.logException(e);
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", response.body().string());
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    void downvote(final String ans_id){

        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/api/app/downvote";

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ans_id="+ans_id);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", auth_token)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("cache-control", "no-cache")
                .addHeader("Postman-Token", "5fe314cf-7d2f-41d2-a5d3-7abb3ba2f3bc")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    Handler mainHandler;
                    setdata(ans_id);
                    try {
                        mainHandler = new Handler(FullscreenActivity.this.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                            }
                        });
                        response.body().close();
                    }
                    catch (NullPointerException e) {
                        Log.i("Null exception", e.getStackTrace().toString());
                        Crashlytics.logException(e);
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", response.body().string());
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    void setdata(String ans_id){
        Log.d("function call ", "setData");
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/api/app/loggedindetails";

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ans_id="+ans_id);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", auth_token)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "46c83302-892b-4bfc-8d13-0faf881db00b,8e3f96f4-cbf5-4554-8b72-1c6f8ec26e3a")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "31")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp=response.body().string();
                    Handler mainHandler;
                    try {
                        JSONObject obj = new JSONObject(resp);
                        if(obj.has("upvotes")) nupvotes=obj.getInt("upvotes"); else nupvotes=0;
                        if(obj.has("downvotes")) ndownvotes=obj.getInt("downvotes"); else ndownvotes=0;
                        if(obj.has("user_vote")) user_vote=obj.getInt("user_vote"); else  user_vote =0;
                        if(obj.has("comments")) ncomments=obj.getInt("comments"); else ncomments =0;
                        if(obj.has("shares")) nshares=obj.getInt("shares"); else nshares =0;

                        mainHandler = new Handler(FullscreenActivity.this.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                final TextView upvotesvw = findViewById(R.id.nupv);
                                final TextView downvotesvw = findViewById(R.id.ndnv);
                                final TextView commentsvw = findViewById(R.id.ncmt);
                                final TextView sharesvw = findViewById(R.id.nshr);
                                final ImageButton upvt = findViewById(R.id.upvote);
                                final ImageButton dnvt = findViewById(R.id.downvote);
                                final ImageButton cmnt = findViewById(R.id.comment);
                                final ImageButton shr = findViewById(R.id.share);

                                upvotesvw.setText(String.format("%d Upvotes",nupvotes));
                                downvotesvw.setText(String.format("%d Downvotes",ndownvotes));
                                //commentsvw.setText(String.format("%d Comments",ncomments));
                                //sharesvw.setText(String.format("%d Shares",nshares));

                                if(user_vote==1){
                                    upvt.setImageResource(R.drawable.home_upvote_clicked);
                                    dnvt.setImageResource(R.drawable.home_downvote);
                                    upvt.setBackgroundResource(R.drawable.votes_pressed);
                                    dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                                    /*upvt.setImageResource(R.drawable.upvclkd);
                                    dnvt.setImageResource(R.drawable.downv);*/
                                } else if(user_vote==-1){
                                    dnvt.setImageResource(R.drawable.home_downvote_clicked);
                                    upvt.setImageResource(R.drawable.home_upvote);
                                    upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    dnvt.setBackgroundResource(R.drawable.votes_pressed);

                                    /*dnvt.setImageResource(R.drawable.downvclkd);
                                    upvt.setImageResource(R.drawable.upv);*/
                                } else {
                                    dnvt.setImageResource(R.drawable.home_downvote);
                                    upvt.setImageResource(R.drawable.home_upvote);
                                    upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                                    /*dnvt.setImageResource(R.drawable.downv);
                                    upvt.setImageResource(R.drawable.upv);*/
                                }
                            }
                        });
                        response.body().close();
                    } catch (NullPointerException | JSONException e) {
                        Log.i("Null exception", e.getStackTrace().toString());
                        Crashlytics.logException(e);
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", resp);
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    void getbookmarks(){
        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "/api/app/viewbookmarks";
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("Authorization", auth_token)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "5225bfa6-cc21-47e6-8c19-a6fb887466f5,a90ef59f-aa47-4f06-81b8-3844f4eb6566")
                .addHeader("Host", BASE_HOST)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();


        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                e.printStackTrace();

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("getbookmarks ","Response" + response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp = response.body().string();
                    try {
                        JSONArray array = new JSONArray(resp);
                        for(int i=0; i<array.length(); i++){
                            JSONObject obj = array.getJSONObject(i);
                            if(obj.get("type").equals("question")) quesbookmarks.add(obj.getString("ques_id"));
                            if(obj.get("type").equals("answer")) ansbookmarks.add(obj.getString("ans_id"));
                        }
                        response.body().close();
                    } catch (NullPointerException | JSONException e) {
                        Log.i("Exception", e.getStackTrace().toString());
                        Crashlytics.logException(e);
                    }
//                    Log.i(" getbookmarks Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", resp);
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }
    //endregion

    /*check app version to check for update*/
    private String getCurrentVersion(){
        PackageManager pm = this.getPackageManager();
        PackageInfo pInfo = null;

        try {
            pInfo =  pm.getPackageInfo(this.getPackageName(),0);

        } catch (PackageManager.NameNotFoundException e1) {
            e1.printStackTrace();
            Crashlytics.logException(e1);
        }
        String currentVersion = pInfo.versionName;

        return currentVersion;
    }
    //Returns activity State
    /*
    public static boolean isActivityVisible() {
        return FullscreenActivityVisible; // return true or false
    }
    public static void activityResumed() {
        FullscreenActivityVisible = true;// this will set true when activity resumed

    }
*/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        //Toast.makeText(this, "onDestroy "+aid, Toast.LENGTH_LONG).show();
        Log.d("function call: ", "onDestroy");
        //if(main)
        //  clearApplicationData();
        stopMedia();
        youTubePlayerView.release();
    }
    /*
    public static void activityPaused() {
        FullscreenActivityVisible = false;// this will set false when activity paused

    }
    */

    public static synchronized FullscreenActivity getInstance() {
        return mInstance;
    }
    /*
    public void setConnectivityListener(InternetConnector_Checker.ConnectivityReceiverListener listener) {
        InternetConnector_Checker.connectivityReceiverListener = listener;
    }
    */

}