package co.revidly.android.helpers;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import com.crashlytics.android.Crashlytics;
import com.onesignal.shortcutbadger.util.BroadcastHelper;

import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import co.revidly.android.HomeFeed;
import co.revidly.android.R;
import me.leolin.shortcutbadger.Badger;
import me.leolin.shortcutbadger.ShortcutBadgeException;

import static java.lang.Boolean.FALSE;

public class NotificationService extends FirebaseMessagingService  implements Badger{
     public static final String INTENT_ACTION = "android.intent.action.APPLICATION_MESSAGE_UPDATE";
    public static final String EXTRA_UPDATE_APP_COMPONENT_NAME = "android.intent.extra.update_application_component_name";
    public static final String EXTRA_UPDATE_APP_MSG_TEXT = "android.intent.extra.update_application_message_text";
    private ResolveInfo resolveInfo;
    public static int id=0;
    String channel_id="Revidly";
    String TAG = "NotificationService";
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        Log.d("LOG_DATA","Inside Notification service");
        if(remoteMessage.getData()!=null){
            try{
                Log.d(TAG,"Response: "+remoteMessage.getData().toString());
                JSONObject jsonObject = new JSONObject(remoteMessage.getData());
                String title=jsonObject.getString("title");
                Log.d(TAG,"Title: "+jsonObject.getString("title"));
                String message=jsonObject.getString("message");
                String uniqueId = jsonObject.getString("uniqueId");
                String entityId = jsonObject.getString("entityId");
                Log.d(TAG,"EntityId: " + entityId);
                String imageUrl;
                if(jsonObject.has("imageUrl"))
                    imageUrl = jsonObject.getString("imageUrl");
                else
                    imageUrl = "";
                String kind = jsonObject.getString("kind");
                sendNotification(title,message, entityId, kind, imageUrl,uniqueId);
            }
            catch (Exception e){
                e.printStackTrace();
                Crashlytics.logException(e);
                Log.e(TAG,e.getMessage());
            }
        }
    }

    private void sendNotification(String title,String message, String entityId, String kind, String imageUrl, String uniqueId){

        String postId = null;
        String followerId = null;
        Boolean isComment=FALSE;

        if(kind.equals("comment_recieved"))
        {
            postId = entityId;
            followerId = null;
            isComment=Boolean.TRUE;
        }
        else if(kind.equals("new_post") || kind.equals("post_upvoted") || kind.equals("trending_post")){
            postId = entityId;
            followerId = null;
        }
        else if (kind.equals("new_follower")){
            postId = null;
            followerId = entityId;
        }

        Bitmap image = null;
        if(imageUrl.isEmpty() || imageUrl.equals("null") || imageUrl.equals(""))
        {
            image = BitmapFactory.decodeResource(this.getResources(),
                    R.drawable.ic_onesignal_large_icon_default);
        }
        else
        {
            try {
                URL newurl = new URL(imageUrl);
                image = BitmapFactory.decodeStream(newurl.openConnection().getInputStream());
                //image =
            }
            catch (Exception e)
            {
                e.printStackTrace();
                Crashlytics.log(e.toString());
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            Intent intent;
            intent = new Intent(getApplicationContext(), HomeFeed.class);
            intent.putExtra(HomeFeed.PARAM_TOKEN,postId);
            intent.putExtra(HomeFeed.PARAM_TOKEN_ProfileID,followerId);
            intent.putExtra(HomeFeed.PARAM_ISCOMMENT,isComment);
            intent.putExtra("NotifClicked",uniqueId);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, id /* Request code */, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, channel_id)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    //.setLargeIcon(getDrawable(R.drawable.ic_onesignal_large_icon_default))
                    //.setLargeIcon(BitmapFactory.decodeResource(this.getResources(),
                      //      R.drawable.ic_onesignal_large_icon_default))
                    .setLargeIcon(image)
                    .setContentIntent(pendingIntent);

            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            /* Create or update. */
            NotificationChannel channel = new NotificationChannel(channel_id,
                    "Notification channel",
                    NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
            Log.d("LOG_DATA","Inside channel. ");
            channel.setDescription("Desc");
            notificationManager.notify(id /* ID of notification */, notificationBuilder.build());
        }
        else{
            Intent intent;
            intent = new Intent(getApplicationContext(), HomeFeed.class);
            intent.putExtra(HomeFeed.PARAM_TOKEN,postId);
            intent.putExtra(HomeFeed.PARAM_TOKEN_ProfileID,followerId);
            intent.putExtra(HomeFeed.PARAM_ISCOMMENT,isComment);
            intent.putExtra("NotifClicked",uniqueId);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, id /* Request code */, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setSound(defaultSoundUri)
                    .setLargeIcon(image)
                    .setContentIntent(pendingIntent);
            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(id /* ID of notification */, notificationBuilder.build());
        }
        id++;
    }
    @Override
    public void executeBadge(Context context, ComponentName componentName, int badgeCount) throws ShortcutBadgeException {
        try {
            Class miuiNotificationClass = Class.forName("android.app.MiuiNotification");
            Object miuiNotification = miuiNotificationClass.newInstance();
            Field field = miuiNotification.getClass().getDeclaredField("messageCount");
            field.setAccessible(true);
            try {
                field.set(miuiNotification, String.valueOf(badgeCount == 0 ? "" : badgeCount));
            } catch (Exception e) {
                field.set(miuiNotification, badgeCount);
            }
        } catch (Exception e) {
            Intent localIntent = new Intent(
                    INTENT_ACTION);
            localIntent.putExtra(EXTRA_UPDATE_APP_COMPONENT_NAME, componentName.getPackageName() + "/" + componentName.getClassName());
            localIntent.putExtra(EXTRA_UPDATE_APP_MSG_TEXT, String.valueOf(badgeCount == 0 ? "" : badgeCount));
            if (BroadcastHelper.canResolveBroadcast(context, localIntent)) {
                context.sendBroadcast(localIntent);
            }
        }
        if (Build.MANUFACTURER.equalsIgnoreCase("Xiaomi")) {
            tryNewMiuiBadge(context, badgeCount);
        }
    }

    @Override
    public List<String> getSupportLaunchers() {
        return null;
    }
    private void tryNewMiuiBadge(Context context, int badgeCount) throws ShortcutBadgeException {
        if (resolveInfo == null) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            resolveInfo = context.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
        }

        if (resolveInfo != null) {
            NotificationManager mNotificationManager = (NotificationManager) context
                    .getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder builder = new Notification.Builder(context)
                    .setContentTitle("")
                    .setContentText("")
                    .setSmallIcon(resolveInfo.getIconResource());
            Notification notification = builder.build();
            try {
                Field field = notification.getClass().getDeclaredField("extraNotification");
                Object extraNotification = field.get(notification);
                Method method = extraNotification.getClass().getDeclaredMethod("setMessageCount", int.class);
                method.invoke(extraNotification, badgeCount);
                mNotificationManager.notify(0, notification);
            } catch (Exception e) {
                throw new ShortcutBadgeException("not able to set badge", e);
            }
        }
    }
}
