package co.revidly.android;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.FullscreenActivity.auth_token;
import static co.revidly.android.FullscreenActivity.invite_ques_id;
import static co.revidly.android.helpers.Config.BASE_URL;
import static co.revidly.android.helpers.Config.BASE_HOST;

public class AskQuestion extends BottomSheetDialogFragment {
    public static String Question,Description;
    public ArrayList<String> chkbox= new ArrayList<>();
    String[] checked;
    JSONArray checkedlist= new JSONArray();
    static RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager1;
    private addquessearchlistAdapter mAdapter;
    addquesrequestansadapter adapter;
    int no_topics=0;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.AppBottomSheetDialogTheme2);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                FrameLayout bottomSheet = d.findViewById(R.id.design_bottom_sheet);
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) bottomSheet.getParent();
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
                bottomSheetBehavior.setPeekHeight(bottomSheet.getHeight());
                coordinatorLayout.getParent().requestLayout();
            }
        });
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final EditText question = view.findViewById(R.id.Searchtopic);
        question.clearFocus();
        InputMethodManager im = (InputMethodManager)getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

        question.requestFocus();
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        //getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }

    @Override
    public void setupDialog(final Dialog dialog, int style) {
        super.setupDialog(dialog, style);

        //Set the custom view
        final View view = LayoutInflater.from(getContext()).inflate(R.layout.addquestion, null);
        dialog.setContentView(view);

        CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) ((View) view.getParent()).getLayoutParams();
        CoordinatorLayout.Behavior behavior = params.getBehavior();

        final EditText question = view.findViewById(R.id.Searchtopic);
        ImageButton close = view.findViewById(R.id.imageButton);
        Button add = view.findViewById(R.id.Add);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        question.requestFocus();
        question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                question.requestFocus();
            }
        });
        final EditText description = view.findViewById(R.id.quesdesc);
        description.setVisibility(View.GONE);
        description.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                description.requestFocus();
            }
        });
        recyclerView = view.findViewById(R.id.addq);
        layoutManager1 = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager1);
        final View view2 = LayoutInflater.from(getContext()).inflate(R.layout.addquestion2, null);
        final View view3 = LayoutInflater.from(getContext()).inflate(R.layout.addquestion3, null);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Question = question.getText().toString();
                    Description = description.getText().toString();
                if(!Question.equals("")) {
                    ((ViewGroup) view.getParent()).removeView(view);

                    Toast.makeText(getContext(),"Question Submitted",Toast.LENGTH_SHORT).show();

                    //addques();



                    dialog.setContentView(view2);
                    TextView qu = view2.findViewById(R.id.textView12);
                    qu.setText(Question);
                    final EditText searchtopic = view2.findViewById(R.id.Searchtopic);
                    searchtopic.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            searchtopic.requestFocus();
                        }
                    });
                    LinearLayout layout = view2.findViewById(R.id.recchkbox);
                    get_topic(layout);
                    /*for (int i = 0; i < 10; i++) {
                        final CheckBox checkBox = new CheckBox(getActivity());
                        checkBox.setText(String.format("Checkbox Suggestions %d", i + 1));
                        checkBox.setId(i);
                        checkBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                        layout.addView(checkBox);
                    }*/
                    Button next = view2.findViewById(R.id.button4);
                    ImageButton close = view2.findViewById(R.id.imageButton);
                    close.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });


                    next.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            //This is the part where the question will be further developed

                            for (int i = 0; i < no_topics; i++) {
                                CheckBox chk = view2.findViewById(i);
                                if (chk!=null && chk.isChecked()) chkbox.add(chk.getText().toString());
                            }
                            checked = new String[chkbox.size()];
                            for (int i=0;i<chkbox.size();i++) {
                                System.out.println(chkbox.get(i));
                                checkedlist.put(chkbox.get(i));
                                if(chkbox!=null)
                                    checked[i]=chkbox.get(i);
                                    Log.d("Topics Fragment", "");
                            }
                            chkbox.clear();
                            System.out.println(checked+"  "+checkedlist);
                            addques();


                            ((ViewGroup) view2.getParent()).removeView(view2);
                            dialog.setContentView(view3);
                            ImageButton close = view3.findViewById(R.id.imageButton);
                            close.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });
                            final EditText searchpeople = view3.findViewById(R.id.Searchpeople);
                            searchpeople.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    searchpeople.requestFocus();
                                }
                            });
                            searchpeople.addTextChangedListener(new TextWatcher() {
                                @Override
                                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                                }

                                @Override
                                public void onTextChanged(CharSequence s, int start, int before, int count) {
                                    adapter.getFilter().filter(s);

                                }

                                @Override
                                public void afterTextChanged(Editable s) {

                                }
                            });
                            RecyclerView recyclerView2 = view3.findViewById(R.id.people);
                            getuser(recyclerView2);
                            Button done = view3.findViewById(R.id.button4);
                            done.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    getDialog().dismiss();
                                    ((FullscreenActivity) getContext()).quesPosted();
                                    }
                                });
                            }
                        });
                }else Toast.makeText(getContext(),"Enter question",Toast.LENGTH_SHORT).show();
            }
        });
        List<JSONObject> mlist = new ArrayList<>();

        mAdapter = new addquessearchlistAdapter(getContext(), mlist);
        recyclerView.setAdapter(mAdapter);
        question.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mAdapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        /*if (behavior != null && behavior instanceof BottomSheetBehavior) {
            ((BottomSheetBehavior) behavior).setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
                @Override
                public void onStateChanged(@NonNull View bottomSheet, int newState) {
                    String state = "";

                    switch (newState) {
                        case BottomSheetBehavior.STATE_DRAGGING: {
                            state = "DRAGGING";
                            break;
                        }
                        case BottomSheetBehavior.STATE_SETTLING: {
                            state = "SETTLING";
                            break;
                        }
                        case BottomSheetBehavior.STATE_EXPANDED: {
                            state = "EXPANDED";
                            break;
                        }
                        case BottomSheetBehavior.STATE_COLLAPSED: {
                            state = "COLLAPSED";
                            break;
                        }
                        case BottomSheetBehavior.STATE_HIDDEN: {
                            dismiss();
                            state = "HIDDEN";
                            break;
                        }
                    }

                    Toast.makeText(getContext(), "Bottom Sheet State Changed to: " + state, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                }
            });
        }*/

    }
    void addques(){
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/api/app/postques";

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "title="+Question+"&desc="+Description+"&topic="+checkedlist);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "d9064ebe-ed96-4666-b0d6-fc749042bbf2,2d67a07b-53df-4f70-95fd-50e2573d7604")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "86")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();


        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    throw new IOException("Unexpected code " + response);
                } else {
                    try {
                        String resp = response.body().string();
                        JSONObject result = new JSONObject(resp);
                        invite_ques_id=result.getJSONObject("data").getString("_id");
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {

                                                        }
                                                    });*/
                    response.body().close();
                }
            }
        });
    }
    void get_topic(final LinearLayout layout){
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(BASE_URL+"/api/app/gettopics")
                .get()
                .addHeader("Authorization", auth_token)
                .addHeader("User-Agent", "PostmanRuntime/7.20.1")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "ab5a7e41-d3ed-4447-a508-8eb52494cd39,2aa5bdd8-73b1-4aab-9762-6947e1129f60")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    throw new IOException("Unexpected code " + response);
                } else {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    String resp = response.body().string();
                                    JSONArray result = new JSONArray(resp);
                                    Log.d("JSON Array for topics", "" + result);
                                    for (int i = 0; i < result.length(); i++) {
                                        no_topics=result.length();
                                        if(!result.getString(i).equals("null")) {
                                            final CheckBox checkBox = new CheckBox(getActivity());
                                            checkBox.setText(result.getString(i));
                                            checkBox.setId(i);
                                            checkBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                                            layout.addView(checkBox);
                                        }
                                    }
                                } catch (JSONException | IOException e) {
                                    e.printStackTrace();
                                    Crashlytics.logException(e);
                                }
                            }
                        });
                    response.body().close();
                }
            }
        });
    }
void getuser(final RecyclerView recyclerView2){
    OkHttpClient client = new OkHttpClient();

    Request request = new Request.Builder()
            .url(BASE_URL+"/api/app/fetchusers")
            .get()
            .addHeader("Content-Type", "application/x-www-form-urlencoded")
            .addHeader("Authorization", auth_token)
            .addHeader("User-Agent", "PostmanRuntime/7.20.1")
            .addHeader("Accept", "*/*")
            .addHeader("Cache-Control", "no-cache")
            .addHeader("Postman-Token", "8d2c4b40-29dd-40fd-b728-a87bb1bd4404,f46460c7-2cd1-4983-b0b3-0ee91e175190")
            .addHeader("Host", BASE_HOST)
            .addHeader("Accept-Encoding", "gzip, deflate")
            .addHeader("Connection", "keep-alive")
            .addHeader("cache-control", "no-cache")
            .build();


    Call call = client.newCall(request);
    call.enqueue(new Callback() {
        @Override
        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
        }

        @Override
        public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
            if (!response.isSuccessful()) {
                // You can also throw your own custom exception
                Log.i("Response ",response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                throw new IOException("Unexpected code " + response);
            } else {
                if (getDialog() != null) {
                    Handler mainHandler = new Handler(getDialog().getContext().getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String resp = response.body().string();
                                JSONArray result = new JSONArray(resp);
                                RecyclerView.LayoutManager layoutManager2;
                                layoutManager2 = new LinearLayoutManager(getDialog().getContext());
                                recyclerView2.setLayoutManager(layoutManager2);
                                final List<JSONObject> mList = new ArrayList<>();
                                for (int i = 0; i < result.length(); i++) {
                                    final JSONObject obj = new JSONObject(result.get(i).toString());
                                    mList.add(obj);
                                }
                                Handler mainHandler = new Handler(getContext().getMainLooper());
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        adapter = new addquesrequestansadapter(getContext(), mList);
                                        recyclerView2.setAdapter(adapter);
                                    }
                                });

                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                                Crashlytics.logException(e);
                            }
                        }
                    });
                    response.body().close();
                }
            }
        }
    });

}

}