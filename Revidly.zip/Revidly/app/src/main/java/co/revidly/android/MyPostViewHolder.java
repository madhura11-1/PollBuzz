package co.revidly.android;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;

@SuppressWarnings("ALL")
public class MyPostViewHolder extends RecyclerView.ViewHolder {
    PhotoView img;
    SimpleExoPlayerView exoPlayerView;
    ProgressBar myspinner;
    TextView previewTitle, previewDesc;
    ConstraintLayout previewCL;
    public MyPostViewHolder(@NonNull View itemView) {
        super(itemView);
        img = itemView.findViewById(R.id.img);
        exoPlayerView = itemView.findViewById(R.id.ExoPlayerView);
        myspinner=itemView.findViewById(R.id.my_spinner);
        previewTitle = itemView.findViewById(R.id.preview_Title);
        previewDesc = itemView.findViewById(R.id.preview_Desc);
        previewCL = itemView.findViewById(R.id.preview_text_container);
    }
}
