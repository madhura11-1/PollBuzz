package co.revidly.android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;

import com.google.firebase.messaging.FirebaseMessaging;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.FullscreenActivity.auth_token;
import static co.revidly.android.FullscreenActivity.invite_ques_id;
import static co.revidly.android.helpers.Config.BASE_URL;

public class selectClan extends AppCompatActivity {
    int no_topics=0;
    ConstraintLayout constraintLayout;
    ArrayList<String> topicName,topicsN,rules;
    ArrayList<String> selectedTopic;
    ListView listView;
    Button post;
    TextView errorMsg;
    String data;
    ArrayList<String> multdata,dataType;
    ClanArrayAdapter arrayAdapter;
    String postDescription;
    EditText searchClans;

    String previewImageURL;
    String previewTitle;
    String previewDesc;
    String previewUrl;
    ArrayList<String> UID = new ArrayList<>();
    boolean previewPresent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //getTopics();

        setContentView(R.layout.activity_select_clan);
        constraintLayout = findViewById(R.id.con);
        topicName = new ArrayList<>();
        dataType = new ArrayList<>();
        post = findViewById(R.id.post);
        listView = findViewById(R.id.listView);
        errorMsg = findViewById(R.id.errorMsg);
        listView.setDivider(null);
        topicsN = new ArrayList<>();
        rules = new ArrayList<>();

        getPreviousData();
        displayUserTopics();
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (arrayAdapter != null) {
                    selectedTopic = new ArrayList<>(arrayAdapter.getSelectedTopics());
                    Log.d("LOG_DATA", "SIZE: " + selectedTopic.size());
                    if (selectedTopic.size() == 0) {
                        errorMsg.setText("Please select at least one clan");
                    } else {
                        addPost();
                        Add_Answer.addAnswer.finish();
                    }
                }
                else{
                    Toast.makeText(selectClan.this, "Something went wrong...", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }


    private void getTopics(){
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/topic")
                .method("GET", null)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    Log.i("Response ",response.toString());
                    throw new IOException("Unexpected code " + response);
                }
                else{
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try{
                                String resp = response.body().string();
                                Log.d("LOG_TAG",resp);
                                JSONObject result = new JSONObject(resp);
                                Log.d("LOG_TAG", "Res: " + result);
                                Log.d("LOG_TAG","Len: "+ result.length());
                                //JSONArray data = new JSONArray(result.getString("data"));
                                JSONArray data = LoggedInUser.userTopics;
//                               Log.d("LOG_TAG","DATA" + data.getString();
                                Log.d("LOG_TAG","DATA" + data.length());
                                for (int i = 0; i < data.length(); i++){
                                    no_topics=data.length();
                                    if(!(data.getString(i).equals("null"))) {

                                        JSONObject name = new JSONObject(data.getString(i));
                                        Log.d("LOG_TAG","DATAA "+name.getString("topic_name"));
                                        topicName.add(name.getString("topic_name"));
                                    }
                                }
                                arrayAdapter = new ClanArrayAdapter(getApplicationContext(),R.layout.layout_clan_list
                                        ,topicName);
                                listView.setAdapter(arrayAdapter);


                            } catch (Exception e) {
                                Log.e("LOG_TAG",e.getMessage());
                                Crashlytics.logException(e);
                            }
                        }
                    });
                    response.body().close();
                }
            }
        });
    }

    private void getPreviousData(){
        Intent intent = getIntent();
        if(intent.hasExtra("mult_data")){
            multdata = (ArrayList<String>) intent.getSerializableExtra("mult_data");
            Log.d("LOG_TAG","SIZE: "+multdata.size());
            dataType = (ArrayList<String>) intent.getSerializableExtra("type");
            Log.d("LOG_TAG","Type: "+dataType);
            previewPresent = false;
        }
        else if(intent.hasExtra("previewUrl"))
        {
            previewImageURL = intent.getStringExtra("previewImageURL");
            previewTitle = intent.getStringExtra("previewTitle");
            previewDesc = intent.getStringExtra("previewDesc");
            previewUrl = intent.getStringExtra("previewUrl");
            previewPresent = true;
        }
        if(intent.hasExtra("taggedUsers")){
            UID = (ArrayList<String>) intent.getSerializableExtra("taggedUsers");
            if (UID != null) {
                Log.d("SelectClanTaggedUsers",UID.toString());
            }
        }
        postDescription = intent.getStringExtra("description");
    }
    private void displayUserTopics()
    {
        try {
            JSONArray data = LoggedInUser.userTopics;
//                        Log.d("LOG_TAG","DATA" + data.getString();
            Log.d("LOG_TAG", "DATA" + data.length());
            for (int i = 0; i < data.length(); i++) {
                no_topics = data.length();
                if (!(data.getString(i).equals("null"))) {

                    JSONObject name = new JSONObject(data.getString(i));
                    if(name.has("topic_name")) {
                        Log.d("LOG_TAG", "DATAA " + name.getString("topic_name"));
                        topicName.add(name.getString("topic_name"));
                    }
                    else if (name.has("name"))
                    {
                        Log.d("LOG_TAG", "DATAA " + name.getString("name"));
                        topicName.add(name.getString("name"));
                    }
                }
            }
            arrayAdapter = new ClanArrayAdapter(getApplicationContext(), R.layout.layout_clan_list
                    , topicName);
            listView.setAdapter(arrayAdapter);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
    }

    private void addPost(){
        try {
            String url = BASE_URL + "/api/post/add";
            JSONObject postObj = new JSONObject();
            JSONArray media = new JSONArray();
            Log.d("LOG_DATA", "POST JSON " + postObj.toString());
            if(!previewPresent) {
                for (int i = 0; i < multdata.size(); i++) {
                    JSONObject tempObj = new JSONObject();
                        tempObj.put("loc", multdata.get(i));
                        tempObj.put("kind", dataType.get(i));
                    media.put(tempObj);
                    Log.d("LOG_DATA", "Media JSON " + media.toString());
                }
            }
            else
            {
                JSONObject tempObj = new JSONObject();
                tempObj.put("loc", previewImageURL);
                tempObj.put("kind", "preview");
                tempObj.put("previewTitle", previewTitle);
                tempObj.put("previewDesc", previewDesc);
                tempObj.put("previewUrl", previewUrl);
                media.put(tempObj);
                Log.d("LOG_DATA", "Media JSON " + media.toString());
            }
            JSONArray arr = new JSONArray();
            for (int i = 0; i < UID.size(); i++) arr.put(UID.get(i));
            postObj.put("media", media);
            Log.d("LOG_DATA", "POST JSON " + postObj.toString());

            JSONArray topics = new JSONArray();
            for (int i = 0; i < selectedTopic.size(); i++) {
                JSONObject temp = new JSONObject();
                temp.put("name", selectedTopic.get(i));
                topics.put(temp);
            }
            postObj.put("topics", topics);
            postObj.put("description", postDescription);
            postObj.put("title", "default");
            postObj.put("lang", "default");
            postObj.put("taggedUsers",arr);
            Log.d("LOG_DATA", "POST JSON --> " + postObj.toString());
            //startActivity(new Intent(getApplicationContext(), HomeFeed.class));


            OkHttpClient client = new OkHttpClient().newBuilder()
                    .build();
            MediaType mediaType = MediaType.parse("application/json");
            RequestBody body = RequestBody.create(mediaType, postObj.toString());
            Request request = new Request.Builder()
                    .post(body)
                    .url(url)
                    .method("POST", body)
                    .addHeader("Authorization", LoggedInUser.auth_token_global)
                    .addHeader("Content-Type", "application/json")
                    .build();

           Call call = client.newCall(request);
           call.enqueue(new Callback() {
               @Override
              public void onFailure(@NotNull Call call, @NotNull IOException e) {

               }

               @Override
               public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                   if (!response.isSuccessful()) {
                       // You can also throw your own custom exception
                       Log.i("Response ",response.toString());
                       throw new IOException("Unexpected code " + response);
                   }
                   else {
                       try {
                           String resp = response.body().string();
                           JSONObject result = new JSONObject(resp);
                           Log.d("LOG_DATA","Result : "+ result.toString());
//                           Log.d("LOG_DATA","JSON Array: "+result.getJSONArray("post"));
                           JSONArray topics = result.getJSONObject("post").optJSONArray("topics");
                           for(int i=0;i<topics.length();i++){
                                topicsN.add(topics.getJSONObject(i).getString("name"));
                                String rule = topics.getJSONObject(i).getString("allowPosts");
                                if(rule.equalsIgnoreCase("0")){
                                    rules.add("Posted");
                                }
                                else if(rule.equalsIgnoreCase("1")){
                                    rules.add("Post submitted for review");
                                }
                                else if(rule.equalsIgnoreCase("2")){
                                    rules.add("Only admin can post");
                                }
                                Log.d("LOG_DATA","Topic Name: "+ topics.getJSONObject(i).getString("name"));
                           }
                           Log.d("LOG_DATA","JSON Object: "+result.getJSONObject("post").getString("_id"));
//                           FirebaseMessaging.getInstance().subscribeToTopic("notification-upvote_recieved-"+result.getJSONObject("post").getString("_id"));
//                           FirebaseMessaging.getInstance().subscribeToTopic("notification-comment_recieved-"+result.getJSONObject("post").getString("_id"));
                           Log.d("LOG_DATA","notification-upvote_recieved-"+result.getJSONObject("post").getString("_id"));
                           createCustomDialog();
                           response.body().close();
                       } catch (JSONException e) {
                           e.printStackTrace();
                           Crashlytics.logException(e);
                       }
                   }
               }
           });

        }
        catch (Exception e){
            Log.e("LOG_DATA",e.getMessage());
            e.printStackTrace();
            Crashlytics.logException(e);
        }
    }

    private void createCustomDialog(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AlertDialog.Builder customAlert = new AlertDialog.Builder(selectClan.this);
                View view = getLayoutInflater().inflate(R.layout.rules_custom_dialog_layout,null);
                ListView listView = view.findViewById(R.id.rulesList);
                listView.setDivider(null);
                RulesArrayAdapter rulesArrayAdapter = new RulesArrayAdapter(getApplicationContext(),R.layout.rules_listview_layout,
                        topicsN,rules);
                listView.setAdapter(rulesArrayAdapter);
                customAlert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                customAlert.setView(view);
                final AlertDialog alertDialog = customAlert.create();
                alertDialog.show();
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        alertDialog.dismiss();
                        Intent intent = new Intent(selectClan.this, ProfilePage.class);
                        intent.putExtra("USER_ID", LoggedInUser.userId);
                        startActivity(intent);
                        finish();
                    }
                });
            }
        });
    }
}
