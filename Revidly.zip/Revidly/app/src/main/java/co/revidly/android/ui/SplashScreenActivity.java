package co.revidly.android.ui;

import com.crashlytics.android.BuildConfig;
import com.crashlytics.android.Crashlytics;
import com.crashlytics.android.core.CrashlyticsCore;
import com.jaeger.library.StatusBarUtil;

import org.json.JSONArray;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.provider.SyncStateContract;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import co.revidly.android.R;
import co.revidly.android.UserDetails;
import co.revidly.android.helpers.InternetConnector_Checker;
import io.fabric.sdk.android.Fabric;

/**
 * Created by navneet on 12/11/16.
 */

public class SplashScreenActivity extends Activity {

    ImageView imageView;
    ImageView background;
    ProgressDialog progressDialog;
    JSONArray topics;

    private final BroadcastReceiver internetConnector = new InternetConnector_Checker();

    private boolean checkOnPause = false;
    private static SplashScreenActivity mInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StatusBarUtil.setTransparent(this);
        setContentView(R.layout.splashscreenmaker);
        Fabric.with(this, new Crashlytics.Builder().core(new CrashlyticsCore.Builder().disabled(BuildConfig.DEBUG).build()).build());

        mInstance = this;

        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        this.registerReceiver(internetConnector, intentFilter);

        imageView = (ImageView) findViewById(R.id.imageView);
        background = (ImageView) findViewById(R.id.splashBackground);

        if (Utils.getAuthToken(this) != null) {
            UserDetails userDetails = new UserDetails(this, Utils.getAuthToken(this), true);
            userDetails.getUserDetails();
        }
        else
        {
            UserDetails userDetails = new UserDetails(this, null, false);
        }

        final Animation animation_2 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.rotate);
        final Animation animation_1 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.antirotate);
        final Animation animation_3 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.abc_fade_out);

        imageView.startAnimation(animation_2);
        animation_2.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView.startAnimation(animation_1);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView.startAnimation(animation_3);
                if(!UserDetails.userDetailsExecuted) {
                    Intent i = new Intent(getBaseContext(), HomeScreen_Activity.class);
                    startActivity(i);
                    overridePendingTransition(R.anim.slide_out_left, R.anim.slide_in_right);
                    finish();
                }

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        imageView = null;
        background = null;
        if(checkOnPause == false)
            unregisterReceiver(internetConnector);
        Runtime.getRuntime().gc();

    }
    protected void onResume() {
        super.onResume();
        //initExoPlayer();
        Log.d("HomeActivity ", "onResume");
        //activityResumed();
        //FullscreenActivity.getInstance().setConnectivityListener(this);
        //if (checkOnPause)
        if (true)
        {
            IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
            this.registerReceiver(internetConnector, intentFilter);
            checkOnPause = false;
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("HomeActivity ", "onPause");
        checkOnPause = true;
        unregisterReceiver(internetConnector);
    }
    public void displayInternetDialogue(){
        try {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();

            alertDialog.setTitle("No Conncetion");
            alertDialog.setMessage("Internet not available, Cross check your internet connection and try again");
            alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Log.d("FullScreenActivity", "I am finishing");
                    finish();
                    //new FullscreenActivity().isOnline();
                }
            });

            alertDialog.show();
        } catch (Exception e) {
            Crashlytics.logException(e);
            Log.d(SyncStateContract.Constants._ID, "Show Dialog: " + e.getMessage());
        }
    }
    public static synchronized SplashScreenActivity getInstance() {
        return mInstance;
    }


}