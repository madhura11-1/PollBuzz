package co.revidly.android;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import co.revidly.android.helpers.LoggedInUser;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.crashlytics.android.Crashlytics;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.jaeger.library.StatusBarUtil;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import static co.revidly.android.helpers.Config.BASE_URL;

public class DescribedPostsActivity extends AppCompatActivity {


    ArrayList<Post> postArrayList = new ArrayList<>();
    RecyclerView recyclerView;
    TextView c_n, p_d, down, up, username;
    ImageButton shrd, dwn, upv;
    static int count = 0;
    static String fid = "";
    ImageView prpic, comment;
    Context mContext;
    String userId;
    JSONArray topicsArray;
    Boolean iscomment;
    String jasonstring,post_action;
    String postID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        count = 0;
        mContext = getApplicationContext();
        StatusBarUtil.setTransparent(this);
        setContentView(R.layout.activity_described_posts);
        StatusBarUtil.setColor(this, Color.BLACK, 2);
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        ConstraintLayout flo = findViewById(R.id.constraintLayout);
        flo.setPadding(0, result, 0, 0);

        username = findViewById(R.id.user_name);
        c_n = findViewById(R.id.community_name);
        dwn = findViewById(R.id.downvote);
        upv = findViewById(R.id.upvote);
        up = findViewById(R.id.nupv);
        down = findViewById(R.id.ndnv);
        shrd = findViewById(R.id.share);
        p_d = findViewById(R.id.answer);
        comment = findViewById(R.id.comment);
        prpic = findViewById(R.id.propic);
        Intent i = getIntent();
        postArrayList = new ArrayList<>();
        if(i.hasExtra("jason_pos")){
            jasonstring = String.valueOf(i.getStringExtra("jason_pos"));
            post_action = String.valueOf(i.getStringExtra("post_action"));
            setAllData();
        }
        else{
            postID = i.getStringExtra("postID");

            Log.d("LOG_MSG","Post Id: "+postID);
            getPostData();
            if(i.hasExtra("Comment_Notif")){
                fid = postID;
                CommentSheet cfrag = new CommentSheet();
                cfrag.show(getSupportFragmentManager(), "Comments");
            }
        }
        iscomment=i.getBooleanExtra("iscomment",Boolean.FALSE);
    }
    @Override
    public void onBackPressed() {

        finish();
    }
    void setListeners()
    {
        prpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {

                    Log.d("DescribedPostActivity->", "propic clicked");

                    Intent intent = new Intent(mContext, ProfilePage.class);
                    intent.putExtra("USER_ID", userId);
                    mContext.startActivity(intent);
                    finish();
                } catch (Exception e) {
                    Crashlytics.logException(e);
                    e.printStackTrace();
                }

            }
        });
        username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Log.d("DescribedPostActivity->", "username clicked");

                    Intent intent = new Intent(mContext, ProfilePage.class);
                    intent.putExtra("USER_ID", userId);
                    mContext.startActivity(intent);
                    finish();
                } catch (Exception e) {
                    Crashlytics.logException(e);
                    e.printStackTrace();
                }
            }
        });
        c_n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("DescribedPostActivity->", "community clicked");

                Intent intent = new Intent(mContext, CommunityFeed.class);
                intent.putExtra("COMMUNITY_TOKEN", topicsArray.toString());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(intent);
            }
        });
    }

    private void setAllData(){
        Handler mainHandler;
        mainHandler = new Handler(getApplicationContext().getMainLooper());
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                int upvotes = 0, downvotes = 0;
                JSONObject jobj = null;
                try {
                    Log.d("LOG_MSG","JSON: "+jasonstring);
                    jobj = new JSONObject(jasonstring);
                    final String shre = jobj.getString("_id");
                    userId = jobj.getString("userId");
                    username.setText(jobj.getString("userName"));
                    final String profile_pic = BASE_URL + "/app/profilePic/" +  userId + ".jpg";
                    JSONArray mediaarray = jobj.getJSONArray("media");
                    JSONArray community = jobj.getJSONArray("topics");
                    topicsArray = jobj.getJSONArray("topics");
                    if (jobj.has("upvotes"))
                        upvotes = jobj.getInt("upvotes");
                    else
                        upvotes = 0;

                    if (jobj.has("downvotes"))
                        downvotes = jobj.getInt("downvotes");
                    else
                        downvotes = 0;

                    String comm_name = "";


                    if (profile_pic != "null" && !profile_pic.isEmpty()) {
                        Glide.with(mContext)
                                .load(profile_pic)
                                .placeholder(R.drawable.propic1)
                                .into(prpic);
//                Picasso.get()
                        //                        .load(profile_pic)
                        //                        .into(prpic);
                        prpic.setPadding(0, 0, 0, 0);
                    }
                    shrd.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            HomeFeed.getPostFeedClass().shareOnClick(shre);
                        }
                    });
                    comment.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            fid = shre;
                            count = 1;
                            Log.d("described_post --> ", "Comment postId " + shre);
                            CommentSheet cfrag = new CommentSheet();
                            cfrag.show(getSupportFragmentManager(), "Comments");
                            //HomeFeed.getPostFeedClass().commentOnClick(shre);
                        }
                    });
                    for (int k = 0; k < community.length(); k++) {
                        if (k == 0) {
                            comm_name += community.getJSONObject(k).getString("name");
                        } else
                            comm_name += ", " + community.getJSONObject(k).getString("name");

                    }
                    c_n.setText(comm_name);

                    setListeners();

                    String postdesc = jobj.getString("description");
                    if (postdesc.length() > 0) {
                        p_d.setMovementMethod(new ScrollingMovementMethod());
                        p_d.setText(postdesc);
                    }
                    if (mediaarray.length() == 0) {


                    } else if (mediaarray.length() == 1) {
                        String media_url = mediaarray.getJSONObject(0).getString("loc");
                        String media_kind = mediaarray.getJSONObject(0).getString("kind");
                        Post post;
                        if(media_kind.equals("image")) {
                            post = new Post(media_url, media_kind);
                        }
                        else
                        {
                            post = new Post(media_url, media_kind, mediaarray.getJSONObject(0).getString("previewUrl"),
                                    mediaarray.getJSONObject(0).getString("previewTitle"),
                                    mediaarray.getJSONObject(0).getString("previewDesc"));
                        }
                        postArrayList.add(post);
                    } else {
                        for (int k = 0; k < mediaarray.length(); k++) {
                            String media_url = mediaarray.getJSONObject(k).getString("loc");
                            String media_kind = mediaarray.getJSONObject(k).getString("kind");
                            Post post = new Post(media_url, media_kind);
                            postArrayList.add(post);
                        }
                    }
                    if(iscomment) {
                        fid = shre;
                        CommentSheet cfrag = new CommentSheet();
                        cfrag.show(getSupportFragmentManager(), "Comments");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                recyclerView = findViewById(R.id.postRecyclerView);
                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                PostAdapter postAdapter = new PostAdapter(getApplicationContext(), postArrayList);
                recyclerView.setAdapter(postAdapter);
                JSONObject jpost = null;
                //        Remove bottom comments when described post has upvote and downvote

//        try {
                //            jpost = new JSONObject(post_action);
                //        } catch (JSONException e) {
                //            e.printStackTrace();
                //        }
                int user_vot = 0;
                //        if (jpost.optBoolean("upvote")) {
                user_vot = 1;
                //        } else if (jpost.optBoolean("downvote")) {
                user_vot = -1;
                //        }
                final int finalDownvotes = downvotes;
                final int finalUpvotes = upvotes;
                final int user_vote = user_vot;
                up.setText(String.format("%d Upvotes", finalUpvotes));
                down.setText(String.format("%d Downvotes", finalDownvotes));
                if (user_vote == 1) {
                    //holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                    upv.setImageResource(R.drawable.home_upvote_clicked);
                    dwn.setImageResource(R.drawable.home_downvote);
                    upv.setBackgroundResource(R.drawable.votes_pressed);
                    dwn.setBackgroundResource(R.drawable.votes_unpressed);

                } else if (user_vote == -1) {
                    //holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                    dwn.setImageResource(R.drawable.home_downvote_clicked);
                    upv.setImageResource(R.drawable.home_upvote);
                    upv.setBackgroundResource(R.drawable.votes_unpressed);
                    dwn.setBackgroundResource(R.drawable.votes_pressed);

                } else {
                    dwn.setImageResource(R.drawable.home_downvote);
                    upv.setImageResource(R.drawable.home_upvote);
                    upv.setBackgroundResource(R.drawable.votes_unpressed);
                    dwn.setBackgroundResource(R.drawable.votes_unpressed);
                }

                final int finalDownvotes1 = downvotes;
                final int finalUpvotes1 = upvotes;
                final JSONObject finalJobj = jobj;
                upv.setOnClickListener(new View.OnClickListener() {
                    int user_v = user_vote;
                    int downv = finalDownvotes1;
                    int upvo = finalUpvotes1;

                    @Override
                    public void onClick(View view) {
                        if (user_v == 0) {
                            user_v = 1;
                            upvo += 1;
                        } else if (user_v == -1) {
                            user_v = 1;
                            downv -= 1;
                            upvo += 1;
                        } else if (user_v ==1) {
                            user_v = 0;
                            upvo -= 1;
                        }
                        up.setText(String.format("%d Upvotes", upvo));
                        down.setText(String.format("%d Downvotes", downv));
                        try {
                            finalJobj.put("upvotes",upvo);
                            finalJobj.put("downvotes",downv);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (user_v == 1) {
                            //holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                            upv.setImageResource(R.drawable.home_upvote_clicked);
                            dwn.setImageResource(R.drawable.home_downvote);
                            upv.setBackgroundResource(R.drawable.votes_pressed);
                            dwn.setBackgroundResource(R.drawable.votes_unpressed);

                        } else if (user_v == -1) {
                            //holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                            dwn.setImageResource(R.drawable.home_downvote_clicked);
                            upv.setImageResource(R.drawable.home_upvote);
                            upv.setBackgroundResource(R.drawable.votes_unpressed);
                            dwn.setBackgroundResource(R.drawable.votes_pressed);

                        } else {
                            dwn.setImageResource(R.drawable.home_downvote);
                            upv.setImageResource(R.drawable.home_upvote);
                            upv.setBackgroundResource(R.drawable.votes_unpressed);
                            dwn.setBackgroundResource(R.drawable.votes_unpressed);
                        }
                    }
                });
                dwn.setOnClickListener(new View.OnClickListener() {
                    int user_v = user_vote;
                    int downv = finalDownvotes1;
                    int upvo = finalUpvotes1;

                    @Override
                    public void onClick(View view) {
                        if (user_v == 0) {
                            user_v = -1;
                            downv += 1;
                        } else if (user_v == 1) {
                            user_v = -1;
                            downv += 1;
                            upvo -= 1;
                        } else if (user_v == -1) {
                            user_v = 0;
                            downv -= 1;
                        }
                        up.setText(String.format("%d Upvotes", upvo));
                        down.setText(String.format("%d Downvotes", downv));
                        try {
                            finalJobj.put("upvotes",upvo);
                            finalJobj.put("downvotes",downv);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (user_v == 1) {
                            //holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                            upv.setImageResource(R.drawable.home_upvote_clicked);
                            dwn.setImageResource(R.drawable.home_downvote);
                            upv.setBackgroundResource(R.drawable.votes_pressed);
                            dwn.setBackgroundResource(R.drawable.votes_unpressed);

                        } else if (user_v == -1) {
                            //holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                            dwn.setImageResource(R.drawable.home_downvote_clicked);
                            upv.setImageResource(R.drawable.home_upvote);
                            upv.setBackgroundResource(R.drawable.votes_unpressed);
                            dwn.setBackgroundResource(R.drawable.votes_pressed);

                        } else {
                            dwn.setImageResource(R.drawable.home_downvote);
                            upv.setImageResource(R.drawable.home_upvote);
                            upv.setBackgroundResource(R.drawable.votes_unpressed);
                            dwn.setBackgroundResource(R.drawable.votes_unpressed);
                        }
                    }
                });
            }
        });
    }

    private void getPostData(){
        String url = BASE_URL + "/api/post/getPostById/" + postID;
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Authorization", LoggedInUser.auth_token_global)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("LOG_MSG",e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if(!response.isSuccessful()){
                    Log.e("LOG_MSG","Response Unsuccessfull");
                }
                else{
                    try{
                        String resp = response.body().string();
                        JSONObject resultObj = new JSONObject(resp);
                        Log.d("LOG_MSG","DATA: "+resultObj);
                        Log.d("LOG_MSG","Data: "+resultObj.optJSONObject("post"));
                        jasonstring = resultObj.optJSONObject("post").toString();
                        post_action = resultObj.optJSONObject("postAction").toString();
                        Log.d("LOG_MSG","Data: "+post_action);
                        setAllData();
                    }
                    catch (Exception e){
                        Log.e("LOG_MSG",e.getMessage());
                        e.printStackTrace();                    }


                }
            }
        });
    }


}

//        Post post = new Post("http://i.imgur.com/DvpvklR.png","image");
//        postArrayList.add(post);
//        Uri uri = Uri.parse("https://dev-api.revidly.co/media/VIDEO_2_2_111_232515-1578765567004.mp4");
//        post = new Post(String.valueOf(uri),"video");
//        postArrayList.add(post);
//        postArrayList.add(new Post("https://cdn.pixabay.com/photo/2015/03/26/09/41/chain-690088_1280.jpg","image"));
//        postArrayList.add(new Post("https://www.radiantmediaplayer.com/media/bbb-360p.mp4","video"));