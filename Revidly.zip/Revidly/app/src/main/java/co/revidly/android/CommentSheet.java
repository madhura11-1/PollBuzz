package co.revidly.android;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.firebase.messaging.FirebaseMessaging;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.crashlytics.android.Crashlytics;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

public class CommentSheet extends BottomSheetDialogFragment implements TagUserListAdapter.AdapterCallBack {
    RecyclerView recyclerView_User;
    ShimmerRecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    LinearLayoutManager layoutmanager_User;
    private commentlistadapter mAdapter;
    TagUserListAdapter userAdapter;
    List<JSONObject> mlist = new ArrayList<>();
    String auth_token_local;
    public static String comment_ans_id;
    ProgressDialog progressDialog;
    FirebaseAnalytics mFirebaseAnalytics;
    Boolean flag1 = false, flag2 = false;
    Timer timer;
    private static String TAG = "TagActivityComment";
    JSONArray data = new JSONArray();
    ArrayList<FollowerList> users = new ArrayList<>();
    String name = "";
//    int index = -1;
    EditText addcomm;
//    String text = "";
    List<String> names = new ArrayList<>();
    List<String> UID = new ArrayList<>();
    Call call;
    String authorId = "";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.AppBottomSheetDialogTheme);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(getContext());
        mFirebaseAnalytics.setCurrentScreen(getActivity(), "CommentSheet", null);

        auth_token_local = LoggedInUser.auth_token_global;
        if (getContext() instanceof HomeFeed || getContext() instanceof CommunityFeed || getContext() instanceof ProfilePage) {

            comment_ans_id = PostFeed.commans_id;
        } else if (getContext() instanceof DescribedPostsActivity) {
            comment_ans_id = DescribedPostsActivity.fid;
            Log.d("DivyankisTesting", comment_ans_id);
        } else {

            comment_ans_id = "";
        }

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                FrameLayout bottomSheet = d.findViewById(R.id.design_bottom_sheet);
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) bottomSheet.getParent();
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
                bottomSheetBehavior.setPeekHeight(bottomSheet.getHeight());
                coordinatorLayout.getParent().requestLayout();
            }
        });
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getDialog().setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                BottomSheetDialog d = (BottomSheetDialog) dialog;

                FrameLayout bottomSheet = d.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });


    }

    @SuppressLint({"ClickableViewAccessibility", "RestrictedApi"})
    @Override
    public void setupDialog(@NonNull final Dialog dialog, final int style) {
        super.setupDialog(dialog, style);
        final View view = LayoutInflater.from(getContext()).inflate(R.layout.comment_sheet, null);
        dialog.setContentView(view);

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                //if(((FullscreenActivity) getContext()).vid!=null) ((FullscreenActivity) getContext()).vid.start();
            }
        });
        recyclerView = view.findViewById(R.id.commcomments);
        recyclerView_User = view.findViewById(R.id.taguser);
        layoutManager = new LinearLayoutManager(getActivity());
        layoutmanager_User = new LinearLayoutManager(getActivity());
        layoutmanager_User.setOrientation(RecyclerView.VERTICAL);
//        layoutmanager_User.setReverseLayout(true);
        layoutmanager_User.setSmoothScrollbarEnabled(true);
        layoutmanager_User.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView_User.setLayoutManager(layoutmanager_User);
        userAdapter = new TagUserListAdapter(users, getContext(), CommentSheet.this);
        recyclerView.setAdapter(mAdapter);
        recyclerView.showShimmerAdapter();
        recyclerView_User.setAdapter(userAdapter);

        //getcomments(comment_ans_id);
        getPostComments(comment_ans_id);
        TextView no_of_comm = view.findViewById(R.id.commtitle);
        ImageButton close = view.findViewById(R.id.commclose);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "commentSheetClosed");
                mFirebaseAnalytics.logEvent("commentSheetClosed", bundle);
                if (FullscreenActivity.auth_token != null) {
                    FullscreenActivity.getInstance().resumePlayer();
                    FullscreenActivity.getInstance().youTubePlayer.play();
                }
            }
        });


        addcomm = view.findViewById(R.id.commaddcomm);
        addcomm.setMovementMethod(new ScrollingMovementMethod());
        try {
            addcomm.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                while (addcomm.canScrollVertically(1)) {
//                    addcomm.scrollBy(0, 10);
//                }

//                    if (line_count != addcomm.getLineCount()) {
//                        addcomm.setLines(1);
//                        if (addcomm.getLineCount() < 5) {
//                            addcomm.setLines(addcomm.getLineCount());
//                        } else {
//                            addcomm.setLines(5);
//                        }
//                    }
                    if (!users.isEmpty()) {
                        users.clear();
                        userAdapter.notifyDataSetChanged();
                        flag1 = false;
                        flag2 = false;
                    }
                    int cursorPos = addcomm.getSelectionStart();
                    Log.d("COMMENTSHEETFEEDPOS", String.valueOf(cursorPos));
                    if (cursorPos != -1) {
                        String selectedWord = "", prevWord = "";
                        int length_temp = 0;

                        for (String currentWord : charSequence.toString().split(" |\n")) {
                            length_temp += currentWord.length() + 1;
                            if (length_temp > cursorPos) {
                                selectedWord = currentWord;
                                break;
                            } else prevWord = currentWord;
                        }
                        Log.d("COMMENTSHEETFEED", prevWord + " " + selectedWord);
                        if (selectedWord.trim().startsWith("@")) {
//                            index = charSequence.toString().length();
                            flag1 = true;
                            name = "";
//                            text = charSequence.toString().substring(0, index - 1);
                        } else if (prevWord.trim().startsWith("@")) {
//                            index = charSequence.toString().length();
                            flag2 = true;
                            name = "";
//                            text = charSequence.toString().substring(0, index - 1);
                        } else {
                            flag1 = false;
                            flag2 = false;
                            users.clear();
                            userAdapter.notifyDataSetChanged();
                            view.findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
//                        view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                        }
                        try {
                            if (flag1) {
                                if (selectedWord.length() > 0) {
                                    Log.d("TagUsers", users.toString());
                                    String searchUrl = BASE_URL + "/api/user/search";
                                    view.findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
//                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                    if (timer != null) {
                                        timer.cancel();
                                    }
                                    if (call != null) call.cancel();
                                    OkHttpClient client = new OkHttpClient().newBuilder()
                                            .build();
                                    MediaType mediaType = MediaType.parse("application/json");
                                    Log.d("SelectedWordChange", selectedWord);
                                    RequestBody body = RequestBody.create(mediaType, "{\n\t\"text\": \"" + selectedWord.substring(1) + "\"\n}");
                                    Log.d("SelectedWordChange", "{\n\t\"text\": \"" + selectedWord.substring(1) + "\"\n}");
                                    Request request = new Request.Builder()
                                            .url(searchUrl)
                                            .method("POST", body)
                                            .addHeader("Content-Type", "application/json")
                                            .addHeader("Authorization", Utils.getAuthToken(getContext()))
                                            .build();
                                    call = client.newCall(request);
                                    call.enqueue(new Callback() {
                                        @Override
                                        public void onFailure(@NotNull Call call, @NotNull IOException e) {

                                        }

                                        @Override
                                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                            if (response.isSuccessful()) {
                                                try {
                                                    String resp = response.body().string();
//                                            Log.d(TAG, "Response body: " + resp);
                                                    JSONObject data1 = new JSONObject(resp);
                                                    data = data1.getJSONArray("users");
//                                            Log.d(TAG, "dataBody:" + data);
                                                    String avatar, name, userId;
//                                            Log.d(TAG, "onResponse: " + data.length());
                                                    for (int i = 0; i < data.length(); i++) {
                                                        JSONObject object = data.getJSONObject(i);
                                                        avatar = object.getString("avatar");
//                                                Log.d(TAG, "FollowerAvatar: " + avatar);
                                                        name = object.getString("name");
                                                        userId = object.getString("_id");
//                                                Log.d(TAG, "FollowerName: " + name);
                                                        users.add(new FollowerList(avatar, name, userId));
                                                    }
                                                    if (getActivity() != null)
                                                        getActivity().runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                if (!users.isEmpty()) {
                                                                    Log.d("TagUser", users.toString());
//                                                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                                                    view.findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
                                                                    userAdapter.notifyDataSetChanged();
                                                                } else {
                                                                    view.findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
//                                                            view.findViewById(R.id.noResult).setVisibility(View.VISIBLE);
                                                                }

                                                            }
                                                        });
                                                    response.body().close();
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        }
                                    });
                                } else {
                                    if (!users.isEmpty()) {
                                        users.clear();
                                        userAdapter.notifyDataSetChanged();
                                    }
                                }
                            } else if (flag2) {
                                if ((prevWord.length() + selectedWord.length()) > 0) {
                                    Log.d("TagUsers", users.toString());
                                    String searchUrl = BASE_URL + "/api/user/search";
                                    view.findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
//                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                    if (timer != null) {
                                        timer.cancel();
                                    }
                                    if (call != null) call.cancel();
                                    OkHttpClient client = new OkHttpClient().newBuilder()
                                            .build();
                                    MediaType mediaType = MediaType.parse("application/json");
                                    Log.d("SelectedWordChange", selectedWord);
                                    if (prevWord.length() > 1) {
                                        RequestBody body = RequestBody.create(mediaType, "{\n\t\"text\": \"" + prevWord.substring(1) + " " + selectedWord + "\"\n}");
                                        Log.d("SelectedWordChange", "{\n\t\"text\": \"" + prevWord.substring(1) + " " + selectedWord + "\"\n}");
                                        Request request = new Request.Builder()
                                                .url(searchUrl)
                                                .method("POST", body)
                                                .addHeader("Content-Type", "application/json")
                                                .addHeader("Authorization", Utils.getAuthToken(getContext()))
                                                .build();
                                        call = client.newCall(request);
                                        call.enqueue(new Callback() {
                                            @Override
                                            public void onFailure(@NotNull Call call, @NotNull IOException e) {

                                            }

                                            @Override
                                            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                                if (response.isSuccessful()) {
                                                    try {
                                                        String resp = response.body().string();
//                                            Log.d(TAG, "Response body: " + resp);
                                                        JSONObject data1 = new JSONObject(resp);
                                                        data = data1.getJSONArray("users");
//                                            Log.d(TAG, "dataBody:" + data);
                                                        String avatar, name, userId;
//                                            Log.d(TAG, "onResponse: " + data.length());
                                                        for (int i = 0; i < data.length(); i++) {
                                                            JSONObject object = data.getJSONObject(i);
                                                            avatar = object.getString("avatar");
//                                                Log.d(TAG, "FollowerAvatar: " + avatar);
                                                            name = object.getString("name");
                                                            userId = object.getString("_id");
//                                                Log.d(TAG, "FollowerName: " + name);
                                                            users.add(new FollowerList(avatar, name, userId));
                                                        }
                                                        if (getActivity() != null)
                                                            getActivity().runOnUiThread(new Runnable() {
                                                                @Override
                                                                public void run() {
                                                                    if (!users.isEmpty()) {
                                                                        Log.d("TagUser", users.toString());
//                                                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                                                        view.findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
                                                                        userAdapter.notifyDataSetChanged();
                                                                    } else {
                                                                        view.findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
//                                                            view.findViewById(R.id.noResult).setVisibility(View.VISIBLE);
                                                                    }

                                                                }
                                                            });
                                                        response.body().close();
                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                            }
                                        });
                                    }
                                } else {
                                    if (!users.isEmpty()) {
                                        users.clear();
                                        userAdapter.notifyDataSetChanged();
                                    }
                                }
                            }
                        }catch (Exception e){
                            FirebaseCrashlytics.getInstance().log(e.getMessage());
                        }
                    }
                }

                @Override
                public void afterTextChanged(Editable editable) {
                    String comment = editable.toString();
                    comment = comment.replace("\n", "\n ");
                    String[] arr = comment.split(" ");
                    CustomStyleSpan[] styles = editable.getSpans(0, comment.length(), CustomStyleSpan.class);
                    List<String> namesTemp = new ArrayList<>();
                    List<String> UIDTemp = new ArrayList<>();
                    for (int i = 0; i < arr.length - 1; i++) {
                        if (arr[i].trim().startsWith("@")) {
                            String temp = (arr[i] + " " + arr[i + 1]).trim();
                            Log.d("CommentSheetTemp", i + " " + temp + " " + names.toString());
                            if (names.contains(temp)) {
                                int index = names.indexOf(temp);
                                Log.d("CommentSheetTemp", String.valueOf(index));
                                namesTemp.add(names.get(index));
                                names.remove(index);
                                names.add(index, null);
                                UIDTemp.add(UID.get(index));
                            }
                        }
                    }
                    for (int i = 0; i < names.size(); i++) {
                        if (names.get(i) != null && i < styles.length) {
                            Log.d("CommentSheetTemp", names.get(i));
                            editable.removeSpan(styles[i]);
                        }
                    }
                    names.clear();
                    names.addAll(namesTemp);
                    UID.clear();
                    UID.addAll(UIDTemp);
                    timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            if (getActivity() != null)
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                    }
                                });
                        }
                    }, 600);
                }
            });
            addcomm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addcomm.requestFocus();

                }
            });
        } catch (Exception e) {
            Crashlytics.log(e.toString());
        }
        ImageButton send = view.findViewById(R.id.commsend);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (addcomm.getText().toString().trim().equals(""))
                    Toast.makeText(getContext(), "Enter a comment to post", Toast.LENGTH_SHORT).show();
                else {
                    //addcomment(comment_ans_id,addcomm.getText().toString().trim());
                    addPostComment(comment_ans_id, addcomm.getText().toString().trim(), UID);
                    addcomm.setText("");
                    Bundle bundle = new Bundle();
                    bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "commentAdded");
                    mFirebaseAnalytics.logEvent("commentAdded", bundle);
                }
            }
        });


    }

    void getPostComments(final String ansid) {

        Log.d("UIDCHECKING", ansid);
        //progressDialog = ProgressDialog.show(this.getContext(),
        //      "Loading Comments",
        //    "Please Wait...");

        OkHttpClient client = new OkHttpClient();

//        Handler mainHandler;
//        mainHandler = new Handler(getContext().getMainLooper());
//        mainHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                progressDialog = ProgressDialog.show(getContext(),
//                        "Loading Comments..",
//                        "\nPlease Wait...");
//            }
//        });

        String url = BASE_URL + "/api/comment/get/" + ansid;
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("Authorization", auth_token_local)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "e92938cb-fa26-4406-aaa9-3cf01a5d7124,abae2026-9ac9-4b79-bb2c-fde95d26b5e6")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();
        Log.d("CommentSheet -->", "Link " + url);
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
                Handler mainHandler;
                if (getDialog() != null) {
                    mainHandler = new Handler(getDialog().getContext().getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {

                            //mShimmerFrameLayout.stopShimmer();
                            //mShimmerFrameLayout.setVisibility(View.GONE);
                            try {
//                            progressDialog.dismiss();
                                recyclerView.hideShimmerAdapter();
                                final AlertDialog.Builder builder = new AlertDialog.Builder(getDialog().getContext());
                                builder.setTitle("Something\'s Wrong");
                                builder.setMessage("Something does not seem to be right. If the problem continues, close the app and start it again.");
                                builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //Click button action
                                        dialog.dismiss();
                                        getPostComments(ansid);
                                    }
                                });
                                builder.setCancelable(false);
                                builder.show();
                            } catch (Exception e) {
                                Log.e("LOG_DATA", e.getMessage());
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    try {
//                        progressDialog.dismiss();
                        Handler mainHandler;
                        if (getDialog() != null) {
                            mainHandler = new Handler(getDialog().getContext().getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    recyclerView.hideShimmerAdapter();
                                    final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                                    builder.setTitle("Something\'s Wrong");
                                    builder.setMessage("Something does not seem to be right. If the problem continues, close the app and start it again.");
                                    builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            //Click button action
                                            dialog.dismiss();
                                            getPostComments(ansid);
                                        }
                                    });
                                    builder.setCancelable(false);
                                    builder.show();
                                }
                            });
                        }
                    } catch (Exception e) {
                        Log.e("LOG_DATA", e.getMessage());
                        e.printStackTrace();
                    }
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp = response.body().string();
                    try {
                        //JSONObject result=new JSONObject(response);
                        JSONObject result = new JSONObject(resp);
                        //JSONObject com = new JSONObject(result.get(0).toString());
                        Log.d("LOG_DATAaa", "Error: " + result.getString("err"));
                        if (result.getString("err").equals("true")) {
                            Handler mainHandler;
                            if (getDialog() != null) {
                                mainHandler = new Handler(getDialog().getContext().getMainLooper());
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        recyclerView.hideShimmerAdapter();
                                        //mShimmerFrameLayout.stopShimmer();
                                        //mShimmerFrameLayout.setVisibility(View.GONE);
                                        try {
//                                        progressDialog.dismiss();
                                            final AlertDialog.Builder builder = new AlertDialog.Builder(getDialog().getContext());
                                            builder.setTitle("Something\'s Wrong");
                                            builder.setMessage("Something does not seem to be right. If the problem continues, close the app and start it again.");
                                            builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    //Click button action
                                                    dialog.dismiss();
                                                    getPostComments(ansid);
                                                }
                                            });
                                            builder.setCancelable(false);
                                            builder.show();
                                        } catch (Exception e) {
                                            Log.e("LOG_DATA", e.getMessage());
                                            e.printStackTrace();
                                        }
                                    }
                                });
                            }
                        }
                        authorId = result.optString("postAuthor");
                        Handler mainHandler = null;
                        if (getContext() != null) {
                            mainHandler = new Handler(getContext().getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    //progressDialog.dismiss();
                                    mAdapter = new commentlistadapter(getContext(), mlist, authorId);
                                    recyclerView.setAdapter(mAdapter);
                                }
                            });
                        }
                        final JSONArray comments = result.getJSONArray("comments");
                        Log.i("Comments array ", comments.toString());
                        if (comments.length() != 0)
                            Log.i("Comment ", new JSONObject(comments.get(0).toString()).getString("content"));
                        for (int i = 0; i < comments.length(); i++) {
                            final JSONObject obj = new JSONObject(comments.get(i).toString());
                            try {
                                mlist.add(obj);
                                Log.i("Comm id",obj.getString("_id"));
                                Log.d("Post id",obj.getString("postId"));
//                                FirebaseMessaging.getInstance().subscribeToTopic("notification-comment_recieved-"+obj.getString("postId"));
                                //Log.i("Ques id",obj.getString("ques_id"));
                                Log.i("Username ", obj.getString("userName"));
                                Log.i("Comment ", obj.getString("content"));
                                Log.i("date ", obj.getString("updatedAt"));
                                //Log.i("Auth_token----->", auth_token_local);
                            } catch (NullPointerException e) {
                                Log.i("Null exception", e.getStackTrace().toString());
                                Crashlytics.logException(e);
                            }
                        }

                       /* if(progressDialog != null && progressDialog.isShowing())
                            progressDialog.dismiss();*/
                        if (mainHandler != null) {
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    recyclerView.hideShimmerAdapter();
                                    //progressDialog.dismiss();
                                    mAdapter.notifyDataSetChanged();
                                    TextView no_of_comm = getDialog().findViewById(R.id.commtitle);
                                    no_of_comm.setText(String.format("%d Comments", comments.length()));
                                    //System.out.println(mlist+"    "+mAdapter.mData.get(0).comment);

                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                    Log.i("Response:", response.toString());
                    Log.i("Response body:", response.body().toString());
                    Log.i("Response String: ", resp);
                    Log.i("Response message:", response.message());
                    //mAdapter1.notifyDataSetChanged();
                    response.body().close();
                }
            }
        });
    }

    void addPostComment(final String ans_id, String comment, List<String> UID) {
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/api/comment/add";
        JSONArray arr = new JSONArray();
        for (int i = 0; i < UID.size(); i++) arr.put(UID.get(i));
        JSONObject commentObject = new JSONObject();
        try {
            commentObject.put("postId", ans_id);
            commentObject.put("text", comment);
            //comment out below 2 lines when there is no need for front end to send these details to backend
            commentObject.put("userName", LoggedInUser.userName);
            commentObject.put("profilePicUrl", LoggedInUser.userProfileImage);
            commentObject.put("taggedUsers", arr);
            Log.d("UIDCHECKING", commentObject.toString());
        } catch (Exception e) {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, commentObject.toString());
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", auth_token_local)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "06079cfc-257c-4ce6-99ca-e174654a6543,c644e0ef-6acb-4b07-9893-4295c2a96ca3")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "94")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("FailedCommenting : ", e.getStackTrace().toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                } else {
                    Handler mainHandler;
                    try {
                        mainHandler = new Handler(getContext().getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                mlist.clear();
                                getPostComments(ans_id);
                                System.out.println(mlist);
                                Toast.makeText(getContext(), "Comment posted", Toast.LENGTH_SHORT).show();
                            }
                        });
                        response.body().close();
                    } catch (NullPointerException e) {
                        Log.i("Null exception", e.getStackTrace().toString());
                        Crashlytics.logException(e);
                    }


//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", response.body().string());
//                    Log.i("Response message:", response.message());
                }
            }
        });

    }

    void getcomments(String ansid) {
        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "/api/app/commentsOfAnswer?ans_id=" + ansid;
        Request request = new Request.Builder()
                .url(url)
                .get()
                .addHeader("Authorization", auth_token_local)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "e92938cb-fa26-4406-aaa9-3cf01a5d7124,abae2026-9ac9-4b79-bb2c-fde95d26b5e6")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp = response.body().string();
                    try {
                        //JSONObject result=new JSONObject(response);
                        JSONArray result = new JSONArray(resp);
                        JSONObject com = new JSONObject(result.get(0).toString());
                        final JSONArray comments = com.getJSONArray("comments");
                        Log.i("Comments array ", comments.toString());
                        Log.i("Comment ", new JSONObject(comments.get(0).toString()).getString("comment_desc"));
                        for (int i = 0; i < comments.length(); i++) {
                            final JSONObject obj = new JSONObject(comments.get(i).toString());
                            try {
                                mlist.add(obj);
                                Log.i("Comm id", obj.getString("_id"));
                                Log.i("Ans id", obj.getString("ans_id"));
                                Log.i("Ques id", obj.getString("ques_id"));
                                Log.i("Username ", obj.getString("username"));
                                Log.i("Comment ", obj.getString("comment_desc"));
                                Log.i("date ", obj.getString("date"));


                            } catch (NullPointerException e) {
                                Log.i("Null exception", e.getStackTrace().toString());
                                Crashlytics.logException(e);
                            }
                        }
                        Handler mainHandler;
                        mainHandler = new Handler(getContext().getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                mAdapter.notifyDataSetChanged();
                                TextView no_of_comm = getDialog().findViewById(R.id.commtitle);
                                no_of_comm.setText(String.format("%d Comments", comments.length()));
                                //System.out.println(mlist+"    "+mAdapter.mData.get(0).comment);
                            }
                        });
                        response.body().close();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", resp);
//                    Log.i("Response message:", response.message());
                    //mAdapter1.notifyDataSetChanged();
                }
            }
        });
    }

    void addcomment(final String ans_id, String comment) {
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/api/app/commentonans";

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ans_id=" + ans_id + "&comment_desc=" + comment);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token_local)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "06079cfc-257c-4ce6-99ca-e174654a6543,c644e0ef-6acb-4b07-9893-4295c2a96ca3")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "94")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                } else {
                    Handler mainHandler;
                    try {
                        mainHandler = new Handler(getContext().getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                mlist.clear();
//                                        getcomments(ans_id);
                                System.out.println(mlist);
                                Toast.makeText(getContext(), "Comment posted", Toast.LENGTH_SHORT).show();
                            }
                        });
                        response.body().close();
                    } catch (NullPointerException e) {
                        Log.i("Null exception", e.getStackTrace().toString());
                        Crashlytics.logException(e);
                    }


//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", response.body().string());
//                    Log.i("Response message:", response.message());
                }
            }
        });

    }

    @Override
    public void onItemClicked(int position) {
        try {
            Log.d("COMMENTSHEETFEED", "Pressed");
            if (position < users.size()) {
                name = users.get(position).getName();
                if (name.split(" ").length == 2) {
                    String userId = users.get(position).getUserId();
                    String name = users.get(position).getName();
                    if (!names.contains(name) && !UID.contains(userId)) {
                        UID.add(userId);
                        names.add("@" + name);
                    }
                    int cursorPos = addcomm.getSelectionStart();
                    Log.d("CommentSheetCursorX", String.valueOf(cursorPos));
                    String comment = addcomm.getText().toString();
                    comment = comment.replace("\n", "\n ");
                    int length_temp = 0;
                    String textToPut = "";
                    int final_index = 0;
                    String prevWord = "";
                    for (String currentWord : comment.split(" ")) {
                        length_temp += currentWord.length() + 1;
                        Log.d("CommentSheetCursor", String.valueOf(length_temp));
                        if (length_temp > cursorPos) {
                            if (currentWord.startsWith("@"))
                                textToPut += "@" + name + " ";
                            else if(prevWord.startsWith("@")) {
                                textToPut = textToPut.replace(prevWord,"") + "@" + name + " ";
                            }
                            final_index = textToPut.length();
                            cursorPos = Integer.MAX_VALUE;
                        } else {
                            if (currentWord.endsWith("\n")) {
                                textToPut += currentWord;
                                prevWord = currentWord + "\n";
                            } else {
                                textToPut += currentWord + " ";
                                prevWord = currentWord + " ";
                            }
                            Log.d("COMMENTSHEETFEEDPUT", currentWord);
                        }
                    }
//                textToPut=textToPut.replace("\n","\n ");
                    SpannableString put_text = new SpannableString(textToPut);
                    String[] arr = textToPut.split(" |\n");
                    for (int i = 0; i < arr.length - 1; i++) {
                        Log.d("CommentSheetArray", arr[i]);
                        if (arr[i].trim().startsWith("@")) {
                            Log.d("TagUser", arr[i]);
                            String tag_name = arr[i] + " " + arr[i + 1];
                            tag_name = tag_name.trim();
                            Log.d(TAG, names.toString());
                            Log.d("COMMENTSHEETTAGNAME", tag_name);
                            Log.d("CommentSheetCheck1", arr[i] + " " + arr[i + 1]);
                            if (names.contains(tag_name)) {
                                Log.d("COMMENTSHEETTAGNAME", names.toString());
                                put_text.setSpan(new CustomStyleSpan(UID.get(names.indexOf(tag_name))),
                                        textToPut.indexOf(tag_name),
                                        textToPut.indexOf(tag_name) + tag_name.length(),
                                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                            }
                        }
                    }
                    users.clear();
                    userAdapter.notifyDataSetChanged();
                    addcomm.setText(put_text);
                    addcomm.setSelection(final_index);
                    addcomm.setMovementMethod(LinkMovementMethod.getInstance());
                }
            } else {
                Toast.makeText(getContext(), "Select name of length 2", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Crashlytics.log(e.toString());
        }
    }

    private class CustomStyleSpan extends ClickableSpan {
        String Id;

        public CustomStyleSpan(String Id) {
            this.Id = Id;
        }

        @Override
        public void onClick(@NonNull View view) {
            addcomm.setSelection(addcomm.getText().length());
            goToProfile(Id);
        }
    }

    public void goToProfile(String User_Id) {
        Intent intent = new Intent(getContext(), ProfilePage.class);
        intent.putExtra("USER_ID", User_Id);
        startActivity(intent);
    }
}
