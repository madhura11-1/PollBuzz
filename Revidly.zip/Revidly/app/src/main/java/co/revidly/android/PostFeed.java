package co.revidly.android;

import com.google.firebase.analytics.FirebaseAnalytics;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.crashlytics.android.Crashlytics;
import com.facebook.AccessToken;
import com.facebook.login.LoginManager;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.SplashScreenActivity;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.HomeFeed.commentfragment;
import static co.revidly.android.helpers.Config.BASE_URL;

public class PostFeed {
    JSONArray topicsArray;
    JSONObject topics;
    static String auth_token_local;
    Context mContext;
    String userProfileId;
    TextView textView,noPostTextViewHomeFeed,noPostTextViewCommunityFeed;
    ShimmerRecyclerView recyclerView;
    List<JSONObject> mlist;
    List<String> postIds, viewedPosts;
    List<JSONObject> mPostAction;
    Adapter adapter;
    static Timer timer;

    //final boolean flag = true;
    boolean homeFlag = true;
    boolean communityFlag = true;
    static int fvi;
    static String commans_id;
    ProgressBar mProgressBar;

//    ProgressDialog progressDialog;

    String postURL;

    FirebaseAnalytics mFirebaseAnalytics;
    private String topicId;
    private boolean topicFound=false;
    private int startPoint=0, endPoint=0,dataInserted=0;
    int home_index = 1;
    int prof_index = 1;
    int community_index = 1;
    boolean refresh_flag;

    PostFeed(Context mContext, String auth_token, String userProfileId)
    {
        Log.d("TATA", "PostFeed Constructor Called");
        topicsArray = new JSONArray();
        topics = new JSONObject();
        auth_token_local = auth_token;
        this.mContext = mContext;
        this.userProfileId = userProfileId;
        setGlobals();
//        setRecyclerView();
        refresh_flag = true;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(mContext);
        //mShimmerFrameLayout = findViewById(R.id.shimmer_qanda);
    }
    void setGlobals()
    {
        if(mContext instanceof HomeFeed) {
            recyclerView = ((HomeFeed) mContext).findViewById(R.id.recvw);
            mProgressBar = ((HomeFeed) mContext).findViewById(R.id.loadPosts);
            postURL = "/api/post/get/";
            noPostTextViewHomeFeed = ((HomeFeed) mContext).findViewById(R.id.nopost);
            home_index = 1;
        }
        else if(mContext instanceof ProfilePage) {
            UserProfilePosts userProfilePostsFragment = (UserProfilePosts)((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(0);
            recyclerView = userProfilePostsFragment.recyvlerView();
            mProgressBar=userProfilePostsFragment.getProgressBar();
            textView = userProfilePostsFragment.textView;
            postURL = "/api/post/" + userProfileId + "/getPosts/";
            prof_index = 1;
        }
        else if(mContext instanceof CommunityFeed) {
            recyclerView = ((CommunityFeed) mContext).findViewById(R.id.recvw);
            mProgressBar = ((CommunityFeed) mContext).findViewById(R.id.loadPosts);
            postURL = "/api/post/get/";
            noPostTextViewCommunityFeed = ((CommunityFeed) mContext).findViewById(R.id.nopost);
            community_index = 1;
        }
        mlist = new ArrayList<>();
        mPostAction = new ArrayList<>();
        postIds = new ArrayList<>();
        viewedPosts = new ArrayList<>();
        adapter = new Adapter(mContext, mlist, mPostAction);
    }
    void setTopics(String topicsString)
    {
        try{
            topicsArray = new JSONArray(topicsString);
            buildPostArray(topicsArray);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
    }
    void buildPostArray(JSONArray topicsArray)
    {
        JSONArray topicNames = new JSONArray();
        try {
            //JSONObject topicsObj = new JSONObject(topicsString);
            for (int i = 0; i <= topicsArray.length() - 1; i++) {
                JSONObject topicsItem = topicsArray.optJSONObject(i);
                if(mContext instanceof HomeFeed || mContext instanceof ProfilePage) {
                    if(topicsItem.has("topic_name"))
                    topicNames.put(topicsItem.optString("topic_name"));
                    else if(topicsItem.has("name"))
                        topicNames.put(topicsItem.optString("name"));
                }
                else if (mContext instanceof CommunityFeed)
                    topicNames.put(topicsItem.optString("name"));
                //topicsArray.put("Technology");
                //topicsArray.put("politics");
                topics.put("topic", topicNames);
                Log.d("PostsFeed --->", "JSON TOPIC ----->" + topics.toString());
            }
        } catch(Exception e) {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
    }
    void setRecyclerView()
    {
        adapter.setHasStableIds(true);
        recyclerView.setAdapter(adapter);
//        recyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        recyclerView.setHasFixedSize(true);
        //recyclerView.smoothScrollToPosition(6);
        //recyclerView.setItemViewCacheSize(20);
        //adapter.setHasStableIds(true);
        recyclerView.setNestedScrollingEnabled(true);
        final LinearLayoutManager layoutManager=new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        ////itemTouchHelper.attachToRecyclerView(recyclerView);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            /*
            if (newState == RecyclerView.SCROLL_STATE_DRAGGING || newState == RecyclerView.SCROLL_STATE_SETTLING || newState == RecyclerView.SCROLL_STATE_IDLE) {
                adapter.onScrolled(recyclerView);
            }
             */
//                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
//                    int start = layoutManager.findFirstVisibleItemPosition();
//                    int end = layoutManager.findLastVisibleItemPosition();
//                    for (int i = start; i <= end; i++) {
//                        if (i > 0 && i < postIds.size()) {
//                            if (!viewedPosts.contains(postIds.get(i))) {
//                                Log.d("VisibleItem2", postIds.get(i));
//                                viewedPosts.add(postIds.get(i));
//                            }
//                        }
//                    }
//                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
//                if(((previous_scroll > 0 && dy < 0) || (previous_scroll < 0 && dy > 0))){
//                    viewedPosts.clear();
//                    previous_scroll=dy;
//                }
//                if (!recyclerView.canScrollVertically(-1) && layoutManager.findFirstCompletelyVisibleItemPosition() == 0) {
//                    viewedPosts.add(postIds.get(0));
//                }
                if (recyclerView.getAdapter() == adapter) {
                    int start = layoutManager.findFirstVisibleItemPosition();
                    int end = layoutManager.findLastVisibleItemPosition();
                    for (int i = start; i <= end; i++) {
                        if (i > 0 && i < postIds.size()) {
                            if (!viewedPosts.contains(postIds.get(i))) {
                                viewedPosts.add(postIds.get(i));
                                Log.d("VisibleItem2", viewedPosts.toString());
                            }
                        }
                    }
                    fvi = layoutManager.findFirstCompletelyVisibleItemPosition();
                    if (fvi == RecyclerView.NO_POSITION)
                        fvi = layoutManager.findFirstVisibleItemPosition();
                    if (topicId == null && refresh_flag && !recyclerView.canScrollVertically(1) && layoutManager.findFirstCompletelyVisibleItemPosition() != 0) {
                        Log.d("TATA", "HERE1");
                        getPosts();
                    }
                }
            }
        });
    }

    void commentOnClick(String post_id){
        commans_id=post_id;
        commentfragment = new CommentSheet();

        if(mContext instanceof HomeFeed)
            commentfragment.show(((HomeFeed) mContext).getSupportFragmentManager(),"Comments");
        else if(mContext instanceof ProfilePage)
            commentfragment.show(((ProfilePage) mContext).getSupportFragmentManager(),"Comments");
        else if(mContext instanceof CommunityFeed)
            commentfragment.show(((CommunityFeed) mContext).getSupportFragmentManager(),"Comments");


        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"comment");
        mFirebaseAnalytics.logEvent("commentClicked",bundle);
    }
    void shareOnClick(String post_id){
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        //Use the below line to share revidly link with ans id
        String shareBody = "https://www.revidly.co/viewPost/"+post_id;

        //Currently Sending it to Google Play Store to download app
        //String shareBody = "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +  "&hl=en";

        //sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);

        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"share");
        mFirebaseAnalytics.logEvent("shareClicked",bundle);
        mContext.startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    void acceptOnClick(String post_id, final int position){
        String url = BASE_URL+"/api/post/updatePostVisibility";
        String topic_id = CommunityFeed.topicID;
        String postID = post_id;
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\n\t\"topicId\":\""+topic_id+"\",\n\t\"postId\":\""+post_id+"\",\n\t\"rule\":\""+0+"\"\n}");
        final Request request = new Request.Builder()
                .url(url)
                .method("POST", body)
                .addHeader("Authorization", Utils.getAuthToken(mContext))
                .addHeader("Content-Type", "application/json")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if(response.isSuccessful()){
                    try{
                        String result = response.body().string();
                        JSONObject jsonObject = new JSONObject(result);
                        Log.d("LOG_DATA","UpdatePendingPost: "+jsonObject);
                        adapter.notifyItemRemoved(position);
                        adapter.notifyItemRangeChanged(position, mlist.size());
                        adapter.notifyItemRangeChanged(position, mPostAction.size());
                        adapter.notifyDataSetChanged();
                        response.body().close();
                    }
                    catch (Exception e){
                        Crashlytics.log(e.toString());
                        Log.e("LOG_DATA",e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    void declineOnClick(String post_id, final int position){
        Log.d("LOG_DATA","declineOnClick Called");
        String url = BASE_URL+"/api/post/updatePostVisibility";
        String topic_id = CommunityFeed.topicID;
        String postID = post_id;
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\n\t\"topicId\":\""+topic_id+"\",\n\t\"postId\":\""+post_id+"\",\n\t\"rule\":\""+2+"\"\n}");
        final Request request = new Request.Builder()
                .url(url)
                .method("POST", body)
                .addHeader("Authorization", Utils.getAuthToken(mContext))
                .addHeader("Content-Type", "application/json")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if(response.isSuccessful()){
                    try{
                        String result = response.body().string();
                        JSONObject jsonObject = new JSONObject(result);
                        Log.d("LOG_DATA","UpdatePendingPost: "+jsonObject);
                        Handler mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                adapter.notifyItemRemoved(position);
                                adapter.notifyItemRangeChanged(position, mlist.size());
                                adapter.notifyItemRangeChanged(position, mPostAction.size());
                                adapter.notifyDataSetChanged();
                            }
                        });

                        response.body().close();
                    }
                    catch (Exception e){
                        Crashlytics.log(e.toString());
                        Log.e("LOG_DATA",e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        });
    }
    void communityOnClick(JSONArray topicsArray) {
        Log.d("PostFeed comntyOnClck->", "topicsArray = " + topicsArray.toString());
        if(!(mContext instanceof CommunityFeed)) {
            Intent intent = new Intent(mContext, CommunityFeed.class);
            Log.d("LOG_DATA",topicsArray.toString());
            intent.putExtra("COMMUNITY_TOKEN", topicsArray.toString());
            mContext.startActivity(intent);
        }
    }
    void propicOnClick(String userId)
    {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"propic");
        Log.d("UserIDProp",userId);
        mFirebaseAnalytics.logEvent("propicClicked",bundle);
        Log.d("PostFeed propicOnClck->", "");
        if((mContext instanceof HomeFeed)) {
            Intent intent = new Intent(mContext, ProfilePage.class);
            intent.putExtra("USER_ID", userId);
            mContext.startActivity(intent);
        }
        else if(mContext instanceof CommunityFeed)
        {
            Intent intent = new Intent(mContext, ProfilePage.class);
            intent.putExtra("USER_ID", userId);
            mContext.startActivity(intent);
            ((CommunityFeed) mContext).finish();
        }
    }

    void setViews() {
        AsyncTaskRunner3 runner = new AsyncTaskRunner3();
        runner.execute();
    }

    void getPosts() {
        AsyncTaskRunner runner = new AsyncTaskRunner();
        runner.execute();
    }
    void getPendingPosts(String topicID) {
        topicId = topicID;
        AsyncTaskRunner1 runner = new AsyncTaskRunner1();
        runner.execute();

    }
    void getAsyncPendingPosts() {
        mlist.clear();
        mPostAction.clear();
        postIds.clear();
        Log.d("HomeFeed->getPosts()", "First line of getPosts");
        Log.d("TATA", "Pending");
        Handler mainHandler;
        mainHandler = new Handler(mContext.getMainLooper());
        mainHandler.post(new Runnable() {
            @Override
            public void run(){
//                progressDialog = ProgressDialog.show(mContext,
//                        "Loading Awesomeness..",
//                        "We are getting posts for you\n From your favourite clans\n Please Wait...");
                recyclerView.showShimmerAdapter();
            }
        });
        String url = BASE_URL + "/api/post/getPendingPosts";
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\n\t\"topicId\":\""+topicId+"\"\n}");
        Request request = new Request.Builder()
                .url(url)
                .method("POST", body)
                .addHeader("Authorization", auth_token_local)
                .addHeader("Content-Type", "application/json")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
                Handler mainHandler;
                mainHandler = new Handler(mContext.getMainLooper());
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {

                        //mShimmerFrameLayout.stopShimmer();
                        //mShimmerFrameLayout.setVisibility(View.GONE);
                        try {
//                            if (progressDialog != null && progressDialog.isShowing())
//                                progressDialog.dismiss();
                            recyclerView.hideShimmerAdapter();

                            final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                            builder.setTitle("Something\'s Wrong");
                            builder.setMessage("Something does not seem to be right. If the problem continues, close the app and start it again.");
                            builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //Click button action
                                    getAsyncPendingPosts();
                                    dialog.dismiss();
                                    Bundle bundle = new Bundle();
                                    bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "PostFeed");
                                    mFirebaseAnalytics.logEvent("getAsyncPostError", bundle);
                                }
                            });
                            builder.setCancelable(false);
                            builder.show();

                        } catch (Exception e) {
                            e.printStackTrace();
                            Crashlytics.log(e.toString());
                        }
                    }
                });
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                } else {
                    final String resp = response.body().string();
                    try {
                        JSONObject resultObject = new JSONObject(resp);
                        Log.d("JSON TOPIC result --->", resultObject.toString());

                        JSONObject data;
                        final JSONArray result;
                        JSONArray postActionResult = null;

                        if (resultObject.has("posts")) {
                            result = resultObject.getJSONArray("posts");
                        }
                        else {
                            data = resultObject.getJSONObject("data");
                            result = data.getJSONArray("posts");
                            //if(mContext instanceof HomeFeed)
                            if(data.has("postAction")) {
                                postActionResult = data.getJSONArray("postAction");
                            }
                            else if(data.has("postActions")) {
                                postActionResult = data.getJSONArray("postActions");
                            }
                        }
                        boolean flag = true;
                        Log.d("LOG_DATA","Results: "+result);
                        ////quanswers = new JSONObject[result.length()];
                        if (result.length() != 0){
                            for (int i = 0; i < result.length(); i++) {
                                final JSONObject obj = result.getJSONObject(i);
                                JSONObject obj2 = null;
                                // if(mContext instanceof HomeFeed)
                                obj2 = postActionResult.getJSONObject(i);
                                postIds.add(result.optJSONObject(i).optString("_id"));
                                //quanswers[i] = new JSONObject(result.get(i).toString());
                                mlist.add(obj);
                                //if(mContext instanceof HomeFeed)

                                Log.d("PostFeed->getPosts()", "After adding object to obj");
                                //Log.i("Question id "+i,obj.getString("ques_id"));
                                Log.i("Post Title", obj.getString("title"));
                                Log.i("Post Description", obj.getString("description"));
                                //Log.i("Answer URL",obj.getString("ans_url"));
                                Log.i("Answer Auth id", obj.getString("userId"));
                                //if(mContext instanceof HomeFeed)
                                Log.d("PostFeed->getPosts()", "mPostAction = " + obj2.getString("postId"));
                                //Log.i("Question Auth id",obj.getString("ques_auth_id"));
                                if(mContext instanceof  ProfilePage)
                                    flag = false;
                                if(mContext instanceof HomeFeed)
                                    homeFlag = false;
                                if(mContext instanceof  CommunityFeed)
                                    communityFlag = false;
                            }
                            getPostAction();
                        }
                        else{
                            if(mContext instanceof  ProfilePage)
                                flag = true;
                            if(mContext instanceof HomeFeed)
                                homeFlag = true;
                            if(mContext instanceof CommunityFeed)
                                communityFlag = true;
                        }
                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        final boolean finalFlag = flag;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                //mShimmerFrameLayout.stopShimmer();
                                //mShimmerFrameLayout.setVisibility(View.GONE);
                                try {
//                                    if (progressDialog != null && progressDialog.isShowing())
//                                        progressDialog.dismiss();
                                    recyclerView.hideShimmerAdapter();
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    Crashlytics.log(e.toString());
                                }
                                adapter.notifyDataSetChanged();
                                if( mContext instanceof HomeFeed) {
                                    ((HomeFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.GONE);
                                    if(homeFlag){
                                        noPostTextViewHomeFeed.setVisibility(View.VISIBLE);
                                    }
                                    else{
                                        noPostTextViewHomeFeed.setVisibility(View.GONE);
                                    }
                                }
                                else if( mContext instanceof CommunityFeed) {
                                    ((CommunityFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.GONE);
                                    if(communityFlag){
                                        noPostTextViewCommunityFeed.setVisibility(View.VISIBLE);
                                    }
                                    else{
                                        noPostTextViewCommunityFeed.setVisibility(View.GONE);
                                    }
                                }
                                if(mContext instanceof ProfilePage){
                                    if(finalFlag){
                                        textView.setVisibility(View.VISIBLE);
                                    }
                                    else{
                                        textView.setVisibility(View.GONE);
                                    }
                                }
                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
//                                if (progressDialog != null && progressDialog.isShowing())
//                                    progressDialog.dismiss();
                                recyclerView.hideShimmerAdapter();
                                if (resp.equals("NO ANSWERS"))
                                    //mShimmerFrameLayout.stopShimmer();
                                    //mShimmerFrameLayout.setVisibility(View.GONE);
                                    if( mContext instanceof HomeFeed)
                                        ((HomeFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.VISIBLE);
                                    else if( mContext instanceof CommunityFeed)
                                        ((CommunityFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.VISIBLE);
                            }
                        });
                    }
                    Log.i("Response:", response.toString());
                    Log.i("Response body:", response.body().toString());
                    Log.i("Response String: ", resp);
                    Log.i("Response message:", response.message());
                    response.body().close();
                }
            }
        });
    }

    void getAsyncPosts() {
        Log.d("HomeFeed->getPosts()", "First line of getPosts");

        Handler mainHandler;
        mainHandler = new Handler(mContext.getMainLooper());
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
//                progressDialog = ProgressDialog.show(mContext,
//                        "Loading Posts..",
//                        "We are getting posts for you\n From your favourite clans\n Please Wait...");
                if (mlist.size() == 0)
                    recyclerView.showShimmerAdapter();
                else
                    mProgressBar.setVisibility(View.VISIBLE);
            }
        });



        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/json");
        //RequestBody body = RequestBody.create(mediaType, "ques_id="+ques_id);

        String url = BASE_URL + postURL;

        //RequestBody body = RequestBody.create(mediaType, "{\n\t\"topic\":[\"politics\"]\n}");
        RequestBody body;
        if(mContext instanceof CommunityFeed)
            body = RequestBody.create(mediaType, topics.toString());
        else if(mContext instanceof HomeFeed)
            body = RequestBody.create(mediaType, "");
        else
            body = RequestBody.create(mediaType, "");
        Log.d("PostFeed -->", "Topics ------> " + topics.toString());

        Request request;
        if (postURL.equals("/api/post/get/")) {
            if (mContext instanceof HomeFeed) {
                url += String.valueOf(home_index);
                Log.d("TATATATA", "home_index: " + String.valueOf(home_index));
                home_index++;
                request = new Request.Builder()
                        .url(url)
                        .post(body)
                        .addHeader("Authorization", auth_token_local)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Connection", "keep-alive")
                        .build();
            } else {
                url += String.valueOf(community_index);
                Log.d("TATATATA", "com_index: " + String.valueOf(community_index));
                community_index++;
                request = new Request.Builder()
                        .url(url)
                        .post(body)
                        .addHeader("Authorization", auth_token_local)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Connection", "keep-alive")
                        .build();
            }
        }
        else
        {
            url+=String.valueOf(prof_index);
            prof_index++;
            request = new Request.Builder()
                    .url(url)
                    .get()
                    .addHeader("Authorization", auth_token_local)
                    .addHeader("Content-Type", "application/x-www-form-urlencoded")
                    .addHeader("Connection", "keep-alive")
                    .build();
        }

        Call call = client.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());

                Handler mainHandler;
                mainHandler = new Handler(mContext.getMainLooper());
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {

                        //mShimmerFrameLayout.stopShimmer();
                        //mShimmerFrameLayout.setVisibility(View.GONE);
                        try {
//                            if (progressDialog != null && progressDialog.isShowing())
//                                progressDialog.dismiss();
                            if(mContext instanceof HomeFeed){
                                if(home_index<=2)
                                    recyclerView.hideShimmerAdapter();
                                else
                                    mProgressBar.setVisibility(View.GONE);
                            }
                            if(mContext instanceof CommunityFeed){
                                if(community_index<=2)
                                    recyclerView.hideShimmerAdapter();
                                else
                                    mProgressBar.setVisibility(View.GONE);
                            }
                            if(mContext instanceof ProfilePage){
                                if(prof_index<=2)
                                    recyclerView.hideShimmerAdapter();
                                else
                                    mProgressBar.setVisibility(View.GONE);
                            }
                            final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                            builder.setTitle("Something\'s Wrong");
                            builder.setMessage("Something does not seem to be right. If the problem continues, close the app and start it again.");
                            builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //Click button action
                                    getAsyncPosts();
                                    dialog.dismiss();
                                    Bundle bundle = new Bundle();
                                    bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"PostFeed");
                                    mFirebaseAnalytics.logEvent("getAsyncPostError",bundle);
                                }
                            });
                            builder.setCancelable(false);
                            builder.show();

                        } catch (Exception e) {
                            e.printStackTrace();
                            Crashlytics.log(e.toString());
                        }
                    }
                    });
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception

                    if(response.message().equalsIgnoreCase("Forbidden"))
                    {
                        logout();
                    }
                    else {

                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

//                                if (progressDialog != null && progressDialog.isShowing())
//                                    progressDialog.dismiss();
                                if(mContext instanceof HomeFeed){
                                    if(home_index<=2)
                                        recyclerView.hideShimmerAdapter();
                                    else
                                        mProgressBar.setVisibility(View.GONE);
                                }
                                if(mContext instanceof CommunityFeed){
                                    if(community_index<=2)
                                        recyclerView.hideShimmerAdapter();
                                    else
                                        mProgressBar.setVisibility(View.GONE);
                                }
                                if(mContext instanceof ProfilePage){
                                    if(prof_index<=2)
                                        recyclerView.hideShimmerAdapter();
                                    else
                                        mProgressBar.setVisibility(View.GONE);
                                }
                                final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                                builder.setTitle("Something\'s Wrong");
                                builder.setMessage("Something does not seem to be right. If the problem continues, close the app and start it again.");
                                builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //Click button action
                                        getAsyncPosts();
                                        dialog.dismiss();
                                        Bundle bundle = new Bundle();
                                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "PostFeed");
                                        mFirebaseAnalytics.logEvent("getAsyncPostError", bundle);
                                    }
                                });
                                builder.setCancelable(false);
                                builder.show();
                            }
                        });
                        throw new IOException("Unexpected code " + response);
                    }
                } else {
                    final String resp = response.body().string();
//                    mlist.clear();
//                    mPostAction.clear();
//                    postIds.clear();
                    try {
                        JSONObject resultObject = new JSONObject(resp);
                        Log.d("JSON TOPIC result --->", resultObject.toString());

                        JSONObject data;
                        final JSONArray result;
                        JSONArray postActionResult = null;

                        if (resultObject.has("posts")) {
                            result = resultObject.getJSONArray("posts");
                        }
                        else
                        {
                            data = resultObject.getJSONObject("data");

                            //if(mContext instanceof HomeFeed)
                            if(data.has("postAction")) {
                                postActionResult = data.getJSONArray("postAction");
                            }
                            else if(data.has("postActions"))
                            {
                                postActionResult = data.getJSONArray("postActions");
                            }
                            result = data.getJSONArray("posts");
                            Log.d("LOG_DATA","DATA: "+data.getJSONArray("posts"));
                        }
                        Log.d("LOG_DATA","Results: "+result);
                        Log.d("LOG_DATA","PostAction: "+postActionResult);
                        boolean flag = true;

                        ////quanswers = new JSONObject[result.length()];
                        startPoint = postIds.size();
                        if (result.length() != 0){
                            for (int i = 0; i < result.length(); i++){
                                final JSONObject obj = result.getJSONObject(i);
                                JSONObject obj2 = null;
                                obj2 = postActionResult.getJSONObject(i);
                                postIds.add(result.optJSONObject(i).optString("_id"));
                                mlist.add(obj);
                                Log.d("VisibleItem1", obj.toString());
                                //if(mContext instanceof HomeFeed)



                                // if(mContext instanceof HomeFeed)


                                //quanswers[i] = new JSONObject(result.get(i).toString());

                                Log.d("PostFeed->getPosts()", "After adding object to obj");
                                //Log.i("Question id "+i,obj.getString("ques_id"));
                                Log.i("Post Title", obj.getString("title"));
                                Log.i("Post Description", obj.getString("description"));
                                //Log.i("Answer URL",obj.getString("ans_url"));
                                Log.i("Answer Auth id", obj.getString("userId"));
                                //if(mContext instanceof HomeFeed)
                                Log.d("PostFeed->getPosts()", "mPostAction = " + obj2.getString("postId"));
                                //Log.i("Question Auth id",obj.getString("ques_auth_id"));
                                if(mContext instanceof  ProfilePage)
                                    flag = false;
                                if(mContext instanceof HomeFeed)
                                    homeFlag = false;
                                if(mContext instanceof  CommunityFeed)
                                    communityFlag = false;
                            }
//                            endPoint=0;
                            getPostAction();
                    }
                        else{
                            if (mlist.isEmpty()) {
                                if (mContext instanceof ProfilePage)
                                    flag = true;
                                if (mContext instanceof HomeFeed)
                                    homeFlag = true;
                                if (mContext instanceof CommunityFeed)
                                    communityFlag = true;
                            } else {
                                if (mContext instanceof ProfilePage)
                                    flag = false;
                                if (mContext instanceof HomeFeed)
                                    homeFlag = false;
                                if (mContext instanceof CommunityFeed)
                                    communityFlag = false;
                                refresh_flag = false;
                            }
                        }
                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        final boolean finalFlag = flag;
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                                //mShimmerFrameLayout.stopShimmer();
                                //mShimmerFrameLayout.setVisibility(View.GONE);
                                try {
//                                    if (progressDialog != null && progressDialog.isShowing())
//                                        progressDialog.dismiss();
                                    adapter.notifyDataSetChanged();
                                    if(mContext instanceof HomeFeed){
                                        if(home_index<=2)
                                            recyclerView.hideShimmerAdapter();
                                        else
                                            mProgressBar.setVisibility(View.GONE);
                                    }
                                    if(mContext instanceof CommunityFeed){
                                        if(community_index<=2)
                                            recyclerView.hideShimmerAdapter();
                                        else
                                            mProgressBar.setVisibility(View.GONE);
                                    }
                                    if(mContext instanceof ProfilePage){
                                        if(prof_index<=2)
                                            recyclerView.hideShimmerAdapter();
                                        else
                                            mProgressBar.setVisibility(View.GONE);
                                    }

                                }
                                catch(Exception e)
                                {
                                    e.printStackTrace();
                                    Crashlytics.log(e.toString());
                                }
                                if (!refresh_flag)
                                    Toast.makeText(mContext, "You have viewed all posts!", Toast.LENGTH_SHORT).show();

                                if( mContext instanceof HomeFeed) {
                                    ((HomeFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.GONE);
                                    if(homeFlag){
                                        noPostTextViewHomeFeed.setVisibility(View.VISIBLE);
                                    }
                                    else{
                                        noPostTextViewHomeFeed.setVisibility(View.GONE);
                                    }
                                }
                                else if( mContext instanceof CommunityFeed) {
                                    ((CommunityFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.GONE);
                                    if(communityFlag){
                                        noPostTextViewCommunityFeed.setVisibility(View.VISIBLE);
                                    }
                                    else{
                                        noPostTextViewCommunityFeed.setVisibility(View.GONE);
                                    }
                                }
                                if(mContext instanceof ProfilePage){
                                    if(finalFlag){
                                        textView.setVisibility(View.VISIBLE);
                                    }
                                    else{
                                        textView.setVisibility(View.GONE);
                                    }
                                }
                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (resp.equals("NO ANSWERS"))
                                    //mShimmerFrameLayout.stopShimmer();
                                //mShimmerFrameLayout.setVisibility(View.GONE);
                                    if( mContext instanceof HomeFeed)
                                        ((HomeFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.VISIBLE);
                                    else if( mContext instanceof CommunityFeed)
                                        ((CommunityFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.VISIBLE);
                            }
                        });
                    }
                    Log.i("Response:", response.toString());
                    Log.i("Response body:", response.body().toString());
                    Log.i("Response String: ", resp);
                    Log.i("Response message:", response.message());
                    response.body().close();
                }
            }
        });
    }

    void getPostAction() {
        AsyncTaskRunner2 runner = new AsyncTaskRunner2();
        runner.execute();
    }
    public void getAsyncPostAction(final List<String> postIds){
        Log.d("LOG_DATA","Inside getPostAction");
        Log.d("LOG_DATA","SIZE(): "+ postIds.size());
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body;
        String content = "{\n\t\"posts\": [\"" + postIds.get(startPoint) + "\",";
        for (int i = startPoint + 1; i < postIds.size() - 1; i++) {
//            if(i==postIds.size()){
//                runner.cancel(true);
//            }
//            if(postIds.size()-i==1){

            content += "\"" + postIds.get(i) + "\",";

//            body = RequestBody.create(mediaType, "{\n\t\"posts\": [\"" + postIds.get(i) + "\"]\n}");
//                dataInserted = 1;
//                endPoint=i;
//            }
        }
        content += "\"" + postIds.get(startPoint) + "\"]\n}";
        Log.d("PostAction123Div", content);
        body = RequestBody.create(mediaType, content);

//            else if(postIds.size()-i==2) {
//                Log.d("TATATA","Inside 2");
//                body = RequestBody.create(mediaType, "{\n\t\"posts\": [\""+postIds.get(i)+"\"," +
//                        "\""+postIds.get(i+1)+"\\\"]\n}");
//                dataInserted = 2;
//                endPoint = i+1;
//            }
//            else if(postIds.size()-i==3){
//                Log.d("TATATA","Inside 3");
//                body = RequestBody.create(mediaType, "{\n\t\"posts\": [\""+postIds.get(i)+"\"," +
//                        "\""+postIds.get(i+1)+"\",\""+postIds.get(i+2)+"\"]\n}");
//                dataInserted = 3;
//                endPoint = i+2;
//            }
//            else{
//                Log.d("TATATA","Inside 4");
//                body = RequestBody.create(mediaType, "{\n\t\"posts\": [\""+postIds.get(i)+"\"," +
//                        "\""+postIds.get(i+1)+"\",\""+postIds.get(i+2)+"\",\""+postIds.get(i+3)+"\"]\n}");
//                endPoint = i+3;
//                dataInserted = 4;
//                i = endPoint;
//            }
            String url = BASE_URL + "/api/post/postactions";
            Request request = new Request.Builder()
                    .url(url)
                    .method("POST", body)
                    .addHeader("Authorization", Utils.getAuthToken(mContext))
                    .addHeader("Content-Type", "application/json")
                    .build();

            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    Log.e("PostFeed",e.getMessage());
                    e.printStackTrace();

                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    if(!response.isSuccessful()){

                    }
                    else{
                        try {
                            String resp = response.body().string();
                            Log.d("LOG_DATA", "Corona_Go_Back: " + resp);
                            JSONObject res = new JSONObject(resp);
                            final JSONArray postAction = res.optJSONArray("postActions");
                            Log.d("PostActionCount", postAction.toString());
                            if (postAction != null) {
                                recyclerView.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        for (int j = 0; j < postAction.length(); j++) {
                                            mPostAction.add(postAction.optJSONObject(j));
                                            adapter.notifyItemChanged(mPostAction.size() - 1);
                                        }
                                    }
                                });
                            }
//                            if (recyclerView != null) {
//                                Handler mainHandler;
//                                mainHandler = new Handler(mContext.getMainLooper());
//                                recyclerView.post(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                    if(startPoint>5){
//                                        adapter.notifyDataSetChanged();
//                                    }
//                                    else{
//                                        adapter.notifyItemChanged(startPoint);
//                                    }
//                                    }
//                                });
//                            }
                            response.body().close();
                        }
                        catch (Exception e){
                            Log.d("LOG_DATA","Error");
                            e.printStackTrace();
                            Crashlytics.log(e.toString());
                        }
                    }
                }
            });
        }
//        recyclerView.post(new Runnable() {
//            @Override
//            public void run() {
////                for(int j = 0;j<postIds.size();j++) {
////                    Log.d("TATATA", "Here: " + String.valueOf(j));
////                    adapter.notifyItemChanged(j);
//                adapter.notifyDataSetChanged();
////                }
//            }
//        });


//    }

    private void checkTopicStatus(JSONArray topics) {
        try{
            for(int j=0;j<topics.length();j++){
                JSONObject topic = topics.getJSONObject(j);
                Log.d("LOG_DATA","TOPICS: "+ topic);
                Log.d("LOG_DATA","Name: "+topic.getString("name"));
                Log.d("LOG_DATA","Status: "+topic.getString("allowPosts"));
                if(topic.get("topicId").equals(CommunityFeed.topicID)){
                    if(topic.getString("allowPosts").equalsIgnoreCase("0")){
                        topicFound = true;
                        break;
                    }
                }
            }
        }
        catch (Exception e){
            Log.e("LOG_DATA",e.getMessage());
            e.printStackTrace();
            Crashlytics.log(e.toString());
        }

    }

    void deletePost(final String postId){
        Log.i("deletePost Reponse -->"," before OKHTTP I am called postId = " + postId);
        Log.d("LOG_DATA","DeletePost Called");
        new AlertDialog.Builder(mContext)
                .setTitle("Delete Post")
                .setMessage("Are you sure you want to delete this Post?")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.

                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"deletePost");
                        mFirebaseAnalytics.logEvent("deletePostClicked",bundle);
                        // Continue with delete operation
                        OkHttpClient client = new OkHttpClient();
                        Log.i("deletePost Reponse -->"," after OKHTTP I am called postId = " + postId);
                        String url = BASE_URL + "/api/post/delete";
                        MediaType mediaType = MediaType.parse("application/json");
                        JSONObject postDelete = new JSONObject();
                        try {
                            postDelete.put("postId", postId);
                        }
                        catch(Exception e) {
                            e.printStackTrace();
                            Crashlytics.logException(e);
                        }
                        Log.i("deletePost Reponse -->"," after postDelete = " + postDelete.toString());

                        RequestBody body = RequestBody.create(mediaType, postDelete.toString());
                        Request request = new Request.Builder()
                                .url(url)
                                .post(body)
                                .addHeader("Content-Type", "application/json")
                                .addHeader("Authorization", auth_token_local)
                                .addHeader("cache-control", "no-cache")
                                .addHeader("Postman-Token", "62f68963-bad1-4ed2-adf1-6d275e647694")
                                .build();

                        Call call = client.newCall(request);
                        call.enqueue(new Callback() {
                            @Override
                            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                            }

                            @Override
                            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                if (!response.isSuccessful()) {
                                    // You can also throw your own custom exception
                                    Log.i("Response ",response.toString());
                                    throw new IOException("Unexpected code " + response);
                                } else {
                                    //setdata(holder, position);
                                    Log.i("deletePost Reponse -->"," Success " + response.toString());
                                    getAsyncPosts();

                                    Handler mainHandler;
                                    try {
                                        mainHandler = new Handler(mContext.getMainLooper());
                                        mainHandler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                Log.i("deletePost Reponse -->"," Inside run");
                                                Toast.makeText(mContext, "Post Deleted", Toast.LENGTH_LONG).show();
                                            }
                                        });
                                    } catch (NullPointerException e) {
                                        Log.i("Null exception", e.getStackTrace().toString());
                                        Crashlytics.logException(e);
                                    }
                                    Log.i("Response:", response.toString());
                                    Log.i("Response body:", response.body().toString());
                                    Log.i("Response String: ", response.body().string());
                                    Log.i("Response message:", response.message());
                                    response.body().close();
                                }
                            }
                        });

                    }
                })
                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private class AsyncTaskRunner extends AsyncTask<String, String, String> {

        private String resp;
//        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            Log.d("HomeFeed Async -->", "I am inside doInBackground before publishProgress");
            publishProgress("Sleeping..."); // Calls onProgressUpdate()
            Log.d("HomeFeed Async -->", "I am inside doInBackground after publishProgress");
            try {
                Log.d("HomeFeed Async -->", "I am inside doInBackground before getTopics");
                getAsyncPosts();


            } catch (Exception e) {
                e.printStackTrace();
                resp = e.getMessage();
                Crashlytics.logException(e);
            }
            return resp;
        }


        @Override
        protected void onPostExecute(String result) {
            // execution of result of Long time consuming operation
            //progressDialog.dismiss();
            Log.d("HomeFeed Async -->", "I am inside onPostExecute");
            //finalResult.setText(result);


        }


        @Override
        protected void onPreExecute() {
            Log.d("HomeFeed Async --> ", "I am inside onPreExecute");
            //progressDialog = ProgressDialog.show(HomeFeed.this,"Loading Awesomeness..","Your internet is a bit slow..But don\'t worry we got your back.");

        }


        @Override
        protected void onProgressUpdate(String... text) {
            //finalResult.setText(text[0]);
            Log.d("HomeFeed Async -->", "I am inside onProgressUpdate");
        }
    }

    private void logout(){
        Utils.removeLoginAuthToken(mContext);
        mContext.startActivity(new Intent(mContext, SplashScreenActivity.class));
        Log.d("PostFeed", "logout Called");
        AccessToken fbAccessToken = AccessToken.getCurrentAccessToken();
        if(fbAccessToken != null){
            Log.d("LOG_DATA", "Logged out");
            LoginManager.getInstance().logOut();
        }
    }

    private class AsyncTaskRunner1 extends AsyncTask<String, String, String> {

        private String resp;
//        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            Log.d("HomeFeed Async -->", "I am inside doInBackground before publishProgress");
            publishProgress("Sleeping..."); // Calls onProgressUpdate()
            Log.d("HomeFeed Async -->", "I am inside doInBackground after publishProgress");
            try {
                Log.d("HomeFeed Async -->", "I am inside doInBackground before getTopics");
                getAsyncPendingPosts();

            } catch (Exception e) {
                e.printStackTrace();
                resp = e.getMessage();
                Crashlytics.logException(e);
            }
            return resp;
        }


        @Override
        protected void onPostExecute(String result) {
            // execution of result of Long time consuming operation
            //progressDialog.dismiss();
            Log.d("HomeFeed Async -->", "I am inside onPostExecute");
            //finalResult.setText(result);

        }


        @Override
        protected void onPreExecute() {
            Log.d("HomeFeed Async --> ", "I am inside onPreExecute");
            //progressDialog = ProgressDialog.show(HomeFeed.this,"Loading Awesomeness..","Your internet is a bit slow..But don\'t worry we got your back.");

        }


        @Override
        protected void onProgressUpdate(String... text) {
            //finalResult.setText(text[0]);
            Log.d("HomeFeed Async -->", "I am inside onProgressUpdate");
        }
    }

    private class AsyncTaskRunner2 extends AsyncTask<String, String, String> {

        private String resp;
//        ProgressDialog progressDialog;

        @Override
        protected String doInBackground(String... params) {
            Log.d("HomeFeed Async -->", "I am inside doInBackground before publishProgress");
            publishProgress("Sleeping..."); // Calls onProgressUpdate()
            Log.d("HomeFeed Async -->", "I am inside doInBackground after publishProgress");
            try {
                Log.d("HomeFeed Async -->", "I am inside doInBackground before getTopics");

                getAsyncPostAction(postIds);


            } catch (Exception e) {
                e.printStackTrace();
                resp = e.getMessage();
                Crashlytics.logException(e);
            }
            return resp;
        }


        @Override
        protected void onPostExecute(String result) {
            // execution of result of Long time consuming operation
            //progressDialog.dismiss();
            Log.d("HomeFeed Async -->", "I am inside onPostExecute");
            //finalResult.setText(result);

        }


        @Override
        protected void onPreExecute() {
            Log.d("HomeFeed Async --> ", "I am inside onPreExecute");
            //progressDialog = ProgressDialog.show(HomeFeed.this,"Loading Awesomeness..","Your internet is a bit slow..But don\'t worry we got your back.");

        }


        @Override
        protected void onProgressUpdate(String... text) {
            //finalResult.setText(text[0]);
            Log.d("HomeFeed Async -->", "I am inside onProgressUpdate");
        }
    }

    private class AsyncTaskRunner3 extends AsyncTask<String, String, String> {
        private String resp;

        @Override
        protected String doInBackground(String... params) {
            publishProgress("Sleeping..."); // Calls onProgressUpdate()
            Log.d("HomeFeed Async -->", "I am inside doInBackground after publishProgress");
            try {
                Log.d("HomeFeed Async -->", "I am inside doInBackground before setViews");
                setAsyncViews();

            } catch (Exception e) {
                e.printStackTrace();
                resp = e.getMessage();
                Crashlytics.logException(e);
            }
            return resp;
        }


        @Override
        protected void onPostExecute(String result) {
            // execution of result of Long time consuming operation
            //progressDialog.dismiss();
            Log.d("HomeFeed Async -->", "I am inside onPostExecute");
            //finalResult.setText(result);

        }


        @Override
        protected void onPreExecute() {
            Log.d("HomeFeed Async --> ", "I am inside onPreExecute");
            //progressDialog = ProgressDialog.show(HomeFeed.this,"Loading Awesomeness..","Your internet is a bit slow..But don\'t worry we got your back.");

        }


        @Override
        protected void onProgressUpdate(String... text) {
            //finalResult.setText(text[0]);
            Log.d("HomeFeed Async -->", "I am inside onProgressUpdate");
        }
    }

    private void setAsyncViews() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (viewedPosts.size() >= 5) {
                    Log.d("Timer", viewedPosts.toString());
                    String url = BASE_URL + "/api/post/view/";
                    OkHttpClient client = new OkHttpClient().newBuilder()
                            .build();
                    MediaType mediaType = MediaType.parse("application/json");
                    JSONObject postCountObject = new JSONObject();
                    JSONArray array = new JSONArray();
                    try {
                        for (int i = 0; i < viewedPosts.size(); i++) {
                            JSONObject obj = new JSONObject();
                            obj.put("postId", postIds.get(i));
                            obj.put("duration", 1);
                            array.put(obj);
                        }
                        postCountObject.put("data", array);
                        Log.d("PostCountObject123", postCountObject.toString());
                        viewedPosts.clear();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                    RequestBody body = RequestBody.create(mediaType, postCountObject.toString());
                    final Request request = new Request.Builder()
                            .url(url)
                            .method("POST", body)
                            .addHeader("Authorization", LoggedInUser.auth_token_global)
                            .addHeader("Content-Type", "application/json")
                            .build();
                    Call call = client.newCall(request);
                    call.enqueue(new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            System.out.println(e.getStackTrace().toString());
                            Log.i("FailedIncCount : ", e.getStackTrace().toString());
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            System.out.println("Success : " + response.body().toString());
                            if (!response.isSuccessful()) {
                                // You can also throw your own custom exception
                                throw new IOException("Unexpected code " + response);
                            } else {
                                System.out.println("SuccessConfirm : " + response.body().toString());
                                response.body().close();
                            }
                        }
                    });
                }
            }
        }, 3000,3000);
    }
}
