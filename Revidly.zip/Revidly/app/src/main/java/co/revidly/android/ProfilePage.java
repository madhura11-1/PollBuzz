package co.revidly.android;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;

import com.crashlytics.android.Crashlytics;
import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.SplashScreenActivity;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;


public class ProfilePage extends AppCompatActivity {

    private static final String TAG = "OnCreate:ProfilePage";
    private String get_user_det_url;
    private PagerAdapter pagerAdapter;
    public static boolean main = true;
    private ViewPager mViewPager;
    public static AskQuestion fragment;
    static public String auth_token;

    JSONObject data;
    TextView name, follower, username, following, upvoteCount;
    ArrayList<String> ans_url;
    ImageView profilePic, logout, backButton;
    //    ImageView notification, notificationActive;
    BottomNavigationView bottomNavigationView;
    ImageButton refer;

    Button updateClans, followButton, unfollow;

    String askedUserId;

    String profilePicUrl;

    UserClans userClans;

    private static ProfilePage mInstance;
    private FirebaseAnalytics mFirebaseAnalytics;
    private int code = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Log.d(TAG, "onCreate: Started.");

        mInstance = this;
        //name= findViewById(R.id.name);
        //username = findViewById(R.id.username);
        follower = findViewById(R.id.follower);
        following = findViewById(R.id.following);
        profilePic = findViewById(R.id.profile_pic);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
//        notification = findViewById(R.id.notification);
//        notificationActive = findViewById(R.id.notificationActive);
        logout = findViewById(R.id.logout);
        updateClans = findViewById(R.id.update_clans_btn);
        refer = findViewById(R.id.refer);
        followButton = findViewById(R.id.follow_btn);
        unfollow = findViewById(R.id.unfollow);
        auth_token = Utils.getAuthToken(getApplicationContext());
        checkNotificationStatus();
        GoogleSignInOptions gso = new GoogleSignInOptions.
                Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).
                build();

        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient(getApplicationContext(), gso);
        googleSignInClient.signOut();

        userClans = null;
        backButton = findViewById(R.id.ivBackArrow);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                    Intent intent=new Intent(ProfilePage.this,HomeFeed.class);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//                    startActivity(intent);
                finish();
            }
        });

        askedUserId = "";
        askedUserId = getIntent().getStringExtra("USER_ID");
        Log.d("LOG_DATA", "UserID: " + askedUserId);
        if (askedUserId.equals(LoggedInUser.userId)) {
            setUserDetails();
//            checkNotificationStatus();
            updateClans.setVisibility(View.VISIBLE);
            refer.setVisibility(View.VISIBLE);
            followButton.setVisibility(View.INVISIBLE);
        } else {
//            notificationActive.setVisibility(View.INVISIBLE);
//            notification.setVisibility(View.INVISIBLE);
            logout.setVisibility(View.INVISIBLE);
            getUserDetails();
        }
        Log.d(TAG, "TOKEN: " + auth_token);
        //fragment = new AskQuestion();
        followButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    followButton.setVisibility(View.INVISIBLE);
                    unfollow.setVisibility(View.VISIBLE);
                    int followerCount = Integer.parseInt(follower.getText().toString()) + 1;
                    follower.setText("" + followerCount);
                    updateMetaData();
                } catch (Exception e) {
                    e.printStackTrace();
                    Crashlytics.log(e.toString());
                }

            }
        });

        unfollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    unfollow.setVisibility(View.INVISIBLE);
                    followButton.setVisibility(View.VISIBLE);
                    int followerCount = Integer.parseInt(follower.getText().toString()) - 1;
                    follower.setText("" + followerCount);
                    updateMetaData();
                } catch (Exception e) {
                    e.printStackTrace();
                    Crashlytics.log(e.toString());

                }

            }
        });
            /*
            profilePic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),ChangeProfile.class));
                }
            });

             */
        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DescribedProfilePicActivity.class);
                intent.putExtra("userId", getIntent().getStringExtra("USER_ID"));
                startActivity(intent);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertBuilder();
            }
        });

        updateClans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("ProfilePage ---> ", "updateClans is Clicked");
                LoggedInUser.updateClans = true;

                finish();
            }
        });
        refer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("UserId", LoggedInUser.userId);
                String userId = LoggedInUser.userId;
                String url = BASE_URL + "/api/user/" + userId + "/getCode";
                OkHttpClient client = new OkHttpClient().newBuilder()
                        .build();
                Request request = new Request.Builder()
                        .url(url)
                        .method("GET", null)
                        .addHeader("Authorization", auth_token)
                        .build();
                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Log.e(TAG, e.getMessage());
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            try {
                                String resp = response.body().string();
                                JSONObject data = new JSONObject(resp);
                                String code = data.getString("code");
                                Log.d(TAG, "ReferCode: " + code);
                                String share_link = BASE_URL + "/refer/" + code;
                                try {
                                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                                    shareIntent.setType("text/plain");
                                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Revidly");
                                    shareIntent.putExtra(Intent.EXTRA_TEXT, share_link);
                                    startActivity(Intent.createChooser(shareIntent, "Choose One"));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } catch (Exception e) {
                                Log.e(TAG, e.getMessage());
                                e.printStackTrace();
                                Crashlytics.logException(e);
                            }

                        }
                    }
                });
            }
        });
        findViewById(R.id.fText).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfilePage.this, FollowerListActivity.class);
                intent.putExtra("userId", getIntent().getStringExtra("USER_ID"));
                startActivity(intent);
            }
        });
        follower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfilePage.this, FollowerListActivity.class);
                intent.putExtra("userId", getIntent().getStringExtra("USER_ID"));
                startActivity(intent);
            }
        });
        findViewById(R.id.foText).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfilePage.this, FollowingListActivity.class);
                intent.putExtra("userId", getIntent().getStringExtra("USER_ID"));
                startActivity(intent);
            }
        });
        following.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfilePage.this, FollowingListActivity.class);
                intent.putExtra("userId", getIntent().getStringExtra("USER_ID"));
                startActivity(intent);
            }
        });

        pagerAdapter = new PagerAdapter(getSupportFragmentManager());
        ans_url = new ArrayList<>();
        mViewPager = (ViewPager) findViewById(R.id.container);
        setupViewPager(mViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
//        notification.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivityForResult(new Intent(getApplicationContext(), NotificationActivity.class), code);
//                Bundle bundle = new Bundle();
//                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "notificationActivity");
//                mFirebaseAnalytics.logEvent("notificationIntent", bundle);
//            }
//        });
//        notificationActive.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivityForResult(new Intent(getApplicationContext(), NotificationActivity.class), code);
//                Bundle bundle = new Bundle();
//                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "notificationActivity");
//                mFirebaseAnalytics.logEvent("notificationIntent", bundle);
//            }
//        });
        bottomBar();
    }

    private void bottomBar() {
        bottomNavigationView.getMenu().findItem(R.id.action_profile).setChecked(true);
        final View viewprof = findViewById(R.id.profile_pic);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_new_home:
                        bottomNavigationView.getMenu().findItem(R.id.action_new_home).setChecked(true);
                        Intent intent = new Intent(ProfilePage.this, newHomeFeed.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        break;
                    case R.id.action_home:
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
                        Intent intent1 = new Intent(ProfilePage.this, HomeFeed.class);
                        startActivityForResult(intent1, 0);
                        break;
                        /*
                        case R.id.action_video:
                            finish();
                            Intent videoScreen = new Intent(viewprof.getContext(), FullscreenActivity.class);
                            startActivityForResult(videoScreen, 0);
                            break;

                         */
                    case R.id.action_notif:
                        Intent i = new Intent(getApplicationContext(), NotificationActivity.class);
                        startActivityForResult(i,0);
                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "notificationActivity");
                        mFirebaseAnalytics.logEvent("notificationIntent", bundle);
                        break;
                    case R.id.action_post:
                        bottomNavigationView.getMenu().findItem(R.id.action_post).setCheckable(false);
                        startActivity(new Intent(getApplicationContext(), Add_Answer.class));
                        break;
                    case R.id.action_profile:
                        break;


                }
                return true;


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        bottomBar();
    }

    private void setupViewPager(ViewPager viewPager) {
        PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
        //adapter.addFragment(new QuesNAnsProfile(), "TAB1");

        adapter.addFragment(UserProfilePosts.newInstance(askedUserId), "POSTS");
        //adapter.addFragment(new UserProfilePosts(null), "POSTS");

        //new UserProfilePosts();
        //adapter.addFragment(new BookmarkVideosProfile(), "TAB2");
        //adapter.addFragment(new TopicFollowing(), "CLANS");
        if (askedUserId.equals(LoggedInUser.userId)) {
            userClans = UserClans.newInstance2(auth_token, true);
            adapter.addFragment(userClans, "CLANS");
        }
        viewPager.setAdapter(adapter);
    }

    UserClans getUserClansClass() {
        return userClans;
    }

    private void alertBuilder() {

        AlertDialog.Builder builder = new AlertDialog
                .Builder(ProfilePage.this);
        builder.setMessage("Do you want to Logout ?");
        builder.setTitle("Alert !");
        builder.setCancelable(false);
        builder.setPositiveButton(
                "Yes",
                new DialogInterface
                        .OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog,
                                        int which) {

                        logout();
                    }
                });
        builder.setNegativeButton(
                "No",
                new DialogInterface
                        .OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog,
                                        int which) {

                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "logoutCancelled");
                        mFirebaseAnalytics.logEvent("logoutCancelled", bundle);
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void setUserDetails() {
        setData();
    }

    public void getUserDetails() {

        get_user_det_url = BASE_URL + "/api/user/" + askedUserId;

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(get_user_det_url)
                .method("GET", null)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e(TAG, e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                if (response.isSuccessful()) {
                    try {
                        String resp = response.body().string();
                        Log.d(TAG, "Response body: " + resp);
                        data = new JSONObject(resp);
                        Log.d(TAG, "User_DATA: " + data.getJSONObject("data"));
                        ProfilePage.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (data != null) {
                                    setData();
                                    setfollowbutton();
                                }

                            }
                        });
                        response.body().close();
                    } catch (Exception e) {
                        Log.e(TAG, e.getMessage())
                        ;
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }

                }
            }
        });


    }

    private void setfollowbutton() {
        try {
            Log.d("LOG_DATA", "Following?: " + data.getJSONObject("metaData").getString("amIfollowingThisUser"));
            if (data.getJSONObject("metaData").getString("amIfollowingThisUser").equals("true")) {
                unfollow.setVisibility(View.VISIBLE);
            } else {
                followButton.setVisibility(View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setData() {
        try {
            name = findViewById(R.id.name);
            username = findViewById(R.id.username);
            follower = findViewById(R.id.follower);
            following = findViewById(R.id.following);
            upvoteCount = findViewById(R.id.upvote);

            if (askedUserId.equals(LoggedInUser.userId)) {
                name.setText(LoggedInUser.userName);
                username.setText(LoggedInUser.userName);
                //JSONArray followers = LoggedInUser.userfollowers;
                //int countFollowers = followers.length();
                follower.setText("" + LoggedInUser.followers);
                following.setText("" + LoggedInUser.following);
                upvoteCount.setText("" + LoggedInUser.totalUpvotes);
                //profilePicUrl = LoggedInUser.userProfileImage;
                setProfilePic(true);
            } else {
                name.setText(data.getJSONObject("data").getString("name"));
                username.setText(data.getJSONObject("data").getString("name"));
                //JSONArray followers = data.getJSONObject("data").getJSONArray("followers");
                //int countFollowers = followers.length();
                follower.setText("" + data.getJSONObject("data").getInt("followers"));
                following.setText("" + data.getJSONObject("data").getInt("following"));
                upvoteCount.setText("" + data.getJSONObject("metaData").getInt("upvotes"));
                Log.d(TAG, "countFollowers ----->" + data.getJSONObject("data").getInt("followers"));
                setProfilePic(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
    }

    private void setProfilePic(boolean loggedUser) {
        try {
            if (loggedUser) {
                String profileUserIdUrl = BASE_URL + "/app/profilePic/" + LoggedInUser.userId + ".jpg";
                Glide.with(getApplicationContext())
                        .load(profileUserIdUrl)
                        .placeholder(R.drawable.propic1)
                        .into(profilePic);
//                Picasso.get()
//                            .load(profileUserIdUrl)
//                            .placeholder(R.drawable.propic1)
//                            .into(profilePic);
                profilePic.setPadding(0, 0, 0, 0);

            } else {
                String profileUserIdUrl = BASE_URL + "/app/profilePic/" + getIntent().getStringExtra("USER_ID") + ".jpg";
                Glide.with(this)
                        .load(profileUserIdUrl)
                        .placeholder(R.drawable.propic1)
                        .into(profilePic);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
    }

    private void updateMetaData() {
        try {
            get_user_det_url = BASE_URL + "/api/user/" + askedUserId;
            JSONObject postObj = new JSONObject();
            if (unfollow.getVisibility() == View.VISIBLE) {
                Toast.makeText(getApplicationContext(), "Followed", Toast.LENGTH_SHORT).show();
                postObj.put("id", askedUserId);
                OkHttpClient client = new OkHttpClient().newBuilder()
                        .build();
                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, "{\n\t\"userId\": \"" + askedUserId + "\"\n}");
                Request request = new Request.Builder()
                        .url(BASE_URL + "/api/follow/follow")
                        .method("POST", body)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                        .build();

                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        try {
                            Log.e("LOG_DATA", e.getMessage());
                            e.printStackTrace();
                            unfollow.setVisibility(View.INVISIBLE);
                            followButton.setVisibility(View.VISIBLE);
                            int followerCount = Integer.parseInt(follower.getText().toString()) + 1;
                            follower.setText("" + followerCount);
                        } catch (Exception x) {
                            Log.e("LOG_DATA", x.getMessage());
                        }

                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            try {
                                Log.d("LOG_DATA", "Response String: " + response.toString());
                                String resp = response.body().string();
                                JSONObject result = new JSONObject(resp);
                                LoggedInUser.following = LoggedInUser.following + 1;
                                Log.d("LOG_DATA", "Result : " + result.toString());
                                Log.d("LOG_DATA", result.getJSONObject("data").get("subject").toString());
                                Log.d("LOG_DATA", "notification-user_following-" + result.getJSONObject("data").get("subject").toString());
//                                FirebaseMessaging.getInstance().subscribeToTopic("notification-user_following-"+ result.getJSONObject("data").get("subject").toString());
                                response.body().close();
                            } catch (Exception e) {
                                e.printStackTrace();

                                Crashlytics.log(e.toString());
                            }

                        } else {

                        }
                    }
                });
            } else if (followButton.getVisibility() == View.VISIBLE) {
                Toast.makeText(getApplicationContext(), "Unfollowed", Toast.LENGTH_SHORT).show();
                OkHttpClient client = new OkHttpClient().newBuilder()
                        .build();
                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, "{\n\t\"userId\": \"" + askedUserId + "\"\n}");
                Request request = new Request.Builder()
                        .url(BASE_URL + "/api/follow/unfollow")
                        .method("POST", body)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                        .build();

                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        try {
                            Log.e("LOG_DATA", e.getMessage());
                            e.printStackTrace();
                            unfollow.setVisibility(View.VISIBLE);
                            followButton.setVisibility(View.INVISIBLE);
                            int followerCount = data.getJSONObject("data").getInt("followers") - 1;
                            follower.setText("" + followerCount);
                        } catch (Exception x) {
                            Log.e("LOG_DATA", e.getMessage());
                        }
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            try {
                                Log.d("LOG_DATA", "Response String: " + response.toString());
                                String resp = response.body().string();
                                JSONObject result = new JSONObject(resp);
                                LoggedInUser.following = LoggedInUser.following - 1;
                                Log.i("LOG_DATA", "Result : " + result.toString());
                                Log.d("LOG_DATA", "Follower ID:" + result.getString("data"));
                                Log.d("LOG_DATA", "notification-user_following-" + result.getString("data"));
                                //FirebaseMessaging.getInstance().unsubscribeFromTopic("revidly-user-"+LoggedInUser.userId);
//                                FirebaseMessaging.getInstance().unsubscribeFromTopic("notification-user_following-"+ result.getString("data"));
                                response.body().close();
                            } catch (Exception e) {
                                Log.e("LOG_DATA", e.getMessage());
                            }
                        } else {
                            unfollow.setVisibility(View.VISIBLE);
                            followButton.setVisibility(View.INVISIBLE);
                        }
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("LOG_DATA", e.getMessage());

            Crashlytics.log(e.toString());
        }

    }

    private void logout() {
        Utils.removeLoginAuthToken(getApplicationContext());
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "logout");
        mFirebaseAnalytics.logEvent("logoutClicked", bundle);
        startActivity(new Intent(getApplicationContext(), SplashScreenActivity.class));
        Log.d("HomeActivity", "logout Called");
        AccessToken fbAccessToken = AccessToken.getCurrentAccessToken();
        if (fbAccessToken != null) {
            Log.d("LOG_DATA", "Logged out");
            LoginManager.getInstance().logOut();
        }
    }

    public static synchronized ProfilePage getInstance() {
        return mInstance;
    }

    public void refreshHomeFeed() {
        HomeFeed.getInstance().setHomeFeed();
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    private void playLink() {
        String link = "https://market.android.com/details?id=co.revidly.android&referrer='Kiki'";
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_TEXT, link);
        intent.setType("text/plain");
        startActivity(intent);
    }

    //    private void checkNotificationStatus() {
//        String url = BASE_URL + "/api/pushnotif/unreadStatus";
//        OkHttpClient client = new OkHttpClient().newBuilder()
//                .build();
//        Request request = new Request.Builder()
//                .url(url)
//                .method("GET", null)
//                .addHeader("Authorization", LoggedInUser.auth_token_global)
//                .build();
//        Call call = client.newCall(request);
//        call.enqueue(new Callback() {
//            @Override
//            public void onFailure(@NotNull Call call, @NotNull IOException e) {
//                Log.e("LOG_MSG", e.getMessage());
//                e.printStackTrace();
//            }
//
//            @Override
//            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
//                try {
//                    data = new JSONObject();
//                    String resp = response.body().string();
//                    JSONObject resultObject = new JSONObject(resp);
//                    Log.d("LOG_MSG", "Result: " + resultObject);
//                    Log.d("LOG_MSGS", "Unread: " + resultObject.optBoolean("unread_notification_exist"));
//                    final Boolean isUnRead = resultObject.optBoolean("unread_notification_exist");
//                    Handler mainHandler;
//                    mainHandler = new Handler(getMainLooper());
//                    mainHandler.post(new Runnable() {
//                        @Override
//                        public void run() {
//                            try {
//                                if (isUnRead) {
//                                    notificationActive.setVisibility(View.VISIBLE);
//                                    notification.setVisibility(View.INVISIBLE);
//                                } else {
//                                    notification.setVisibility(View.VISIBLE);
//                                    notificationActive.setVisibility(View.INVISIBLE);
//                                }
//                            } catch (Exception e) {
//                                Log.e("LOG_DATA", e.getMessage());
//                                e.printStackTrace();
//                            }
//                        }
//                    });
//
//
//                } catch (Exception e) {
//                    Log.e("LOG_MSG", e.getMessage());
//                    e.printStackTrace();
//                }
//            }
//        });
//    }
    private void checkNotificationStatus() {
        String url = BASE_URL + "/api/pushnotif/unreadStatus";
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Authorization", LoggedInUser.auth_token_global)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("LOG_MSG", e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull okhttp3.Response response) throws IOException {
                try {
                    JSONObject data = new JSONObject();
                    String resp = response.body().string();
                    JSONObject resultObject = new JSONObject(resp);
                    Log.d("LOG_MSG", "Result: " + resultObject);
                    Log.d("LOG_MSGS", "Unread: " + resultObject.optBoolean("unread_notification_exist"));
                    final Boolean isUnRead = resultObject.optBoolean("unread_notification_exist");
                    Handler mainHandler;
                    mainHandler = new Handler(getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if (isUnRead) {
                                    bottomNavigationView.getMenu().getItem(3).setIcon(R.drawable.notification_blank_dot);
                                } else {
                                    bottomNavigationView.getMenu().getItem(3).setIcon(R.drawable.ic_notifications);
                                }
                            } catch (Exception e) {
                                Log.e("LOG_DATA", e.getMessage());
                                e.printStackTrace();
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("LOG_MSG", e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }

}


