package co.revidly.android;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;

import com.crashlytics.android.Crashlytics;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.ClanSelector;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

public class UserClans extends Fragment
{
    private static final String TAG = "Fragment:UserClans";
    String topics;
    UserClansAdapter adapter;
    RecyclerView recyclerView;
    static int fvi;

    Button submit;
    TextView titleText, descText;
    String activity="";
    ScrollView mScroller;
    ConstraintLayout fragmentCL;

    String HOMEFEED = "HOME_FEED";
    String COMMUNITYFEED = "COMUNITY_FEED";
    String PROFILEPAGE = "PROFILE_PAGE";
    private FirebaseAnalytics mFirebaseAnalytics;

    Context mContext;
    static String auth_token_local;

    ProgressDialog progressDialog;
    EditText searchText;
    List<JSONObject> mlist;
    List<String> mSelected;
    ClanSelector clanSelector;
    List<String> userTopicSelectedList;

    boolean selectedTopics;
    private boolean isselectedTopicAdmin=false;

    public static UserClans newInstance1(String auth_token)
    {
        UserClans UC = new UserClans();
        Bundle args = new Bundle();
        args.putString("auth_token", auth_token);
        args.putBoolean("selectedTopics",false);
        UC.setArguments(args);
        return UC;
    }
    public static UserClans newInstance2(String auth_token, boolean selectedTopics)
    {
        UserClans UC = new UserClans();
        Bundle args = new Bundle();
        args.putString("auth_token", auth_token);
        args.putBoolean("selectedTopics",selectedTopics);
        UC.setArguments(args);
        return UC;
    }

//    @Override
//    public void onAttach(@NonNull Context context) {
//        super.onAttach(context);
//        mContext=context;
//    }

    private void readBundle(Bundle bundle) {
        if (bundle != null) {
            mContext = getActivity();
            auth_token_local = bundle.getString("auth_token");
            selectedTopics = bundle.getBoolean("selectedTopics");
            mlist = new ArrayList<>();
            mSelected = new ArrayList<>();
            try {
                if (LoggedInUser.userTopics != null) {
                    for (int i = 0; i < LoggedInUser.userTopics.length(); i++) {
                        mSelected.add(LoggedInUser.userTopics.getJSONObject(i).optString("topicId"));
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            userTopicSelectedList = new ArrayList<>();
            clanSelector = new ClanSelector(mSelected);
            Log.d("ClanSelectorF", clanSelector.getSelectedTopics().toString());
            adapter = new UserClansAdapter(mContext, mlist, clanSelector, selectedTopics);
            if (mContext instanceof HomeFeed)
                activity = HOMEFEED;
            else if(mContext instanceof CommunityFeed)
                activity=COMMUNITYFEED;
            else if (mContext instanceof ProfilePage)
                activity = PROFILEPAGE;
            mFirebaseAnalytics = FirebaseAnalytics.getInstance(mContext);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        final View view = inflater.inflate(R.layout.fragment_user_clans,container,false);
        readBundle(getArguments());
        searchText = view.findViewById(R.id.searchClans);
        setGlobals(view);
        if(activity.equals(COMMUNITYFEED))
            getActivity().findViewById(R.id.addClan).setVisibility(View.GONE);
        //setRecyclerView(view);
        if(selectedTopics && activity.equals(PROFILEPAGE))
        {
            getSelectedTopics();
            setRecyclerView(view);
            searchText.setVisibility(View.GONE);
        }
        else if(selectedTopics && activity.equals(HOMEFEED)) {
            getSelectedTopics();
            setHomeFeedRecyclerView(view);
            Log.d(TAG, "I am inside UserClans SelectedTopics & HomeFeed");
            searchText.setVisibility(View.GONE);

        }
        else {
            get_AllTopics();
            setRecyclerView(view);
            searchText.setVisibility(View.GONE);
        }
        if(!selectedTopics && (activity.equals(HOMEFEED) || activity.equals(COMMUNITYFEED))){
            searchText.setVisibility(View.VISIBLE);
            searchText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    filter(charSequence.toString(),view);
                }

                @Override
                public void afterTextChanged(Editable editable) {
//                filter(editable.toString(),view);
                }
            });
        }


        return view;
    }
    void filter(String text,View view){
        List<JSONObject> filteredList = new ArrayList<>();
        if(text.isEmpty()){
            filteredList = mlist;
        }
        else {
            for (int i = 0; i < mlist.size(); i++) {
                JSONObject object = mlist.get(i);
                if (object.optString("name").toLowerCase().contains(text.toLowerCase())) {
                    filteredList.add(object);
                }
            }
        }
        Log.d("FilteredList", filteredList.toString());
        if(filteredList.isEmpty()){
            view.findViewById(R.id.user_clans_rec).setVisibility(View.GONE);
            view.findViewById(R.id.noClans).setVisibility(View.VISIBLE);
        }
        else {
            view.findViewById(R.id.user_clans_rec).setVisibility(View.VISIBLE);
            List<String> clanSelector = adapter.clanSelector.getSelectedTopics();
            Log.d("ClanSelectorListA", clanSelector.toString());
            adapter = new UserClansAdapter(mContext, filteredList, new ClanSelector(clanSelector), false);
            recyclerView.setAdapter(adapter);
//            adapter.filterList(filteredList);
            view.findViewById(R.id.noClans).setVisibility(View.GONE);
        }
    }

    void setGlobals(View view)
    {


        titleText = view.findViewById(R.id.title_text);
        descText = view.findViewById(R.id.desc_text);
        submit = view.findViewById(R.id.submit);
        fragmentCL = view.findViewById(R.id.widthToBeSetLayout);
        //mScroller = view.findViewById(R.id.scroll_view);


        if(activity.equals(HOMEFEED) && !selectedTopics)
        {

            titleText.setVisibility(View.VISIBLE);
            descText.setVisibility(View.VISIBLE);
            submit.setVisibility(View.VISIBLE);
            int marginBottom = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 60, mContext.getResources().getDisplayMetrics());
            ConstraintLayout.LayoutParams param = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT,ConstraintLayout.LayoutParams.MATCH_PARENT);
            param.setMargins(0,0,0, marginBottom);
            fragmentCL.setLayoutParams(param);
            //submit.setText("Choose your Clans");

            View decorView = ((HomeFeed)mContext).getWindow().getDecorView();
            // Hide both the navigation bar and the status bar.
            // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
            // a general rule, you should design your app to hide the status bar whenever you
            // hide the navigation bar.
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
/*
            mScroller.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    Log.d("UserClans", "Inside Scroll onTouch true");
                    return true;
                }
            });

 */

        }
        else if(activity.equals(HOMEFEED) && selectedTopics)
        {
            titleText.setVisibility(View.GONE);
            descText.setVisibility(View.GONE);
            submit.setVisibility(View.GONE);
        }
        else if(activity.equals(PROFILEPAGE))
        {
            titleText.setVisibility(View.GONE);
            descText.setVisibility(View.GONE);
            submit.setVisibility(View.GONE);


            //submit.setText("Update your Clans");
            //submit.setText("Update Clans");

            View decorView = ((ProfilePage)mContext).getWindow().getDecorView();
            // Hide both the navigation bar and the status bar.
            // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
            // a general rule, you should design your app to hide the status bar whenever you
            // hide the navigation bar.
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
/*
            mScroller.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    Log.d("UserClans", "Inside Scroll onTouch false");
                    return false;
                }
            });

 */
        }

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("UserClans", "Save Selected Clans Pressed");
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"submit");
                mFirebaseAnalytics.logEvent("submitClicked",bundle);

                try {
                    Log.d("UserClans", "try");
                    userTopicSelectedList = clanSelector.getSelectedTopics();
                    for (int i = 0; i < userTopicSelectedList.size(); i++) {
                        Log.d(TAG, "IDD:" + userTopicSelectedList.get(i));
                        Log.d("LOG_DATA", "DATA: " + "notification-post_trending-" + userTopicSelectedList.get(i).toString());
                    }
                    if (userTopicSelectedList.size() != 0) {
                        Log.d("UserClans", "!=0");
//                        userTopicSelected.put("topicIds", topicsArray);
                        Log.d(TAG, "IDS: " + userTopicSelectedList);
//                        Log.d(TAG, "final topics Object = " + userTopicSelected);
                        if(LoggedInUser.isTopicAdmin){
                            checkAdminTopic();
                        }
                        else{
                            insertUserTopics();
                        }

                    }
                    else {
                        createAlertDialog("No Clan Selected",
                                "Select at least one Clan.\nDon't worry you will be able to change it later.");
                    }
                }
                catch(Exception e){
                    e.printStackTrace();
                    Crashlytics.logException(e);
                }
            }
        });
    }
    void setRecyclerView(View view) {
        recyclerView = view.findViewById(R.id.user_clans_rec);
        adapter.setHasStableIds(true);
        recyclerView.setAdapter(adapter);

        //recyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false));
        recyclerView.setLayoutManager(new GridLayoutManager(mContext, 2, GridLayoutManager.VERTICAL, false));

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(true);
        final LinearLayoutManager layoutManager=new LinearLayoutManager(mContext);
        ////itemTouchHelper.attachToRecyclerView(recyclerView);
        recyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            /*
            if (newState == RecyclerView.SCROLL_STATE_DRAGGING || newState == RecyclerView.SCROLL_STATE_SETTLING || newState == RecyclerView.SCROLL_STATE_IDLE) {
                adapter.onScrolled(recyclerView);
            }
             */
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                fvi=layoutManager.findFirstCompletelyVisibleItemPosition();
                if(fvi==RecyclerView.NO_POSITION)
                    fvi=layoutManager.findFirstVisibleItemPosition();

            }
        });

    }

    void setHomeFeedRecyclerView(View view) {
        recyclerView = view.findViewById(R.id.user_clans_rec);
        Log.d(TAG, "I am inside setHomeFeedRecyclerView after homefeed_user_clan");
        adapter.setHasStableIds(true);
        recyclerView.setAdapter(adapter);

        recyclerView.setLayoutManager(new GridLayoutManager(mContext, 1, GridLayoutManager.HORIZONTAL, false));
        //recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.HORIZONTAL));
        Log.d(TAG, "I am inside setHomeFeedRecyclerView after layout manager");
        //recyclerView.setLayoutManager(new GridLayoutManager(mContext, 2, GridLayoutManager.VERTICAL, false));

        recyclerView.setHasFixedSize(true);
        recyclerView.setNestedScrollingEnabled(true);
        final LinearLayoutManager layoutManager=new LinearLayoutManager(mContext);
        ////itemTouchHelper.attachToRecyclerView(recyclerView);
        recyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            /*
            if (newState == RecyclerView.SCROLL_STATE_DRAGGING || newState == RecyclerView.SCROLL_STATE_SETTLING || newState == RecyclerView.SCROLL_STATE_IDLE) {
                adapter.onScrolled(recyclerView);
            }
             */
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                fvi=layoutManager.findFirstCompletelyVisibleItemPosition();
                if(fvi==RecyclerView.NO_POSITION)
                    fvi=layoutManager.findFirstVisibleItemPosition();

            }
        });

    }
    void communityOnClick(JSONArray topicsArray) {
        Log.d(TAG, "topicsArray = " + topicsArray.toString());
        Intent intent = new Intent(mContext, CommunityFeed.class);
        intent.putExtra("COMMUNITY_TOKEN", topicsArray.toString());
        if (mContext instanceof HomeFeed) {
            intent.putExtra("HomeFlag",true);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        }
        else             intent.putExtra("HomeFlag",false);
        mContext.startActivity(intent);
//        ((ProfilePage) mContext).finish();

    }
    void getSelectedTopics() {
        try {
            mlist.clear();
            for (int i = 0; i < LoggedInUser.userTopics.length(); i++) {
                mlist.add(LoggedInUser.userTopics.getJSONObject(i));
                Log.d(TAG,  " ->get_Selectedtopics() " + LoggedInUser.userTopics.getJSONObject(i));
            }
            Log.d(TAG, " ->get_Selectedtopics() mList: " + mlist.toString());
            //clanSelector.setAllTopics(mlist);
            adapter.notifyDataSetChanged();
        }
        catch  (Exception e)
        {
            e.printStackTrace();
        }
    }

    void get_AllTopics() {
        OkHttpClient client = new OkHttpClient();

        Handler mainHandler;
        mainHandler = new Handler(mContext.getMainLooper());
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog = ProgressDialog.show(mContext,
                        "Loading Clans..",
                        "Getting our curated clans for you.\n Please Wait...");
            }
        });


        Request request = new Request.Builder()
                .url(BASE_URL+"/api/topic?orderBy=popularityRank&orderDirection=1")
                .get()
                .addHeader("Authorization", auth_token_local)
                .addHeader("Host", BASE_HOST)
                .addHeader("Connection", "keep-alive")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i(TAG, "Response "+response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    throw new IOException("Unexpected code " + response);
                } else {
                    final String resp = response.body().string();
                    mlist.clear();
                    try {
                        JSONObject resultObject = new JSONObject(resp);
                        Log.d(TAG, "JSON getClans result-->"+ resultObject.toString());
                        JSONArray result = resultObject.getJSONArray("data");
                        for (int i = 0; i < result.length(); i++) {
                            final JSONObject obj = result.getJSONObject(i);
                            mlist.add(obj);
                            Log.d(TAG, "UserClans->get_topics() After adding object to obj");
                            Log.i(TAG, "Topic Name : "+obj.getString("name"));
                            Log.i(TAG, "Topic ID : "+obj.getString("_id"));


                        }
//                        clanSelector.setAllTopics(mlist);

                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                                //mShimmerFrameLayout.stopShimmer();
                                //mShimmerFrameLayout.setVisibility(View.GONE);
                                //progressDialog.dismiss();
                                adapter.notifyDataSetChanged();
                                if(progressDialog != null && progressDialog.isShowing())
                                    progressDialog.dismiss();
                                if( mContext instanceof HomeFeed)
                                    ((HomeFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.GONE);
                                //else if( mContext instanceof ProfilePage)
                                //((ProfilePage) mContext).findViewById(R.id.nullanswers).setVisibility(View.GONE);
                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (resp.equals("NO ANSWERS"))
                                    //mShimmerFrameLayout.stopShimmer();
                                    //mShimmerFrameLayout.setVisibility(View.GONE);
                                    if( mContext instanceof HomeFeed)
                                        ((HomeFeed) mContext).findViewById(R.id.nullanswers).setVisibility(View.VISIBLE);
                                // else if( mContext instanceof ProfilePage)
                                //   ((ProfilePage) mContext).findViewById(R.id.nullanswers).setVisibility(View.VISIBLE);
                            }
                        });
                    }
                    Log.i(TAG, "Response:"+ response.toString());
                    Log.i(TAG, "Response body:"+ response.body().toString());
                    Log.i(TAG, "Response String: "+ resp);
                    Log.i(TAG, "Response message:"+ response.message());
                    response.body().close();
                }
            }
        });
    }
    void insertUserTopics() {
        MediaType mediaType = MediaType.parse("application/json");
        JSONObject obj = new JSONObject();
        JSONArray arr = new JSONArray();
        for (int i = 0; i < clanSelector.getSelectedTopics().size(); i++) {
            arr.put(clanSelector.getSelectedTopics().get(i).toString());
            Log.d("FinalObject","\""+clanSelector.getSelectedTopics().get(i)+"\"");
        }
        try {
            obj.put("topicIds", arr);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.d("FinalObject", obj.toString());
        RequestBody body = RequestBody.create(mediaType, obj.toString());

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/user/updateTopics")
                .post(body)
                .addHeader("Authorization", auth_token_local)
                .addHeader("Host", BASE_HOST)
                .addHeader("Connection", "keep-alive")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback(){
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i(TAG, "Response " + response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    throw new IOException("Unexpected code " + response);
                } else {
                    final String resp = response.body().string();
                    //mlist.clear();
                    try {
                        JSONObject resultObject = new JSONObject(resp);
                        Log.d(TAG, "insertUsertTopics-->" + resultObject.toString());
                        JSONArray topics = LoggedInUser.userTopics;
                        for (int i = 0; i < topics.length(); i++) {
                            JSONObject data = topics.getJSONObject(i);
                            Log.d("InsertUserTopics", "Unsubscribed to Topic ID: " + data.getString("name"));
                            FirebaseMessaging.getInstance().unsubscribeFromTopic("notification-post_trending-" + data.getString("topicId"));
                        }
                        LoggedInUser.userTopics = resultObject.getJSONArray("message");
                        for (int i = 0; i < LoggedInUser.userTopics.length(); i++) {
                            JSONObject data = LoggedInUser.userTopics.getJSONObject(i);

                            Log.d("InsertUserTopics", "Subscribed to Topic ID: " + data.getString("name"));
                            FirebaseMessaging.getInstance().subscribeToTopic("notification-post_trending-" + data.getString("topicId"));
                        }
                        Log.d("InsertUserTopics", "insertUsertTopics-->" + LoggedInUser.userTopics.toString());
                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                                //mShimmerFrameLayout.stopShimmer();
                                //mShimmerFrameLayout.setVisibility(View.GONE);
                                //progressDialog.dismiss();
                                //adapter.notifyDataSetChanged();
                                //progressDialog.dismiss();
                                //if( mContext instanceof HomeFeed)

                                    /*Uncomment below 2 lines to remove UserClans fragment*/
                                if (mContext instanceof newHomeFeed || mContext instanceof NotificationActivity) {
//                                        HomeFeed.getInstance().setHomeFeed();
//                                        if (getFragmentManager() != null) {
//                                            getFragmentManager().beginTransaction().remove(UserClans.this).commit();
//                                        }
                                    Intent intent=new Intent(mContext,newHomeFeed.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);

                                }
                                    if (mContext instanceof HomeFeed) {
//                                        HomeFeed.getInstance().setHomeFeed();
//                                        if (getFragmentManager() != null) {
//                                            getFragmentManager().beginTransaction().remove(UserClans.this).commit();
//                                        }
                                        Intent intent=new Intent(mContext,newHomeFeed.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);

                                    }
                                if (mContext instanceof CommunityFeed) {
                                    Intent intent = new Intent(mContext, newHomeFeed.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                } else if (mContext instanceof ProfilePage) {
                                        ProfilePage.getInstance().refreshHomeFeed();
                                    }

                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                    Log.i(TAG, "Response:" + response.toString());
                    Log.i(TAG, "Response body:" + response.body().toString());
                    Log.i(TAG, "Response String: " + resp);
                    Log.i(TAG, "Response message:" + response.message());
                    response.body().close();
                }
            }
        });
    }

    private void checkAdminTopic(){
        try{
            JSONArray adminTopics = LoggedInUser.topicAdmin;
            List<String> selectedTopic = userTopicSelectedList;
            Log.d("LOG_DATA","selectedTopic: "+selectedTopic);
            Log.d("LOG_DATA","selectedTopicID: "+selectedTopic.get(0));
            for(int i=0;i<adminTopics.length();i++){
//                for(int j=0;j<selectedTopic.length();j++){
                Log.d("AdminTopics", adminTopics.toString());
                if (selectedTopic.contains(adminTopics.optJSONObject(i).optString("topicId"))) {
                        Log.d("LOG_DATA","MATCH FOUND");
                        isselectedTopicAdmin=true;
//                    }
                } else {
                    isselectedTopicAdmin = false;
                }
            }
            if(isselectedTopicAdmin){
                Log.d("UserClans", "insert");
                insertUserTopics();
            }
            else{
                createAlertDialog("You are the admin of topic ","Please don't deselect the clan to which you are admin.");
            }
        }

        catch (Exception e){
            Log.d("LOG_DATA",e.getMessage());
            e.printStackTrace();
        }
    }

    private void createAlertDialog(final String title, final String message){
        Handler mainHandler;
        mainHandler = new Handler(mContext.getMainLooper());
        mainHandler.post(new Runnable(){
            @Override
            public void run() {
                new AlertDialog.Builder(mContext)
                        .setTitle(title)
                        .setMessage(message)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                adapter.notifyDataSetChanged();
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setCancelable(false)
                        .show();
            }
        });
    }


}
