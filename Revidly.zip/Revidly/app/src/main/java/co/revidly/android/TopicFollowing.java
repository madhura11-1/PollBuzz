package co.revidly.android;

import com.crashlytics.android.Crashlytics;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.io.IOException;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class TopicFollowing extends Fragment
{
    private static final String TAG = "TopicFollowing";
    Button tp1_NA,tp2_NA,tp3_NA,tp4_NA,tp5_NA,tp6_NA,tp7_NA;
    private boolean bt1_sel=false,bt2_sel=false,bt3_sel=false,bt4_sel=false,bt5_sel=false,bt6_sel=false,bt7_sel=false;
    String topics;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        final View view = inflater.inflate(R.layout.fragment_topic_following,container,false);
        tp1_NA = view.findViewById(R.id.topic1_NA);
        tp2_NA = view.findViewById(R.id.topic2_NA);
        tp3_NA = view.findViewById(R.id.topic3_NA);
        tp4_NA = view.findViewById(R.id.topic4_NA);
        tp5_NA = view.findViewById(R.id.topic5_NA);
        tp6_NA = view.findViewById(R.id.topic6_NA);
        tp7_NA = view.findViewById(R.id.topic7_NA);
        getTopics();

        tp1_NA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(bt1_sel==false)
                {
                    changeToGreen(tp1_NA);
                    bt1_sel = true;
                }

                else
                {
                    changeToRed(tp1_NA);
                    bt1_sel = false;
                }



            }
        });

        tp2_NA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(bt2_sel==false) {
                    changeToGreen(tp2_NA);
                    bt2_sel = true;
                }

                else {
                    changeToRed(tp2_NA);
                    bt2_sel = false;
                }
            }
        });


        tp3_NA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(bt3_sel==false) {
                    changeToGreen(tp3_NA);
                    bt3_sel = true;
                }

                else {
                    changeToRed(tp3_NA);
                    bt3_sel = false;
                }



            }
        });

        tp4_NA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(bt4_sel==false) {
                    changeToGreen(tp4_NA);
                    bt4_sel = true;
                }

                else {
                    changeToRed(tp4_NA);
                    bt4_sel = false;
                }



            }
        });

        tp5_NA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(bt5_sel==false) {
                    changeToGreen(tp5_NA);
                    bt5_sel = true;
                }

                else {
                    changeToRed(tp5_NA);
                    bt5_sel = false;
                }



            }
        });

        tp6_NA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(bt6_sel==false) {
                    changeToGreen(tp6_NA);
                    bt6_sel = true;
                }

                else {
                    changeToRed(tp6_NA);
                    bt6_sel = false;
                }



            }
        });

        tp7_NA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(bt7_sel==false) {
                    changeToGreen(tp7_NA);
                    bt7_sel = true;
                }

                else {
                    changeToRed(tp7_NA);
                    bt7_sel = false;
                }



            }
        });
        return view;
    }

    private void changeToRed(Button button)
    {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setStroke(5, Color.parseColor("#EE2929"));
        drawable.setColor(Color.WHITE);
        button.setBackgroundDrawable(drawable);
    }

    private void changeToGreen(Button button)
    {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setStroke(5, Color.parseColor("#d1fd8b"));
        drawable.setColor(Color.WHITE);
        button.setBackgroundDrawable(drawable);
    }

    private void getTopics(){
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url("https://dev-api.revidly.co/api/app/gettopics")
                .method("GET", null)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZGVlNjA5NjJmYzFiMzJhNzg1ODJiN2YiLCJuYW1lIjoia2FydGlrIiwicGhvbmUiOm51bGwsImVtYWlsIjoidGVzdDEyQGdtYWlsLmNvbSIsInBlcm1pc3Npb25zIjpbXSwiaWF0IjoxNTc4MDczODQ0LCJleHAiOjE1Nzg2Nzg2NDR9.zkwOnhDceZqVgAu0C1rEfXzS0JHkpMxd1WQBJ5yJc88")
                .build();


        Call call = client.newCall(request);
        call.enqueue(new Callback(){
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e(TAG,e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response){
                if (response.isSuccessful()) {
                    try {
                        String resp = response.body().string();
                        Log.d(TAG, "ID response" + resp);
                        JSONObject jsonObject = new JSONObject(resp);
                        Log.d(TAG, "ID: " + jsonObject.getString(""));
                        response.body().close();
                    } catch (Exception e) {
                        Log.e(TAG, e.getMessage());
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                }
            }
        });

    }

}
