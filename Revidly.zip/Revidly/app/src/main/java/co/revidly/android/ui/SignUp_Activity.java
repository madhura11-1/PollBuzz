package co.revidly.android.ui;

import com.crashlytics.android.Crashlytics;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import androidx.appcompat.app.AppCompatActivity;
import co.revidly.android.FullscreenActivity;
import co.revidly.android.R;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

public class SignUp_Activity extends AppCompatActivity implements View.OnClickListener {

    public static String auth_token = null;

    public Button btnSignup;
    public EditText etEmail, etPassword, etFirstName, etLastName;

    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        btnSignup = findViewById(R.id.btnSignup);
        etEmail = findViewById(R.id.email);
        etPassword = findViewById(R.id.password);
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        btnSignup.setOnClickListener(this);
    }

    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    void signup() {


        String name = etFirstName.getText().toString().trim() + " " + etLastName.getText().toString().trim();
        String username = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if(!username.isEmpty() && !password.isEmpty() && isValidEmail(username) && !name.isEmpty()) {
            dialog = ProgressDialog.show(this, "", "Loading. Please wait...", true);

            OkHttpClient client = new OkHttpClient();

            String url = BASE_URL + "/api/auth/signup";

            MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
            RequestBody body = RequestBody.create(mediaType, "name=" + name + "&username=" + username + "&password=" + password);
            Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .addHeader("Content-Type", "application/x-www-form-urlencoded")
                    .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                    .addHeader("Accept", "*/*")
                    .addHeader("Cache-Control", "no-cache")
                    .addHeader("Postman-Token", "9b50a30d-5911-4b58-8cf3-04a269b2c41e")
                    .addHeader("Host", BASE_HOST)
                    .addHeader("Accept-Encoding", "gzip, deflate")
                    .addHeader("Content-Length", "56")
                    .addHeader("Connection", "keep-alive")
                    .addHeader("cache-control", "no-cache")
                    .build();
            //Response response = client.newCall(request).execute();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            dialog.dismiss();
                            Toast.makeText(SignUp_Activity.this, "oops, something went wrong!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    System.out.println("Success : " + response.body().toString());
                    if (!response.isSuccessful()) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dialog.dismiss();
                                Toast.makeText(SignUp_Activity.this, "oops, something went wrong!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else {
                        Log.i("Response:", response.toString());
                        Log.i("Response body:", response.body().toString());
                        String resp = response.body().string();
                        Log.i("Response String: ", resp);
                        Log.i("Response message:", response.message());
                        try {
                            JSONObject res = new JSONObject(resp);
                            login();
                            response.body().close();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Crashlytics.logException(e);
                        }

                    }
                }
            });
        }
        else Toast.makeText(this, "Enter valid fields!", Toast.LENGTH_SHORT).show();
    }

    void login() {


        String username = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "/api/auth/signin";

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
            RequestBody body = RequestBody.create(mediaType, "username=" + username + "&password=" + password);
            Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .addHeader("Content-Type", "application/x-www-form-urlencoded")
                    .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                    .addHeader("Accept", "*/*")
                    .addHeader("Cache-Control", "no-cache")
                    .addHeader("Postman-Token", "75dcac22-9e90-4fd6-952c-0bd046d5ca5e,59f1b37b-32b8-456b-a828-6b3bd0300102")
                    .addHeader("Host", BASE_HOST)
                    .addHeader("Accept-Encoding", "gzip, deflate")
                    .addHeader("Content-Length", "56")
                    .addHeader("Connection", "keep-alive")
                    .addHeader("cache-control", "no-cache")
                    .build();
            //Response response = client.newCall(request).execute();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            dialog.dismiss();
                            Toast.makeText(SignUp_Activity.this, "oops, something went wrong!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    System.out.println("Success : " + response.body().toString());
                    if (!response.isSuccessful()) {
                        // You can also throw your own custom exception
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                dialog.dismiss();
                                Toast.makeText(SignUp_Activity.this, "oops, something went wrong!", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        Log.i("Response:", response.toString());
                        Log.i("Response body:", response.body().toString());
                        String resp = response.body().string();
                        Log.i("Response String: ", resp);
                        Log.i("Response message:", response.message());
                        try {
                            dialog.dismiss();
                            JSONObject res = new JSONObject(resp);
                            auth_token = res.getString("data");
                            Utils.setLoginAuthToken(SignUp_Activity.this, auth_token);
                            Log.i("Auth Token is ", auth_token);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    launchMainScreen();
                                }
                            });
                            response.body().close();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Crashlytics.logException(e);
                        }

                    }
                }
            });
    }

    private void launchMainScreen(){
        startActivity(new Intent(this, FullscreenActivity.class));
        finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSignup : { signup(); }
        }
    }
}
