package co.revidly.android;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.crashlytics.android.Crashlytics;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

public class addquessearchlistAdapter extends RecyclerView.Adapter<addquessearchlistAdapter.MyViewHolder> implements Filterable {
    Context mContext;
    List<JSONObject> mData;
    List<JSONObject> mDataFull;
    private Filter myFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            final List<JSONObject> filteredList = new ArrayList<>();

            if(constraint==null || constraint.length() == 0){
                filteredList.addAll(mDataFull);
            }else{
                String filterPattern = constraint.toString().toLowerCase().trim();

                /*for(questions item : mDataFull){
                    if(item.answers.toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }
                    else if(item.question.toLowerCase().contains(filterPattern)){
                        questions it = new questions();
                        it.question=item.question;
                        it.answers="";
                        it.ansname="";
                        filteredList.add(it);
                    }
                }*/


                OkHttpClient client = new OkHttpClient();
                try{
                    String url = BASE_URL  + "/api/app/getQuesByText?text="+filterPattern;
                    Request request = new Request.Builder()
                            .url(url)
                            .get()
                            .addHeader("Authorization", FullscreenActivity.auth_token)
                            .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                            .addHeader("Accept", "*/*")
                            .addHeader("Cache-Control", "no-cache")
                            .addHeader("Postman-Token", "a7f73585-77d4-48ea-959c-2028d773ecfe,89d9427c-320c-4de7-8a67-c2c09fad3597")
                            .addHeader("Host", BASE_HOST)
                            .addHeader("Accept-Encoding", "gzip, deflate")
                            .addHeader("Connection", "keep-alive")
                            .addHeader("cache-control", "no-cache")
                            .build();
                    Call call = client.newCall(request);
                    call.enqueue(new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            System.out.println(e.getStackTrace().toString());
                            Log.i("Failed : ", e.getStackTrace().toString());
                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                            System.out.println("Success : " + response.body().toString());
                            if (!response.isSuccessful()) {
                                // You can also throw your own custom exception
                                throw new IOException("Unexpected code " + response);
                            } else {
                                String resp = response.body().string();
                                try {
                                    JSONArray result = new JSONArray(resp);
                                    for (int i = 0; i < result.length(); i++) {
                                        final JSONObject obj = new JSONObject(result.get(i).toString());
                                        Handler mainHandler;
                                        try {
                                            mainHandler = new Handler(mContext.getMainLooper());
                                            mainHandler.post(new Runnable() {
                                                @Override
                                                public void run() {
                                                    filteredList.add(obj);
                                                }
                                            });
                                        }catch (NullPointerException e){Log.i("Null exception",e.getStackTrace().toString());}
                                        Log.i("Response ",response.toString());
                                    }
                                    response.body().close();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    Crashlytics.logException(e);
                                }
                                FilterResults results = new FilterResults();
                                results.values = filteredList;
                                mData.clear();
                                mData.addAll((List)results.values);
                                Handler mainHandler;
                                mainHandler = new Handler(mContext.getMainLooper());
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        notifyDataSetChanged();
                                    }
                                });
                            }
                        }
                    });
                }catch (Exception e){Log.i("Error ",e.getStackTrace().toString());
                    Crashlytics.logException(e);
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            //mData.clear();
            //mData.addAll((List)results.values);
            //notifyDataSetChanged();
        }
    };


    public addquessearchlistAdapter(Context mContext, List<JSONObject> mData) {
        this.mContext = mContext;
        this.mData = mData;
        mDataFull = new ArrayList<>(mData);
        //mData.clear();
    }

    @NonNull
    @Override
    public addquessearchlistAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View vw = inflater.inflate(R.layout.ask_question_item, parent, false);
        return new addquessearchlistAdapter.MyViewHolder(vw);
    }

    @Override
    public void onBindViewHolder(@NonNull final addquessearchlistAdapter.MyViewHolder holder, final int position) {
        if (mData != null) {

            holder.question.setText(mData.get(position).optString("title"));
            holder.noansw.setText(String.format("%d Answers", mData.get(position).optJSONArray("answered").length()));
            holder.question.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //((searchView) mContext).queClk(mData.get(position).quesno);
                    ////////////////////////sqno = mData.get(position).quesno;
                    FullscreenActivity.qaup = false;
                    FullscreenActivity.qaquestion = mData.get(position).optString("title");
                    ((FullscreenActivity) mContext).qandats();
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    private void removeItem(int position) {
        mData.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mData.size());
    }

    @Override
    public Filter getFilter() {
        return myFilter;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView user, question, answer;
        TextView noansw;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            question = itemView.findViewById(R.id.searchques);
            noansw = itemView.findViewById(R.id.noansw);

        }
    }
}
