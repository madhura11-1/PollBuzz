
package co.revidly.android;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FollowerViewHolder extends RecyclerView.ViewHolder {
    ImageView follower_img;
    TextView follower_name;
    Button unfollow;
    LinearLayout ll;
    public FollowerViewHolder(@NonNull View itemView) {
        super(itemView);
        follower_img = itemView.findViewById(R.id.follower_img);
        follower_name = itemView.findViewById(R.id.follower_name);
        unfollow = itemView.findViewById(R.id.unfollow);
        ll = itemView.findViewById(R.id.lLayout);
    }
}
