package co.revidly.android.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import co.revidly.android.FullscreenActivity;
import co.revidly.android.HomeFeed;

public class Utils {

    private static String authTokenPrefs = "authTokenSharedPreferences";

    public static void setLoginAuthToken(Context context, String authToken){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(authTokenPrefs, authToken);
        editor.apply();
    }

    public static String getAuthToken(Context context){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getString(authTokenPrefs, null);
    }


    public static void removeLoginAuthToken(Context context)
    {
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(context);
        settings.edit().clear().commit();
    }
/*
    public static  boolean isOnline(Context context) {
        ConnectivityManager conMgr = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conMgr.getActiveNetworkInfo();

        if(netInfo == null || !netInfo.isConnected() || !netInfo.isAvailable()){
            Toast.makeText(context, "No Internet connection!", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
*/
    public static void moveToFullscreenActivity(Context context, String share) {
        Intent intent = new Intent(context, FullscreenActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        if (share != null) {
            intent.putExtra(FullscreenActivity.PARAM_TOKEN, share);
        }
        context.startActivity(intent);
    }
    public static void moveToHomeFeed(Context context, String share) {
        Intent intent = new Intent(context, HomeFeed.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        Log.d("NewHomeFeed","Utils");
        if (share != null) {
            intent.putExtra(HomeFeed.PARAM_TOKEN, share);
        }
        context.startActivity(intent);
    }

}
