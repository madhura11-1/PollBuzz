package co.revidly.android;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.analytics.FirebaseAnalytics;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChoseTopic extends AppCompatActivity{

    RelativeLayout topic1, topic2, topic3, topic4, topic5, topic6;
    ImageView heart_white1,heart_red1, heart_white2,heart_red2, heart_white3,heart_red3,
            heart_white4,heart_red4, heart_white5,heart_red5, heart_white6,heart_red6;
    CircleImageView cirle1, cirle2, cirle3, cirle4, cirle5,cirle6;
    Boolean topic_1=false,topic_2=false,topic_3=false,topic_4=false,topic_5=false,topic_6=false;
    TextView topic_name1,topic_name2,topic_name3,topic_name4,topic_name5,topic_name6;
    Button submit;
    private FirebaseAnalytics mFirebaseAnalytics;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chose_topic);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        topic1 = findViewById(R.id.Topic1_Layout);
        heart_white1 = findViewById(R.id.heart_white1);
        heart_red1 = findViewById(R.id.heart_red1);
        cirle1 = findViewById(R.id.circleImageView1);
        topic_name1 = findViewById(R.id.topic_name1);

        topic2 = findViewById(R.id.Topic2_Layout);
        heart_white2 = findViewById(R.id.heart_white2);
        heart_red2 = findViewById(R.id.heart_red2);
        cirle2 = findViewById(R.id.circleImageView2);
        topic_name2 = findViewById(R.id.topic_name2);

        topic3 = findViewById(R.id.Topic3_Layout);
        heart_white3 = findViewById(R.id.heart_white3);
        heart_red3 = findViewById(R.id.heart_red3);
        cirle3 = findViewById(R.id.circleImageView3);
        topic_name3 = findViewById(R.id.topic_name3);
        heart_white3 = findViewById(R.id.heart_white3);
        heart_red3 = findViewById(R.id.heart_red3);
        cirle3 = findViewById(R.id.circleImageView3);
        topic_name3 = findViewById(R.id.topic_name3);

        topic4 = findViewById(R.id.Topic4_Layout);
        heart_white4 = findViewById(R.id.heart_white4);
        heart_red4 = findViewById(R.id.heart_red4);
        cirle4 = findViewById(R.id.circleImageView4);
        topic_name4 = findViewById(R.id.topic_name4);

        topic5 = findViewById(R.id.Topic5_Layout);
        heart_white5 = findViewById(R.id.heart_white5);
        heart_red5 = findViewById(R.id.heart_red5);
        cirle5 = findViewById(R.id.circleImageView5);
        topic_name5 = findViewById(R.id.topic_name5);

        topic6 = findViewById(R.id.Topic6_Layout);
        heart_white6 = findViewById(R.id.heart_white6);
        heart_red6 = findViewById(R.id.heart_red6);
        cirle6 = findViewById(R.id.circleImageView6);
        topic_name6 = findViewById(R.id.topic_name6);

        submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(topic_1 || topic_2 || topic_3 || topic_4 || topic_5 || topic_6){
                    startActivity(new Intent(getApplicationContext(), FullscreenActivity.class));
                    Bundle bundle = new Bundle();
                    bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"topicSelected");
                    mFirebaseAnalytics.logEvent("topicSelected",bundle);
                }
                else{
                    Toast.makeText(ChoseTopic.this, "Please Select at least one topic", Toast.LENGTH_SHORT).show();
                }
            }
        });

        topic1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(heart_red1.getVisibility() == View.VISIBLE){
                    deSelect(heart_red1,heart_white1,cirle1,topic_name1);
                    topic_1 = false;
                }
                else {
                    select(heart_red1,heart_white1,cirle1,topic_name1);
                    topic_1 = true;
                }
            }
        });

        topic2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if(heart_red2.getVisibility() == View.VISIBLE){
                    deSelect(heart_red2,heart_white2,cirle2,topic_name2);
                    topic_2 = false;
                }
                else {
                    select(heart_red2,heart_white2,cirle2,topic_name2);
                    topic_2 = true;
                }
            }
        });

        topic3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if(heart_red3.getVisibility() == View.VISIBLE){
                    deSelect(heart_red3,heart_white3,cirle3,topic_name3);
                    topic_3 = false;
                }
                else {
                    select(heart_red3,heart_white3,cirle3,topic_name3);
                    topic_3 = true;
                }
            }
        });

        topic4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if(heart_red4.getVisibility() == View.VISIBLE){
                    deSelect(heart_red4,heart_white4,cirle4,topic_name4);
                    topic_4 = false;
                }
                else {
                    select(heart_red4,heart_white4,cirle4,topic_name4);
                    topic_4 = true;
                }
            }
        });

        topic5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if(heart_red5.getVisibility() == View.VISIBLE){
                    deSelect(heart_red5,heart_white5,cirle5,topic_name5);
                    topic_5 = false;
                }
                else {
                    select(heart_red5,heart_white5,cirle5,topic_name5);
                    topic_5 = true;
                }
            }
        });

        topic6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if(heart_red6.getVisibility() == View.VISIBLE){
                    deSelect(heart_red6,heart_white6,cirle6,topic_name6);
                    topic_6 = false;
                }
                else {
                    select(heart_red6,heart_white6,cirle6,topic_name6);
                    topic_6 = true;
                }
            }
        });
    }

    private void select(ImageView vis, ImageView gon, CircleImageView cirImg, TextView txt) {
        gon.setVisibility(View.GONE);
        vis.setVisibility(View.VISIBLE);
        cirImg.requestLayout();
        cirImg.getLayoutParams().height = 290;
        cirImg.getLayoutParams().width = 290;
        txt.setTextColor(Color.parseColor("#FC0404"));
    }

    private void deSelect(ImageView gon, ImageView vis, CircleImageView cirImg, TextView txt) {
        gon.setVisibility(View.GONE);
        vis.setVisibility(View.VISIBLE);
        cirImg.requestLayout();
        cirImg.getLayoutParams().height = 310;
        cirImg.getLayoutParams().width = 310;
        txt.setTextColor(Color.parseColor("#000000"));
    }
}
