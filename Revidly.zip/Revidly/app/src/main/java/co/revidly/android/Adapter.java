package co.revidly.android;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.crashlytics.android.Crashlytics;
import com.google.firebase.analytics.FirebaseAnalytics;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.Utils;
import io.fabric.sdk.android.Fabric;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static android.view.View.GONE;
import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class Adapter extends RecyclerView.Adapter<Adapter.myViewHolder> {
    Context mContext;
    List<JSONObject> mData;
    List<JSONObject> mPostAction;
    public static int pos;
    static ExecutorService service;
    String auth_token_local;
    String video_kind;
    String videoPath;
    String ans_desc;
    myViewHolder holderTemp;
    Handler handler;
    JSONArray mediaArray;
    JSONArray topicsArray;
    String topics = "";
    String postUserId;
    private FirebaseAnalytics mFirebaseAnalytics;
    String postUserProfile;
    static int count = 0;
    String desc;


    public Adapter(Context mContext, List<JSONObject> mData, List<JSONObject> mPostAction) {
        this.mContext = mContext;
        this.mData = mData;
        this.mPostAction = mPostAction;
        auth_token_local = null;
        //if (mContext instanceof HomeFeed)
        auth_token_local = PostFeed.auth_token_local;
        //else
        //  auth_token_local = FullscreenActivity.auth_token;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(mContext);
    }

    @Override
    public void onViewRecycled(@NonNull myViewHolder holder) {
        if (mContext != null) {
            try {
                Glide.with(mContext).clear(holder.focus);
                Glide.with(mContext).clear(holder.previewImage);
                Glide.with(mContext).clear(holder.pro_pic);
                //Glide.with(mContext).clear(holder.focus);
            } catch (Exception e) {
                Crashlytics.log(e.toString());
            }
        }
        super.onViewRecycled(holder);
    }

    @NotNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Fabric.with(mContext, new Crashlytics());

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(mContext);
        View v = null;
        try {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            v = inflater.inflate(R.layout.card_item, parent, false);
            service = Executors.newFixedThreadPool(4);
            Log.d("Adapter->", "onCreateViewHolder called");
        } catch (Exception e) {
            e.printStackTrace();
            Crashlytics.log(e.getMessage());
        }
        return new myViewHolder(v);

    }

    String urL;

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull final myViewHolder holder, final int position) {

        try {

            topics = "";
            mediaArray = mData.get(position).optJSONArray("media");
            Log.d("jason_position:", mData.get(position).toString());
            count = 0;
            topicsArray = mData.get(position).optJSONArray("topics");
            postUserId = mData.get(position).optString("userId");

            if (mData.get(position).has("comments"))
                holder.comments = mData.get(position).optInt("comments");
            else
                holder.comments = 0;
            if (mData.get(position).has("views"))
                holder.views = mData.get(position).optInt("views");
            else
                holder.views = 0;
            postUserId = mData.get(position).optString("userId");
            desc=mData.get(position).optString("description");
            setProfilePic(holder, position);

            int mediaArrayLength = mediaArray.length();
            for (int i = 0; i <= topicsArray.length() - 1; i++) {
                JSONObject topicsItem = topicsArray.optJSONObject(i);
                Log.d("LOG_DATA", "TopicArray: " + topicsItem);
                if (topicsItem.getString("allowPosts").equalsIgnoreCase("0")) {
                    if (topics.isEmpty())
                        topics = topics + topicsItem.optString("name");
                    else
                        topics = topics + ", " + topicsItem.optString("name");
                }
            }
            if (LoggedInUser.userId.equals(postUserId)) {
                holder.xDelete.setVisibility(View.VISIBLE);
            } else {
                holder.xDelete.setVisibility(View.GONE);
            }

            if (mContext instanceof CommunityFeed) {
                if (CommunityFeed.isCurrentTopicAdmin) {
                    holder.xDelete.setVisibility(View.VISIBLE);
                }
//                else{
//                    holder.xDelete.setVisibility(View.GONE);
//                }
            }

            if (mediaArrayLength == 0) {
                holder.greyView.setVisibility(View.GONE);
                holder.focus.setVisibility(View.GONE);
                holder.vid.setVisibility(View.GONE);
                holder.play.setVisibility(View.GONE);
                holder.previewTitle.setVisibility(View.GONE);
                holder.previewDesc.setVisibility(View.GONE);
                holder.previewImage.setVisibility(View.GONE);
                holder.previewCL.setVisibility(View.GONE);
                holder.mediaRecyclerView.setVisibility(View.GONE);
//                holder.postDesc.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent i = new Intent(mContext, DescribedPostsActivity.class);
//                        i.putExtra("jason_pos", mData.get(position).toString());
//                        if (position < mPostAction.size())
//                            i.putExtra("post_action", mPostAction.get(position).toString());
//                        // i.putExtra("length","0");
//                        //i.putExtra("post",);
//                        mContext.startActivity(i);
//                    }
//                });
            } else if (mediaArrayLength == 1) {
                ///////////////////////Entire Old Code//////////////////
                String VIDEO_KIND_SELF = "self_video";
                String VIDEO_KIND_YOUTUBE = "youtube";
                String Image_Kind = "image";
                String PREVIEW = "preview";

                JSONObject media_object = mediaArray.getJSONObject(0);
                String mediaUrl = media_object.optString("loc");
                String kind = media_object.optString("kind");

                holder.mediaRecyclerView.setVisibility(View.GONE);

                ////Glide.with(mContext).load(R.raw.loader).into(holder.spinner);
                //holder.spinner.setVisibility(View.VISIBLE);

                //if(holder.vid.hasFocus())
                {
                    if (kind.equals(Image_Kind)) {
                        holder.greyView.setVisibility(View.VISIBLE);
                        holder.vid.setVisibility(View.GONE);
                        holder.play.setVisibility(View.GONE);
                        holder.focus.setVisibility(View.VISIBLE);
                        holder.duration.setVisibility(View.GONE);
                        holder.previewTitle.setVisibility(View.GONE);
                        holder.previewDesc.setVisibility(View.GONE);
                        holder.previewImage.setVisibility(View.GONE);
                        holder.previewCL.setVisibility(View.GONE);
                        //Picasso.get().load(mediaUrl).into(holder.focus);
                        RequestOptions requestOptions = new RequestOptions()
//                                .centerInside()
                                .centerCrop()
                                .fitCenter()
                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                .format(DecodeFormat.PREFER_RGB_565)
                                .dontAnimate()
                                .dontTransform()
                                .skipMemoryCache(true);
                        Glide.with(mContext)
                                .asBitmap()
                                .load(mediaUrl)
                                .apply(requestOptions)
                                .into(new CustomTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                        holder.greyView.setVisibility(View.GONE);
                                        holder.focus.setImageBitmap(resource);
                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {

                                    }
                                });
                        holder.focus.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent i = new Intent(mContext, DescribedPostsActivity.class);
                                i.putExtra("jason_pos", mData.get(position).toString());
                                if (position < mPostAction.size())
                                    i.putExtra("post_action", mPostAction.get(position).toString());
//                                i.putExtra("length","1");
//                                i.putExtra("media_url",mediaUrl);
//                                i.putExtra("image_kind",Image_Kind);
//                                i.putExtra("comm_name",topics);
                                mContext.startActivity(i);
                            }
                        });
//                        holder.greyView.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View view) {
//                                Intent i=new Intent(mContext,DescribedPostsActivity.class);
//                                i.putExtra("post_action",mPostAction.get(position).toString());
//                                i.putExtra("jason_pos",mData.get(position).toString());
////                                i.putExtra("length","1");
////                                i.putExtra("media_url",mediaUrl);
////                                i.putExtra("image_kind",Image_Kind);
////                                i.putExtra("comm_name",topics);
//                                mContext.startActivity(i);
//                            }
//                        });
//                        holder.postDesc.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View view) {
//                                Intent i = new Intent(mContext, DescribedPostsActivity.class);
//                                i.putExtra("jason_pos", mData.get(position).toString());
//                                if (position < mPostAction.size())
//                                    i.putExtra("post_action", mPostAction.get(position).toString());
////                                i.putExtra("length","1");
////                                i.putExtra("comm_name",topics);
////                                i.putExtra("media_url",mediaUrl);
////                                i.putExtra("image_kind",Image_Kind);
//                                mContext.startActivity(i);
//                            }
//                        });

                    }
                    if (kind.equals(PREVIEW)) {
                        holder.greyView.setVisibility(View.VISIBLE);
                        holder.vid.setVisibility(View.GONE);
                        holder.play.setVisibility(View.GONE);
                        holder.focus.setVisibility(View.GONE);
                        holder.duration.setVisibility(View.GONE);
                        holder.previewTitle.setVisibility(View.VISIBLE);
                        holder.previewDesc.setVisibility(View.VISIBLE);
                        holder.previewImage.setVisibility(View.VISIBLE);
                        holder.previewCL.setVisibility(View.VISIBLE);

                        holder.previewTitle.setText(media_object.optString("previewTitle"));
                        holder.previewDesc.setText(media_object.optString("previewDesc"));
                        holder.previewUrl = media_object.optString("previewUrl");

                        holder.previewCL.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                //Comment out these lines..This is for testing previewlinks
                                /*
                                Intent i=new Intent(mContext,DescribedPostsActivity.class);
                                i.putExtra("jason_pos",mData.get(position).toString());
                                i.putExtra("post_action",mPostAction.get(position).toString());
//                                i.putExtra("length","1");
//                                i.putExtra("comm_name",topics);
//                                i.putExtra("media_url",mediaUrl);
//                                i.putExtra("image_kind",Image_Kind);
                                mContext.startActivity(i);
                                */
                                ///Comment out above lines

                                //Remove comment from below lines

                                Log.d("Inside adapter : ", "I am called inside focus");
                                {
                                    String link;
                                    if (holder.previewUrl.startsWith("https") || holder.previewUrl.startsWith("http"))
                                        link = holder.previewUrl;
                                    else
                                        link = "https://" + holder.previewUrl;
                                    //String link = url;
//                                    Uri webpage = Uri.parse(link);
//                                    Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
//                                    mContext.startActivity(intent);
                                    InAppBrowser inAppBrowser = InAppBrowser.newInstance(link);
                                    Log.d("URLLink", link);
//                                    inAppBrowser.setCancelable(false);
                                    inAppBrowser.show(((FragmentActivity) mContext).getSupportFragmentManager(), inAppBrowser.getTag());
                                }
                                //if ( mContext instanceof HomeFeed)
                                //((HomeFeed) mContext).call(position);
                                //  ((HomeFeed) mContext).call(mData.get(position).optString("ans_id"));
                                //else
                                //  ((QuesAndAns) mContext).call(position);
                                Log.d("Inside adapter : ", "I am called inside focus");

                                //Remove comments from above lines
                            }
                        });
//                        holder.greyView.setOnClickListener(new View.OnClickListener() {
//                            @Override
//                            public void onClick(View v) {
//
//                                //Comment out these lines..This is for testing previewlinks
//                                /*
//                                Intent i=new Intent(mContext,DescribedPostsActivity.class);
//                                i.putExtra("jason_pos",mData.get(position).toString());
//                                i.putExtra("post_action",mPostAction.get(position).toString());
////                                i.putExtra("length","1");
////                                i.putExtra("comm_name",topics);
////                                i.putExtra("media_url",mediaUrl);
////                                i.putExtra("image_kind",Image_Kind);
//                                mContext.startActivity(i);
//                                */
//                                ///Comment out above lines
//
//                                //Remove comment from below lines
//
//                                Log.d("Inside adapter : ", "I am called inside focus");
//                                {
//                                    String link;
//                                    if(holder.previewUrl.startsWith("https") || holder.previewUrl.startsWith("http") )
//                                        link = holder.previewUrl;
//                                    else
//                                        link = "https://" + holder.previewUrl;
//                                    //String link = url;
//                                    Uri webpage = Uri.parse(link);
//                                    Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
//                                    mContext.startActivity(intent);
//                                }
//                                //if ( mContext instanceof HomeFeed)
//                                //((HomeFeed) mContext).call(position);
//                                //  ((HomeFeed) mContext).call(mData.get(position).optString("ans_id"));
//                                //else
//                                //  ((QuesAndAns) mContext).call(position);
//                                Log.d("Inside adapter : ", "I am called inside focus");
//
//                                //Remove comments from above lines
//                            }
//                        });

                        //Picasso.get()
                        //      .load(mediaUrl)
                        //    .into(holder.previewImage);
                        RequestOptions requestOptions = new RequestOptions()
//                                .centerInside()
                                .centerCrop()
                                .fitCenter()
                                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                                .format(DecodeFormat.PREFER_RGB_565)
                                .dontAnimate()
                                .dontTransform()
                                .skipMemoryCache(true);
                        Glide.with(mContext)
                                .asBitmap()
                                .load(mediaUrl)
                                .apply(requestOptions)
                                .into(new CustomTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                        holder.greyView.setVisibility(View.GONE);
                                        holder.previewImage.setImageBitmap(resource);
                                    }

                                    @Override
                                    public void onLoadCleared(@Nullable Drawable placeholder) {

                                    }
                                });
                    }

                    if (kind.equals(VIDEO_KIND_SELF)) {
                        holder.greyView.setVisibility(GONE);
                        Handler handler = new Handler();

                        String url = BASE_URL + "/media/";
                        //if (mData.get(position).optString("ans_url").contains(url)) {
                        //holder.vid.setVideoPath(mData.get(position).optString("ans_url"));
                        Log.d("Adapter-->", "videoURL -->" + url + mediaUrl);
                        //}
                        //else {
                        //  holder.vid.setVideoPath(url + mData.get(position).optString("ans_url"));
                        //}
                        //holder.vid.setVideoPath(url + mediaUrl);
                        //holder.vid.start();
                        holder.vid.setVideoPath(mediaUrl);
                        holder.vid.seekTo(2000);
                        holder.vid.pause();
                        holder.vid.setVisibility(View.VISIBLE);

                        holder.play.setVisibility(View.VISIBLE);
                        holder.focus.setVisibility(View.GONE);
                        holder.duration.setVisibility(View.VISIBLE);
                        holder.previewTitle.setVisibility(View.GONE);
                        holder.previewDesc.setVisibility(View.GONE);
                        holder.previewImage.setVisibility(View.GONE);
                        holder.previewCL.setVisibility(View.GONE);

                        Log.d("Adapter-->", "videoURL -->" + mediaUrl);



                        /*
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                holder.play.setVisibility(View.GONE);
                                holder.spinner.setVisibility(View.GONE);
                                holder.vid.start();
                            }
                        }, 5000);

                         */

                        pos = position;
                        //holder.vid.setVideoPath(mData.get(position).geturl());
                        //holder.setIsRecyclable(false);
                        holder.vid.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                            @Override
                            public void onPrepared(MediaPlayer mp) {
                                mp.setVolume(0f, 0f);
                                mp.setLooping(true);
                                int dur = holder.vid.getDuration() / 1000;
                                //String durn=String.format("Duration : %d:%02d mins",dur/60,dur%60);
                                String durn = String.format(" %d:%02d mins", dur / 60, dur % 60);
                                holder.duration.setText(durn);
                        /*
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            public void run() {
                                holder.vid.pause();
                                holder.play.setVisibility(View.VISIBLE);
                                holder.spinner.setVisibility(View.GONE);
                                holder.vid.requestFocus();
                            }
                        }, 10000);

                         */
                            }
                        });

                        holder.lang.setVisibility(View.INVISIBLE);

                        holder.vid.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Log.d("Adapter.java", "vid is clicked");
                                Intent i = new Intent(mContext, DescribedPostsActivity.class);
                                i.putExtra("jason_pos", mData.get(position).toString());
                                if (position < mPostAction.size())
                                    i.putExtra("post_action", mPostAction.get(position).toString());
//                        i.putExtra("length","1");
//                        i.putExtra("media_url",mediaUrl);
//                        i.putExtra("image_kind",VIDEO_KIND_SELF);
//                        i.putExtra("comm_name",topics);
                                mContext.startActivity(i);
                                Log.d("Adapter.java", "vid is clicked -> after intent is sent to DescribedPostActivity");
                            }
                        });
                    }

                    /* Uncomment this code to use youtube player
                    ********************************************

                    else if (kind.equals(VIDEO_KIND_YOUTUBE)) {
                        holder.spinner.setVisibility(View.GONE);
                        holder.youTubePlayerView.getYouTubePlayerWhenReady(new YouTubePlayerCallback() {
                            @Override
                            public void onYouTubePlayer(@NotNull YouTubePlayer youTubePlayer) {
                                Handler handler = new Handler();
                                holder.youTubePlayer=youTubePlayer;
                                holder.play.setVisibility(View.GONE);
                                holder.youTubePlayer.loadVideo(mData.get(position).optString("ans_url"), 0);
                                holder.youTubePlayer.mute();
                                holder.youTubePlayerView.setVisibility(View.VISIBLE);
//                        holder.youTubePlayerView.getPlayerUiController().showUi(false);
                                holder.youTubePlayerView.getPlayerUiController().showYouTubeButton(false);
                                holder.youTubePlayerView.getPlayerUiController().showMenuButton(false);
                                holder.youTubePlayerView.getPlayerUiController().showVideoTitle(false);
                                holder.youTubePlayerView.getPlayerUiController().showDuration(false);
                                holder.youTubePlayerView.getPlayerUiController().showFullscreenButton(false);
                                holder.youTubePlayerView.getPlayerUiController().showCurrentTime(false);
                                holder.youTubePlayerView.getPlayerUiController().showPlayPauseButton(false);
                                holder.youTubePlayerView.getPlayerUiController().showSeekBar(false);
                                holder.youTubePlayer.mute();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        holder.play.setVisibility(View.VISIBLE);
                                        holder.youTubePlayer.mute();
                                        holder.youTubePlayer.pause();
                                        //holder.youTubePlayerView.release();
                                    }
                                },12000);
                            }
                        });

                        //youTubePlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.MINIMAL);

                    }

                     */
                    ///Code for Youtube Player Ends Here

                }

        /*if(holder.getAdapterPosition()==fvi){
            Handler handler = new Handler();
            holder.vid.setVideoPath(mData.get(position).geturl());
            handler.postDelayed(new Runnable() {
                public void run() {
                    holder.play.setVisibility(View.GONE);
                    holder.vid.start();
                }
            }, 5000);
        }*/


                /*
                JSONObject video = mData.get(position).getJSONObject("video");
                //JSONObject innerElemVideo = video.getJSONObject(0);
                String lang = video.getString("lang");

                JSONObject ans_user = mData.get(position).getJSONObject("ans_user");
                //JSONObject innerElemAnsUser = ans_user.getJSONObject(0);
                String name = ans_user.getString("name");

                //holder.username.setText(mData.get(position).optString("name"));
                holder.username.setText(name);
                Log.d("Inside adapter : ", "lang = " + lang);
                //holder.lang.setText(mData.get(position).optString("lang"));
                //if language is required to be set, uncomment the below line//
                //holder.lang.setText(lang);
                 */

//                holder.postDesc.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent i = new Intent(mContext, DescribedPostsActivity.class);
//                        i.putExtra("jason_pos", mData.get(position).toString());
//                        if (position < mPostAction.size())
//                            i.putExtra("post_action", mPostAction.get(position).toString());
////                        i.putExtra("length","1");
////                        i.putExtra("comm_name",topics);
////                        i.putExtra("media_url",mediaUrl);
////                        i.putExtra("image_kind",VIDEO_KIND_SELF);
//                        mContext.startActivity(i);
//                    }
//                });

            } else if (mediaArrayLength == 2) {
                holder.greyView.setVisibility(View.GONE);
                holder.focus.setVisibility(View.GONE);
                holder.vid.setVisibility(View.GONE);
                holder.duration.setVisibility(View.GONE);
                holder.previewTitle.setVisibility(View.GONE);
                holder.previewDesc.setVisibility(View.GONE);
                holder.previewCL.setVisibility(View.GONE);
                holder.mediaRecyclerView.setVisibility(View.VISIBLE);
                holder.mediaAdapter = new MediaAdapter(mContext, mediaArray);
                holder.mediaRecyclerView.setHasFixedSize(true);

                // if 1 element is present, don't call the recycler view, if 2 elements are present -> call (1, horizontal), if more than 2 elements are present -> call (2, Horizontal)
                holder.mediaRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.HORIZONTAL));
                holder.mediaRecyclerView.setAdapter(holder.mediaAdapter);

//                holder.postDesc.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent i = new Intent(mContext, DescribedPostsActivity.class);
//                        i.putExtra("jason_pos", mData.get(position).toString());
//                        if (position < mPostAction.size())
//                            i.putExtra("post_action", mPostAction.get(position).toString());
////                        i.putExtra("length","2");
////                        i.putExtra("comm_name",topics);
////                        i.putExtra("media_url",mediaArray.toString());
//                        mContext.startActivity(i);
//                    }
//                });

                holder.mediaRecyclerView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(mContext, DescribedPostsActivity.class);
                        i.putExtra("jason_pos", mData.get(position).toString());
                        if (position < mPostAction.size())
                            i.putExtra("post_action", mPostAction.get(position).toString());
//                        i.putExtra("length","2");
//                        i.putExtra("comm_name",topics);
//                        i.putExtra("media_url",mediaArray.toString());
                        mContext.startActivity(i);
                    }
                });

            } else if (mediaArrayLength > 2) {
                holder.greyView.setVisibility(View.GONE);
                holder.focus.setVisibility(View.GONE);
                holder.vid.setVisibility(View.GONE);
                holder.duration.setVisibility(View.GONE);
                holder.previewTitle.setVisibility(View.GONE);
                holder.previewDesc.setVisibility(View.GONE);
                holder.previewCL.setVisibility(View.GONE);
                holder.mediaRecyclerView.setVisibility(View.VISIBLE);
                holder.mediaAdapter = new MediaAdapter(mContext, mediaArray);
                holder.mediaRecyclerView.setHasFixedSize(true);

                // if 1 element is present, don't call the recycler view, if 2 elements are present -> call (1, horizontal), if more than 2 elements are present -> call (2, Horizontal)
                holder.mediaRecyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.HORIZONTAL));
                holder.mediaRecyclerView.setAdapter(holder.mediaAdapter);

//                holder.postDesc.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Intent i = new Intent(mContext, DescribedPostsActivity.class);
//                        i.putExtra("jason_pos", mData.get(position).toString());
//                        if (position < mPostAction.size())
//                            i.putExtra("post_action", mPostAction.get(position).toString());
////                        i.putExtra("length","2");
////                        i.putExtra("comm_name",topics);
////                        i.putExtra("media_url",mediaArray.toString());
//                        mContext.startActivity(i);
//                    }
//                });

                holder.mediaRecyclerView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent i = new Intent(mContext, DescribedPostsActivity.class);
                        i.putExtra("jason_pos", mData.get(position).toString());
                        if (position < mPostAction.size())
                            i.putExtra("post_action", mPostAction.get(position).toString());
//                        i.putExtra("length","2");
//                        i.putExtra("comm_name",topics);
//                        i.putExtra("media_url",mediaArray.toString());
                        mContext.startActivity(i);
                    }
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        ///////////Code to extract media array ends///////

        setComment(holder, position, mData.get(position).optJSONObject("comentData"));
        //sets post votes
        setVotes(holder, position);

        // Code for tag list

        // code ends

        if (mContext instanceof CommunityFeed) {
            if (CommunityFeed.pendingClicked) {
                holder.pendingStatus.setVisibility(View.VISIBLE);
            }

        }

        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((CommunityFeed) mContext).getPostFeedClass().acceptOnClick(mData.get(position).optString("_id"), position);
                mData.remove(position);
                mPostAction.remove(position);
            }
        });

        holder.decline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                declineOnClick(position);
//                ((CommunityFeed) mContext).getPostFeedClass().declineOnClick(mData.get(position).optString("_id"),position);
//                mData.remove(position);
//                mPostAction.remove(position);
            }
        });

        holder.upvtCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.upvtCL.setClickable(false);
                holder.dnvtCL.setClickable(false);
                if (holder.user_vote == 0) {
                    holder.user_vote = 1;
                    holder.upvotes += 1;
                } else if (holder.user_vote == 1) {
                    holder.user_vote = 0;
                    holder.upvotes -= 1;
                } else if (holder.user_vote == -1) {
                    holder.user_vote = 1;
                    holder.upvotes += 1;
                    holder.downvotes -= 1;
                    //downvote(holder,position);
                }
                holder.upv.setText(String.format("%d Upvotes", holder.upvotes));
                holder.dnv.setText(String.format("%d Downvotes", holder.downvotes));
                holder.cmnt.setText(String.format("%d", holder.comments));
                if (holder.views < 999)
                    holder.view.setText(String.format("%d", holder.views));
                else {
                    int rounded = ((holder.views + 99) / 100) * 100;
                    double roundedTo = rounded / 1000.0;
                    holder.view.setText(roundedTo + "k");
                }
                holder.shr.setText(String.format("%d Shares", holder.shares));

                holder.shr.setText(String.format("%d Shares", holder.shares));
                if (holder.user_vote == 1) {
                    holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                    holder.upvt.setBackgroundResource(R.drawable.votes_pressed);
                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                } else if (holder.user_vote == -1) {
                    holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                    holder.upvt.setImageResource(R.drawable.home_upvote);
                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    holder.dnvt.setBackgroundResource(R.drawable.votes_pressed);

                } else {
                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                    holder.upvt.setImageResource(R.drawable.home_upvote);
                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                }
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "upvote");
                mFirebaseAnalytics.logEvent("upvoteClicked", bundle);
                upvote(holder, position);
            }
        });
        holder.dnvtCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                holder.upvtCL.setClickable(false);
                holder.dnvtCL.setClickable(false);
                if (holder.user_vote == 0) {
                    holder.user_vote = -1;
                    holder.downvotes += 1;
                } else if (holder.user_vote == 1) {
                    holder.user_vote = -1;
                    holder.downvotes += 1;
                    holder.upvotes -= 1;
                    //upvote(holder,position);
                } else if (holder.user_vote == -1) {
                    holder.user_vote = 0;
                    holder.downvotes -= 1;
                }
                holder.upv.setText(String.format("%d Upvotes", holder.upvotes));
                holder.dnv.setText(String.format("%d Downvotes", holder.downvotes));
                holder.cmnt.setText(String.format("%d", holder.comments));
                if (holder.views < 999)
                    holder.view.setText(String.format("%d", holder.views));
                else {
                    int rounded = ((holder.views + 99) / 100) * 100;
                    double roundedTo = rounded / 1000.0;
                    holder.view.setText(roundedTo + "k");
                }
                holder.shr.setText(String.format("%d Shares", holder.shares));

                if (holder.user_vote == 1) {
                    holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                    holder.upvt.setBackgroundResource(R.drawable.votes_pressed);
                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                } else if (holder.user_vote == -1) {
                    holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                    holder.upvt.setImageResource(R.drawable.home_upvote);
                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    holder.dnvt.setBackgroundResource(R.drawable.votes_pressed);
                } else {
                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                    holder.upvt.setImageResource(R.drawable.home_upvote);
                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                }
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "downvote");
                mFirebaseAnalytics.logEvent("downvoteClicked", bundle);
                downvote(holder, position);
            }
        });
        holder.comm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("Inside Adapter --> ", "Comment postId " + mData.get(position).optString("_id"));
                if (mContext instanceof HomeFeed)
                    HomeFeed.getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                else if (mContext instanceof ProfilePage) {
                    UserProfilePosts fragment = (UserProfilePosts) ((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(0);
                    fragment.getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                } else if (mContext instanceof CommunityFeed)
                    ((CommunityFeed) mContext).getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "comm");
                mFirebaseAnalytics.logEvent("commClicked", bundle);

            }
        });
        holder.shrd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mContext instanceof HomeFeed) {
                    //Toast.makeText(mContext,"Hello Javatpoint",Toast.LENGTH_SHORT).show();
                    HomeFeed.getPostFeedClass().shareOnClick(mData.get(position).optString("_id"));

                } else if (mContext instanceof ProfilePage) {
                    //Toast.makeText(mContext,"Hello Javatpoint",Toast.LENGTH_SHORT).show();
                    UserProfilePosts fragment = (UserProfilePosts) ((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(0);
                    fragment.getPostFeedClass().shareOnClick(mData.get(position).optString("_id"));
                } else if (mContext instanceof CommunityFeed)
                    // Toast.makeText(mContext,"Shared",Toast.LENGTH_LONG).show();
                    ((CommunityFeed) mContext).getPostFeedClass().shareOnClick(mData.get(position).optString("_id"));
//
//                Bundle bundle = new Bundle();
//                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"share");
//                mFirebaseAnalytics.logEvent("shareClicked",bundle);
            }
        });

        holder.pro_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    if (mContext instanceof HomeFeed)
                        //((HomeFeed) mContext).propicClick(position);
                        HomeFeed.getPostFeedClass().propicOnClick(mData.get(position).optString("userId"));
                    else if (mContext instanceof CommunityFeed)
                        ((CommunityFeed) mContext).getPostFeedClass().propicOnClick(mData.get(position).optString("userId"));
                } catch (Exception e) {
                    Crashlytics.logException(e);
                    e.printStackTrace();

                }
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "propic");
                mFirebaseAnalytics.logEvent("propicClicked", bundle);
            }
        });
        holder.username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    if (mContext instanceof HomeFeed)
                        //((HomeFeed) mContext).propicClick(position);
                        HomeFeed.getPostFeedClass().propicOnClick(mData.get(position).optString("userId"));
                    else if (mContext instanceof CommunityFeed)
                        ((CommunityFeed) mContext).getPostFeedClass().propicOnClick(mData.get(position).optString("userId"));
                } catch (Exception e) {
                    Crashlytics.logException(e);
                    e.printStackTrace();
                }
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "propic");
                mFirebaseAnalytics.logEvent("propicClicked", bundle);
            }
        });
        holder.communityName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mContext instanceof HomeFeed) {
                    if (topicsArray.length() == 1) {
                        Intent intent = new Intent(mContext, CommunityFeed.class);
                        intent.putExtra("COMMUNITY_TOKEN", topicsArray.toString());
                        mContext.startActivity(intent);
                    }
                    Log.d("Inside Adapter --->", "Topics Array = " + mData.get(position).optJSONArray("topics"));
                    Log.d("Inside Adapter --->", "Topics String = " + topics);

                    HomeFeed.getPostFeedClass().communityOnClick(mData.get(position).optJSONArray("topics"));
                } else if (mContext instanceof ProfilePage) {
                    Log.d("Inside Adapter --->", "Topics Array = " + mData.get(position).optJSONArray("topics"));
                    Log.d("Inside Adapter --->", "Topics String = " + topics);
                    UserProfilePosts fragment = (UserProfilePosts) ((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(0);
                    fragment.getPostFeedClass().communityOnClick(mData.get(position).optJSONArray("topics"));
                } else if (mContext instanceof CommunityFeed) {
                    Log.d("Inside Adapter --->", "Topics Array = " + mData.get(position).optJSONArray("topics"));
                    Log.d("Inside Adapter --->", "Topics String = " + topics);
                    ((CommunityFeed) mContext).getPostFeedClass().communityOnClick(mData.get(position).optJSONArray("topics"));
                }
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "communityname");
                mFirebaseAnalytics.logEvent("communityNameClicked", bundle);
            }
        });

        holder.xDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Log.d("Delete pressed -->", "before HomeFeed Call postId =" + mData.get(position).optString("_id"));
                    if (mContext instanceof HomeFeed)
                        deletePost(position);
                    else if (mContext instanceof ProfilePage) {
//                        UserProfilePosts fragment = (UserProfilePosts)((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(0);
//                        fragment.getPostFeedClass().deletePost(mData.get(position).optString("_id"));
                        deletePost(position);
                    } else if (mContext instanceof CommunityFeed) {
                        Log.d("LOG_DATA", "isCURRENTADMIN: " + CommunityFeed.isCurrentTopicAdmin);
                        if (CommunityFeed.isCurrentTopicAdmin) {
                            if (LoggedInUser.userId.equalsIgnoreCase(mData.get(position).getString("userId"))) {
                                deletePost(position);
                            } else {
                                declineOnClick(position);
//                                ((CommunityFeed) mContext).getPostFeedClass().declineOnClick(mData.get(position).optString("_id"),position);
//                                mData.remove(position);
//                                mPostAction.remove(position);
                            }
                        } else {
                            deletePost(position);
                        }
                    }
                    Log.d("Delete pressed -->", "after HomeFeed Call postId =" + mData.get(position).optString("_id"));
                } catch (Exception e) {
                    Crashlytics.logException(e);
                    e.printStackTrace();
                }
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "delete");
                mFirebaseAnalytics.logEvent("deleteClicked", bundle);
            }
        });
        String createdAt = mData.get(position).optString("createdAt");
        String date = null, time = null;

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = new Date();
        String today = formatter.format(date1);
        createdAt = createdAt.substring(0, 23) + "+0000";
        DateFormat utcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        DateFormat indianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        indianFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String output = null;
        try {
            Date timestamp = null;
            timestamp = utcFormat.parse(createdAt);
            output = indianFormat.format(timestamp);
            createdAt = output;
            date = createdAt.substring(0, 10);
            time = createdAt.substring(11, 16);
        } catch (ParseException e) {
            Log.d("ParseError", String.valueOf(e));
        }

        int time1 = Integer.parseInt(time.substring(0, 2));
        if (time1 >= 12) {
            time1 = time1 - 12;
            String time2 = time.substring(3, 5);
            if (time1 == 0) {
                time = "12:" + time2 + " PM";
            } else {
                time = time1 + ":" + time2 + " PM";
            }
        } else {
            if (Integer.parseInt(time.substring(0, 2)) == 0) {
                String time2 = time.substring(3, 5);
                time = "12:" + time2 + " AM";
            } else if (Integer.parseInt(time.substring(0, 2)) < 10) {
                time = time.substring(1, 2) + " AM";
            } else
                time = time + " AM";
        }
        long MILLIS_IN_DAY = 1000 * 60 * 60 * 24;
        String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat dateFormat1 = new SimpleDateFormat("d-MMM-yyyy");
        Date mDate = null;
        String day;
        boolean changeHolder = false;
        try {
            mDate = dateFormat.parse(date);
        } catch (ParseException e) {
            Log.d("ParseError", String.valueOf(e));
        }
        String fDate = dateFormat1.format(mDate);
        Calendar cal = Calendar.getInstance();
        cal.setTime(mDate);
        if (date.substring(0, 4).equals(today.substring(0, 4)) && date.substring(5, 7).equals(today.substring(5, 7))) {
            if (date.substring(8, 10).equals(today.substring(8, 10))) {
                holder.createdAt.setText("Today at " + time);
                changeHolder = false;
            } else if (Integer.parseInt(date.substring(8, 10)) == Integer.parseInt(today.substring(8, 10)) - 1) {
                holder.createdAt.setText("Yesterday at " + time);
                changeHolder = false;
            } else {
                holder.createdAt.setText(fDate);
                changeHolder = true;
            }
        } else {
            holder.createdAt.setText(fDate);
            changeHolder = true;
        }
        if (mDate.getTime() >= date1.getTime() - (7 * MILLIS_IN_DAY)) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(mDate);
            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
            day = days[dayOfWeek - 1];
            if (changeHolder) {
                holder.createdAt.setText(day + " at " + time);
            }
        }

        /* Code for adding bookmarks */
        /*
        if (FullscreenActivity.ansbookmarks.contains(mData.get(position).optString("_id")))
            holder.follow.setImageResource(R.drawable.bookmarked);
        else holder.follow.setImageResource(R.drawable.all_ans_bookmark_ribbon);
        holder.follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.bookmarked==0) {addbookmark(holder,position); holder.follow.setImageResource(R.drawable.bookmarked);}
                else if(holder.bookmarked==1) {addbookmark(holder, position); holder.follow.setImageResource(R.drawable.all_ans_bookmark_ribbon);}
            }
        });

         */
        //holder.duration.setText(mData.get(position).getDuration());

        //holder.vid.requestFocus();
        /*holder.vid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //((QuesAndAns) mContext).call(mData.get(position).geturl());
                ((QuesAndAns) mContext).call(mData.get(position).getAns_no());
            }
        });
        holder.vid.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus)
                    ((QuesAndAns) mContext).call(mData.get(position).getAns_no());
            }
        });

        */

        //setdata(holder,position);
        //if((new LinearLayoutManager((QuesAndAns) mContext,LinearLayoutManager.VERTICAL,false)).findLastVisibleItemPosition()+1==position)holder.vid.start();
        //if((new LinearLayoutManager((QuesAndAns) mContext,LinearLayoutManager.VERTICAL,false)).findLastVisibleItemPosition()!=position)holder.vid.stopPlayback();

        holder.three_dots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                holder.desc.setVisibility(View.VISIBLE);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        holder.desc.setVisibility(View.GONE);
                    }
                }, 5000);
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "three_dots");
                mFirebaseAnalytics.logEvent("three_dotsClicked", bundle);

            }
        });
    }

    private void setComment(myViewHolder holder, final int position, final JSONObject commentObj) {
        Log.d("CommentViewTesting", "Hi123Com");
        holder.totalcomm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mContext instanceof HomeFeed)
                    HomeFeed.getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                else if (mContext instanceof ProfilePage) {
                    UserProfilePosts fragment = (UserProfilePosts) ((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(0);
                    fragment.getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                } else if (mContext instanceof CommunityFeed)
                    ((CommunityFeed) mContext).getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "comm");
                mFirebaseAnalytics.logEvent("commClicked", bundle);
            }
        });
        holder.firstcomm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mContext instanceof HomeFeed)
                    HomeFeed.getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                else if (mContext instanceof ProfilePage) {
                    UserProfilePosts fragment = (UserProfilePosts) ((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(0);
                    fragment.getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                } else if (mContext instanceof CommunityFeed)
                    ((CommunityFeed) mContext).getPostFeedClass().commentOnClick(mData.get(position).optString("_id"));
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "comm");
                mFirebaseAnalytics.logEvent("commClicked", bundle);
            }
        });
        holder.firstcommUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String UID = commentObj.optString("userId");
                    goToProfile(UID);
                } catch (Exception e) {
                    Crashlytics.logException(e);
                    e.printStackTrace();
                }
            }
        });
        if (commentObj != null) {
            Log.d("CommentViewTesting", "Hi123");
            if (holder.comments == 0) {
                holder.commentLayout.setVisibility(GONE);
            } else {
                holder.totalcomm.setText(String.format("View all %d comments", holder.comments));
                String name = commentObj.optString("userName");
                holder.firstcommUser.setText(name);
                String comment = commentObj.optString("content");
                holder.firstcomm.setText(comment);
            }
        } else {
            holder.commentLayout.setVisibility(GONE);
        }
    }

    public void setVotes(final myViewHolder holder, final int position) {
        try {

            if (mData.get(position).optString("description") == "" || mData.get(position).optString("description") == "null") {
                holder.postDesc.setText("");
                holder.postDesc.setVisibility(View.GONE);
            } else {
                String postText = "" + mData.get(position).optString("description");
                postText=postText.replace("\n","\n ");
                int pos = 0, posEnd = 0;
                List<Integer> start = new ArrayList<>();
                List<Integer> end = new ArrayList<>();
                List<String> links = new ArrayList<>();
                while (postText.substring(posEnd).contains("http")) {
                    pos = postText.indexOf("http", posEnd);
                    start.add(pos);
                    if (postText.indexOf(' ', pos) == -1 && postText.indexOf('\n', pos) == -1)
                        posEnd = -1;
                    else if (postText.indexOf(' ', pos) == -1 && postText.indexOf('\n', pos) != -1)
                        posEnd = postText.indexOf('\n', pos);
                    else if (postText.indexOf(' ', pos) != -1 && postText.indexOf('\n', pos) == -1)
                        posEnd = postText.indexOf(' ', pos);
                    else
                        posEnd = Math.min(postText.indexOf('\n', pos), postText.indexOf(' ', pos));
                    if (posEnd != -1) {
                        String link = postText.substring(pos, posEnd);
                        int linkLength = link.length();
                        if (linkLength > 20) {
                            postText = postText.substring(0, pos) + postText.substring(pos, pos + 20) + "...(link)" + postText.substring(posEnd);
                            end.add(pos + 29);
                            posEnd = pos + 29;
                        } else if (linkLength > 10) {
                            postText = postText.substring(0, pos) + postText.substring(pos, pos + 10) + "...(link)" + postText.substring(posEnd);
                            end.add(pos + 19);
                            posEnd = pos + 19;
                        } else {
                            postText = postText.substring(0, pos) + postText.substring(pos, pos + 5) + "...(link)" + postText.substring(posEnd);
                            end.add(pos + 14);
                            posEnd = pos + 14;
                        }
                        links.add(link);
                    } else {
                        //postText = postText.substring(0, pos + 20) + "...(link)";
                        String link = postText.substring(pos);
                        int linkLength = link.length();
                        if (linkLength > 20) {
                            postText = postText.substring(0, pos) + postText.substring(pos, pos + 20) + "...(link)";
                            end.add(pos + 29);
                        } else if (linkLength > 10) {
                            postText = postText.substring(0, pos) + postText.substring(pos, pos + 10) + "...(link)";
                            end.add(pos + 19);
                        } else {
                            postText = postText.substring(0, pos) + postText.substring(pos, pos + 5) + "...(link)";
                            end.add(pos + 14);
                        }
                        links.add(link);
                        break;
                    }
                }
                SpannableString postDesc = new SpannableString(postText);
                for (int i = 0; i < start.size(); i++) {
                    postDesc.setSpan(new CustomStyleSpan(links.get(i)), start.get(i), end.get(i), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
                try {
                    JSONArray taggedInfo = mData.get(position).optJSONArray("taggedUsers");
                    List<String> names = new ArrayList<>(), UIDs = new ArrayList<>();
                    for (int i = 0; i < taggedInfo.length(); i++) {
                        JSONObject obj = taggedInfo.optJSONObject(i);
                        names.add(obj.optString("name"));
                        UIDs.add(obj.optString("userId"));
                    }
//                    String text1 = mData.get(position).optString("content");
//                    text1 = text1.replace("\n", "\n ");
//                    SpannableString text = new SpannableString(text1);
                    String[] arr = postText.split(" ");
                    for (int i = 0; i < arr.length - 1; i++) {
                        if (arr[i].trim().startsWith("@")) {
                            String tag_name = arr[i] + " " + arr[i + 1].trim();
                            tag_name = tag_name.substring(1);
                            Log.d("CommentAdapter123", tag_name);
                            if (names.contains(tag_name)) {
                                Log.d("Countung", "Hi");
                                postDesc.setSpan(new CustomTagStyleSpan(UIDs.get(names.indexOf(tag_name))),
                                        postText.indexOf(tag_name) - 1,
                                        postText.indexOf(tag_name) + tag_name.length(),
                                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                            }
                        }
                    }
                    for (int i = 0; i < start.size(); i++) {
                        postDesc.setSpan(new CustomStyleSpan(links.get(i)), start.get(i), end.get(i), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    holder.postDesc.setText(postDesc);
                    holder.postDesc.setVisibility(View.VISIBLE);
                    holder.postDesc.setMovementMethod(LinkMovementMethod.getInstance());
                }catch (Exception e){
                    Crashlytics.log(e.getMessage());
                }
//                holder.postDesc.setText(postDesc);
//                holder.postDesc.setMovementMethod(LinkMovementMethod.getInstance());
            }

            //holder.postDesc.setText("" + mData.get(position).optString("description"));

            if (mData.get(position).optString("userName") == "" || mData.get(position).optString("userName") == "null") {
                holder.username.setText("" + "Anonymous");
            } else {
                holder.username.setText("" + mData.get(position).optString("userName"));
            }
            SpannableString underlineTopics = new SpannableString("" + topics);
            //To make community Name underlines, uncomment this line
            //underlineTopics.setSpan(new UnderlineSpan(), 2, underlineTopics.length(), 0);
            holder.communityName.setText(underlineTopics);
            //holder.communityName.setText("@ " + topics);
            if (mData.get(position).has("upvotes"))
                holder.upvotes = mData.get(position).getInt("upvotes");
            else
                holder.upvotes = 0;

            if (mData.get(position).has("downvotes"))
                holder.downvotes = mData.get(position).getInt("downvotes");
            else
                holder.downvotes = 0;
            //if(mContext instanceof HomeFeed)
            {
                if (!(mPostAction.isEmpty())) {
                    try {
                        if (mPostAction.get(position).optBoolean("upvote"))
                            holder.user_vote = 1;
                        else if (mPostAction.get(position).optBoolean("downvote"))
                            holder.user_vote = -1;
                        else
                            holder.user_vote = 0;
                    } catch (Exception e) {
                        Log.d("Adapter_except", e.getMessage());
                    }
                }
            }
            //else
            //  holder.user_vote = 0;

            Handler mainHandler = new Handler(mContext.getMainLooper());
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    holder.upv.setText(String.format("%d Upvotes", holder.upvotes));
                    Log.d("Votes: ", holder.postDesc.getText() + "\n" + mData.get(position).toString() + holder.upvotes);
                    holder.dnv.setText(String.format("%d Downvotes", holder.downvotes));
                    holder.cmnt.setText(String.format("%d", holder.comments));
                    if (holder.views < 999)
                        holder.view.setText(String.format("%d", holder.views));
                    else {
                        int rounded = ((holder.views + 99) / 100) * 100;
                        double roundedTo = rounded / 1000.0;
                        holder.view.setText(roundedTo + "k");
                    }
                    holder.shr.setText(String.format("%d Shares", holder.shares));
                    holder.shr.setText(String.format("%d Shares", holder.shares));
                    if (holder.user_vote == 1) {
                        //holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                        holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                        holder.dnvt.setImageResource(R.drawable.home_downvote);
                        holder.upvt.setBackgroundResource(R.drawable.votes_pressed);
                        holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                    } else if (holder.user_vote == -1) {
                        //holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                        holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                        holder.upvt.setImageResource(R.drawable.home_upvote);
                        holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                        holder.dnvt.setBackgroundResource(R.drawable.votes_pressed);

                    } else {
                        holder.dnvt.setImageResource(R.drawable.home_downvote);
                        holder.upvt.setImageResource(R.drawable.home_upvote);
                        holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                        holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                    }
                }
            });

        } catch (Exception e) {
            Crashlytics.logException(e);
            e.printStackTrace();
        }
    }

    private void setProfilePic(final myViewHolder holder, final int position)
    {
                postUserProfile = BASE_URL + "/app/profilePic/" + postUserId + ".jpg";
//                Picasso.get().load(postUserProfile).into(holder.pro_pic);
                RequestOptions requestOptions = new RequestOptions()
//                        .centerInside()
//                        .centerCrop()
                        .circleCrop()
                        .fitCenter()
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .format(DecodeFormat.PREFER_RGB_565)
                        .dontAnimate()
                        .dontTransform()
                        .skipMemoryCache(true);
                Glide.with(mContext)
                        .asBitmap()
                        .load(postUserProfile)
                        .apply(requestOptions)
                        .thumbnail(0.1f)
                        .placeholder(R.drawable.propic1)
                        .into(holder.pro_pic);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    private class CustomStyleSpan extends ClickableSpan {
        String url;

        public CustomStyleSpan(String url) {
            this.url = url;
        }

        @Override
        public void onClick(@NonNull View view) {
            InAppBrowser inAppBrowser = InAppBrowser.newInstance(url);
            inAppBrowser.show(((FragmentActivity) mContext).getSupportFragmentManager(), inAppBrowser.getTag());
        }
    }

    void upvote(final myViewHolder holder, final int position) {
        OkHttpClient client = new OkHttpClient();

        String url = BASE_URL + "/api/post/upvote";
        MediaType mediaType = MediaType.parse("application/json");
        JSONObject postBody = new JSONObject();
        try {
            postBody.put("postId", mData.get(position).optString("_id"));
        } catch (Exception e) {
            Crashlytics.logException(e);
            e.printStackTrace();
        }
        Log.d("Adapter Upvote -->", "postBody = " + postBody.toString());
        RequestBody body = RequestBody.create(mediaType, postBody.toString());
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", auth_token_local)
                .addHeader("cache-control", "no-cache")
                .addHeader("Postman-Token", "62f68963-bad1-4ed2-adf1-6d275e647694")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ", response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    //setdata(holder, position);
                    Handler mainHandler;
                    try {

                        JSONObject tempObj = new JSONObject(response.body().string());
                        JSONObject obj = tempObj.optJSONObject("action");
                        Log.d("upvote", "action = " + obj.toString());

                        //checking upvote value and updating data source
                        if (obj.getBoolean("upvote")) {
                            //holder.upvotes = holder.upvotes + 1;
                            holder.user_vote = 1;

                            //update adapter data source arrays
                            Log.d("upvote", "I am inside obj.getboolean()");
                            int upvotes = mData.get(position).getInt("upvotes");
                            Log.d("upvotes", "mData before upvotes removed = " + mData.get(position).toString());
                            mData.get(position).remove("upvotes");
                            Log.d("upvotes", "mData after upvotes removed = " + mData.get(position).toString());
                            mData.get(position).put("upvotes", upvotes + 1);
                            Log.d("upvotes", "mData after upvotes added again= " + mData.get(position).toString());
                            //boolean userVote= mPostAction.get(position).getBoolean("upvote");
                            Log.d("upvotes", "mPostAction before upvote removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).remove("upvote");
                            Log.d("upvotes", "mPostAction after upvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).put("upvote", true);
                            Log.d("upvotes", "mPostAction after upvotes added again= " + mPostAction.get(position).toString());
                        } else {
                            holder.user_vote = 0;

                            int upvotes = mData.get(position).getInt("upvotes");
                            Log.d("upvotes", "mData before upvotes removed = " + mData.get(position).toString());
                            mData.get(position).remove("upvotes");
                            Log.d("upvotes", "mData after upvotes removed = " + mData.get(position).toString());
                            mData.get(position).put("upvotes", upvotes - 1);
                            Log.d("upvotes", "mData after upvotes added again= " + mData.get(position).toString());
                            //boolean userVote= mPostAction.get(position).getBoolean("upvote");
                            Log.d("upvotes", "mPostAction before upvote removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).remove("upvote");
                            Log.d("upvotes", "mPostAction after upvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).put("upvote", false);
                            Log.d("upvotes", "mPostAction after upvotes added again= " + mPostAction.get(position).toString());


                        }

                        //checking downvote value and updating data source
                        if (mPostAction.get(position).optBoolean("downvote") && !obj.getBoolean("downvote")) {
                            //holder.upvotes = holder.upvotes + 1;
                            //holder.user_vote = -1;

                            //update adapter data source arrays
                            Log.d("downvotes", "I am inside obj.getboolean()");
                            int downvotes = mData.get(position).getInt("downvotes");
                            Log.d("downvotes", "mData before downvotes removed = " + mData.get(position).toString());
                            mData.get(position).remove("downvotes");
                            Log.d("downvotes", "mData after downvotes removed = " + mData.get(position).toString());
                            mData.get(position).put("downvotes", downvotes - 1);
                            Log.d("downvotes", "mData after downvotes added again= " + mData.get(position).toString());
                            //boolean userVote= mPostAction.get(position).getBoolean("upvote");
                            Log.d("downvotes", "mPostAction before downvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).remove("downvote");
                            Log.d("downvotes", "mPostAction after downvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).put("downvote", false);
                            Log.d("downvotes", "mPostAction after downvotes added again= " + mPostAction.get(position).toString());
                        }

                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                holder.upv.setText(String.format("%d Upvotes", holder.upvotes));
                                holder.dnv.setText(String.format("%d Downvotes", holder.downvotes));
                                Log.d("upvote number", "holder.upvotes = " + holder.upvotes);
                                if (holder.user_vote == 1) {
                                    //holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                                    holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                                    Log.d("upvote", "I am inside user_vote = 1 after upvt clicked");
                                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_pressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    Log.d("upvote", "I am inside user_vote = 1");


                                } else if (holder.user_vote == -1) {
                                    //holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                                    holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                                    holder.upvt.setImageResource(R.drawable.home_upvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_pressed);
                                    Log.d("upvote", "I am inside user_vote = 0");

                                } else {
                                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                                    holder.upvt.setImageResource(R.drawable.home_upvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    Log.d("upvote", "user_vote not equal to anything");

                                }
                                holder.upvtCL.setClickable(true);
                                holder.dnvtCL.setClickable(true);
                            }
                        });

                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                Log.d("upvote ---> ", "I am before Toast Msg");
                                Toast.makeText(mContext, "Upvoted", Toast.LENGTH_SHORT);

                            }
                        });
                        response.body().close();
                    } catch (Exception e) {
                        Crashlytics.logException(e);
                        e.printStackTrace();
                        Log.i("Null exception", e.getStackTrace().toString());
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
                    //Log.i("Response String: ", response.body().string());
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    @Override
    public long getItemId(int position) {
        Log.d("Adapter->", "getItemId called");
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        Log.d("Adapter->", "getItemViewType called");
        return position;
    }

    void downvote(final myViewHolder holder, final int position) {
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/api/post/downvote";

        MediaType mediaType = MediaType.parse("application/json");
        JSONObject postBody = new JSONObject();
        try {
            postBody.put("postId", mData.get(position).optString("_id"));
        } catch (Exception e) {
            Crashlytics.logException(e);
            e.printStackTrace();
        }
        Log.d("Adapter Downvote -->", "postBody = " + postBody.toString());


        RequestBody body = RequestBody.create(mediaType, postBody.toString());
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", auth_token_local)
                .addHeader("Content-Type", "application/json")
                .addHeader("cache-control", "no-cache")
                .addHeader("Postman-Token", "5fe314cf-7d2f-41d2-a5d3-7abb3ba2f3bc")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ", response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    Handler mainHandler;
                    //setdata(holder,position);
                    try {

                        JSONObject tempObj = new JSONObject(response.body().string());
                        JSONObject obj = tempObj.optJSONObject("action");
                        Log.d("downvote", "action = " + obj.toString());

                        //checking upvote value and updating data source
                        if (mPostAction.get(position).optBoolean("upvote") && !obj.getBoolean("upvote")) {
                            //holder.upvotes = holder.upvotes + 1;
                            //holder.user_vote = 1;

                            //update adapter data source arrays
                            int upvotes = mData.get(position).getInt("upvotes");
                            Log.d("upvotes", "mData before upvotes removed = " + mData.get(position).toString());
                            mData.get(position).remove("upvotes");
                            Log.d("upvotes", "mData after upvotes removed = " + mData.get(position).toString());
                            mData.get(position).put("upvotes", upvotes - 1);
                            Log.d("upvotes", "mData after upvotes added again= " + mData.get(position).toString());
                            //boolean userVote= mPostAction.get(position).getBoolean("upvote");
                            Log.d("upvotes", "mPostAction before upvote removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).remove("upvote");
                            Log.d("upvotes", "mPostAction after upvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).put("upvote", false);
                            Log.d("upvotes", "mPostAction after upvotes added again= " + mPostAction.get(position).toString());
                        }

                        //checking downvote value and updating data source
                        if (obj.getBoolean("downvote")) {
                            //holder.upvotes = holder.upvotes + 1;
                            holder.user_vote = -1;

                            //update adapter data source arrays
                            Log.d("downvotes", "I am inside obj.getboolean()");
                            int downvotes = mData.get(position).getInt("downvotes");
                            Log.d("downvotes", "mData before downvotes removed = " + mData.get(position).toString());
                            mData.get(position).remove("downvotes");
                            Log.d("downvotes", "mData after downvotes removed = " + mData.get(position).toString());
                            mData.get(position).put("downvotes", downvotes + 1);
                            Log.d("downvotes", "mData after downvotes added again= " + mData.get(position).toString());
                            //boolean userVote= mPostAction.get(position).getBoolean("upvote");
                            Log.d("downvotes", "mPostAction before downvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).remove("downvote");
                            Log.d("downvotes", "mPostAction after downvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).put("downvote", true);
                            Log.d("downvotes", "mPostAction after downvotes added again= " + mPostAction.get(position).toString());
                        } else {
                            holder.user_vote = 0;

                            Log.d("downvotes", "I am inside obj.getboolean()");
                            int downvotes = mData.get(position).getInt("downvotes");
                            Log.d("downvotes", "mData before downvotes removed = " + mData.get(position).toString());
                            mData.get(position).remove("downvotes");
                            Log.d("downvotes", "mData after downvotes removed = " + mData.get(position).toString());
                            mData.get(position).put("downvotes", downvotes - 1);
                            Log.d("downvotes", "mData after downvotes added again= " + mData.get(position).toString());
                            //boolean userVote= mPostAction.get(position).getBoolean("upvote");
                            Log.d("downvotes", "mPostAction before downvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).remove("downvote");
                            Log.d("downvotes", "mPostAction after downvotes removed = " + mPostAction.get(position).toString());
                            mPostAction.get(position).put("downvote", false);
                            Log.d("downvotes", "mPostAction after downvotes added again= " + mPostAction.get(position).toString());


                        }


                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                holder.upv.setText(String.format("%d Upvotes", holder.upvotes));
                                holder.dnv.setText(String.format("%d Downvotes", holder.downvotes));
                                Log.d("upvote number", "holder.upvotes = " + holder.upvotes);
                                if (holder.user_vote == 1) {
                                    //holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                                    holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                                    Log.d("downvote", "I am inside user_vote = 1 after upvt clicked");
                                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_pressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    Log.d("downvote", "I am inside user_vote = 1");

                                } else if (holder.user_vote == -1) {
                                    //holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                                    holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                                    holder.upvt.setImageResource(R.drawable.home_upvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_pressed);
                                    Log.d("downvote", "I am inside user_vote = 0");

                                } else {
                                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                                    holder.upvt.setImageResource(R.drawable.home_upvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    Log.d("downvote", "user_vote not equal to anything");

                                }
                                holder.upvtCL.setClickable(true);
                                holder.dnvtCL.setClickable(true);
                            }
                        });
                        response.body().close();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                        Log.i("Null exception", e.getStackTrace().toString());
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", response.body().string());
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    void setdata(final myViewHolder holder, final int position) {
        OkHttpClient client = new OkHttpClient();
        Log.d("Adapter->", "setdata called");
        String url = BASE_URL + "/api/app/loggedindetails";
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ans_id=" + mData.get(position).optString("ans_id"));

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", auth_token_local)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "46c83302-892b-4bfc-8d13-0faf881db00b,8e3f96f4-cbf5-4554-8b72-1c6f8ec26e3a")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "31")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ", response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp = response.body().string();
                    Handler mainHandler;
                    try {
                        JSONObject obj = new JSONObject(resp);
                        if (obj.has("upvotes")) holder.upvotes = obj.getInt("upvotes");
                        else holder.upvotes = 0;
                        if (obj.has("downvotes")) holder.downvotes = obj.getInt("downvotes");
                        else holder.downvotes = 0;
                        if (obj.has("user_vote")) holder.user_vote = obj.getInt("user_vote");
                        else holder.user_vote = 0;
                        if (obj.has("comments")) holder.comments = obj.getInt("comments");
                        else holder.comments = 0;
                        if (obj.has("shares")) holder.shares = obj.getInt("shares");
                        else holder.shares = 0;
                        if (obj.has("bookmarked")) holder.bookmarked = obj.getInt("bookmarked");
                        else holder.bookmarked = 0;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                holder.upv.setText(String.format("%d Upvotes", holder.upvotes));
                                holder.dnv.setText(String.format("%d Downvotes", holder.downvotes));
                                holder.cmnt.setText(String.format("%d", holder.comments));
                                if (holder.views < 999)
                                    holder.view.setText(String.format("%d", holder.views));
                                else {
                                    int rounded = ((holder.views + 99) / 100) * 100;
                                    double roundedTo = rounded / 1000.0;
                                    holder.view.setText(roundedTo + "k");
                                }
                                holder.shr.setText(String.format("%d Shares", holder.shares));
                                holder.shr.setText(String.format("%d Shares", holder.shares));
                                if (holder.user_vote == 1) {
                                    //holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                                    holder.upvt.setImageResource(R.drawable.home_upvote_clicked);
                                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_pressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                                } else if (holder.user_vote == -1) {
                                    //holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                                    holder.dnvt.setImageResource(R.drawable.home_downvote_clicked);
                                    holder.upvt.setImageResource(R.drawable.home_upvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_pressed);

                                } else {
                                    holder.dnvt.setImageResource(R.drawable.home_downvote);
                                    holder.upvt.setImageResource(R.drawable.home_upvote);
                                    holder.upvt.setBackgroundResource(R.drawable.votes_unpressed);
                                    holder.dnvt.setBackgroundResource(R.drawable.votes_unpressed);

                                }
                                if (holder.bookmarked == 1)
                                    holder.follow.setImageResource(R.drawable.bookmarked);
                                    //else holder.follow.setImageResource(R.drawable.bookmark);
                                else
                                    holder.follow.setImageResource(R.drawable.all_ans_bookmark_ribbon);
                            }
                        });
                        response.body().close();
                    } catch (NullPointerException | JSONException e) {
                        Crashlytics.logException(e);
                        Log.i("Null exception", e.getStackTrace().toString());
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: " + mData.get(position).optString("ans_id"), resp);
//                    Log.i("Response message:", response.message());
                }
            }
        });
    }

    void addbookmark(final myViewHolder holder, final int position) {
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ans_id=" + mData.get(position).optString("ans_id"));

        String url = BASE_URL + "/api/app/bookmarkonans";
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token_local)
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "6580d1c2-3cde-47c0-ab17-23d2f4eee8a0,00944a10-3738-47e4-9355-5f148a5c291c")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "31")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ", response.toString());
                    throw new IOException("Unexpected code " + response);
                } else {
                    Handler mainHandler;
                    try {
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                setdata(holder, position);
                            }
                        });
                        response.body().close();
                    } catch (NullPointerException e) {
                        Crashlytics.logException(e);
                        Log.i("Null exception", e.getStackTrace().toString());
                    }
//                    Log.i("Response:", response.toString());
//                    Log.i("Response body:", response.body().toString());
//                    Log.i("Response String: ", response.body().string());
//                    Log.i("Response message:", response.message());
                }
            }
        });

    }


    public class myViewHolder extends RecyclerView.ViewHolder {
        VideoView vid;
        View greyView;
        int upvotes, downvotes, user_vote, comments, views, shares, bookmarked;
        ImageView pro_pic, play, follow, upvt, dnvt, shrd, comm, focus, xDelete, previewImage;
        TextView username, duration, lang, upv, cmnt, view, shr, dnv, desc, postDesc, communityName, previewTitle, previewDesc, accept, decline, pendingTitle, createdAt, totalcomm, firstcommUser, firstcomm;
        String previewUrl;
        // ProgressBar spinner;
        ImageView spinner, three_dots;
        ConstraintLayout pendingStatus;
        LinearLayout commentLayout;

        //YouTubePlayerView youTubePlayerView;
        //YouTubePlayer youTubePlayer;

        RecyclerView mediaRecyclerView;
        MediaAdapter mediaAdapter;
        ConstraintLayout upvtCL, dnvtCL, previewCL;


        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            Log.d("Adapter->", "myViewHolder constructor called");
            totalcomm = itemView.findViewById(R.id.totalcomm);
            firstcommUser = itemView.findViewById(R.id.firstcommUser);
            firstcomm = itemView.findViewById(R.id.firstcomm);
            commentLayout = itemView.findViewById(R.id.commentLayout);
            pro_pic = itemView.findViewById(R.id.propic);
            vid = itemView.findViewById(R.id.vdv);
            greyView = itemView.findViewById(R.id.greyView);
            username = itemView.findViewById(R.id.username);
            communityName = itemView.findViewById(R.id.community_name);
            duration = itemView.findViewById(R.id.durn);
            lang = itemView.findViewById(R.id.lang);
            follow = itemView.findViewById(R.id.follow);
            upv = itemView.findViewById(R.id.nupv);
            play = itemView.findViewById(R.id.play);
            spinner = itemView.findViewById(R.id.my_spinner);
            three_dots = itemView.findViewById(R.id.three_dots);
            xDelete = itemView.findViewById(R.id.x_delete);
            upvtCL = itemView.findViewById(R.id.upv_CL);
            dnvtCL = itemView.findViewById(R.id.dnv_CL);
            previewCL = itemView.findViewById(R.id.preview_CL);
            cmnt = itemView.findViewById(R.id.ncmnt);
            view = itemView.findViewById(R.id.ncount);
            shr = itemView.findViewById(R.id.nshr);
            dnv = itemView.findViewById(R.id.ndnv);
            upvt = itemView.findViewById(R.id.upv);
            dnvt = itemView.findViewById(R.id.dnv);
            shrd = itemView.findViewById(R.id.share);
            comm = itemView.findViewById(R.id.cmnt);
            desc = itemView.findViewById(R.id.desc);
            postDesc = itemView.findViewById(R.id.post_text);
            focus = itemView.findViewById(R.id.focusvw);
            previewTitle = itemView.findViewById(R.id.preview_Title);
            previewDesc = itemView.findViewById(R.id.preview_Desc);
            previewUrl = "";
            previewImage = itemView.findViewById(R.id.preview_Image);
            pendingStatus = itemView.findViewById(R.id.pendingStatus);
            accept = itemView.findViewById(R.id.accept);
            decline = itemView.findViewById(R.id.decline);
            //youTubePlayerView = itemView.findViewById(R.id.youtube_player);
            //youTubePlayerView.setEnableAutomaticInitialization(true);

            mediaRecyclerView = itemView.findViewById(R.id.media_rec_view);
            createdAt = itemView.findViewById(R.id.createdAt);
        }
    }

    void delbookmark(myViewHolder holder, int position) {
        //
    }

    void deletePost(final int position) {
        new AlertDialog.Builder(mContext)
                .setTitle("Delete Post")
                .setMessage("Are you sure you want to delete this Post?")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.

                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "deletePost");
                        mFirebaseAnalytics.logEvent("deletePostClicked", bundle);
                        // Continue with delete operation
                        OkHttpClient client = new OkHttpClient();
                        String url = BASE_URL + "/api/post/delete";
                        MediaType mediaType = MediaType.parse("application/json");
                        JSONObject postDelete = new JSONObject();
                        try {
                            postDelete.put("postId", mData.get(position).optString("_id"));
                        } catch (Exception e) {
                            e.printStackTrace();
                            Crashlytics.logException(e);
                        }
                        Log.i("deletePost Reponse -->", " after postDelete = " + postDelete.toString());

                        RequestBody body = RequestBody.create(mediaType, postDelete.toString());
                        Request request = new Request.Builder()
                                .url(url)
                                .post(body)
                                .addHeader("Content-Type", "application/json")
                                .addHeader("Authorization", auth_token_local)
                                .addHeader("cache-control", "no-cache")
                                .addHeader("Postman-Token", "62f68963-bad1-4ed2-adf1-6d275e647694")
                                .build();

                        Call call = client.newCall(request);
                        call.enqueue(new Callback() {
                            @Override
                            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                                Toast.makeText(mContext, "Deletion Failed. Something went wrong!", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                if (!response.isSuccessful()) {
                                    // You can also throw your own custom exception
                                    Log.i("Response ", response.toString());
                                    throw new IOException("Unexpected code " + response);
                                } else {
                                    //setdata(holder, position);
                                    Log.i("deletePost Reponse -->", " Success " + response.toString());

                                    Handler mainHandler;
                                    try {
                                        mainHandler = new Handler(mContext.getMainLooper());
                                        mainHandler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                Log.i("deletePost Reponse -->", " Inside run");
                                                mData.remove(position);
                                                mPostAction.remove(position);
                                                notifyDataSetChanged();
//                                                notifyItemRemoved(position);
//                                                notifyItemRangeRemoved(position, 1);
                                                Toast.makeText(mContext, "Post Deleted", Toast.LENGTH_LONG).show();
                                            }
                                        });
                                    } catch (NullPointerException e) {
                                        Log.i("Null exception", e.getStackTrace().toString());
                                        Crashlytics.logException(e);
                                    }
                                    Log.i("Response:", response.toString());
                                    Log.i("Response body:", response.body().toString());
                                    Log.i("Response String: ", response.body().string());
                                    Log.i("Response message:", response.message());
                                }
                            }
                        });

                    }
                })
                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
        Log.d("Delete pressed -->", "after HomeFeed Call postId =" + mData.get(position).optString("_id"));
    }


    void declineOnClick(final int position) {
        Log.d("LOG_DATA", "declineOnClick Called");
        String url = BASE_URL + "/api/post/updatePostVisibility";
        String topic_id = CommunityFeed.topicID;
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\n\t\"topicId\":\"" + topic_id + "\",\n\t\"postId\":\"" + mData.get(position).optString("_id") + "\",\n\t\"rule\":\"" + 2 + "\"\n}");
        final Request request = new Request.Builder()
                .url(url)
                .method("POST", body)
                .addHeader("Authorization", Utils.getAuthToken(mContext))
                .addHeader("Content-Type", "application/json")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        String result = response.body().string();
                        JSONObject jsonObject = new JSONObject(result);
                        Log.d("LOG_DATA", "UpdatePendingPost: " + jsonObject);
                        Handler mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                Log.d("PositionDeletion", String.valueOf(position));
                                mData.remove(position);
                                mPostAction.remove(position);
//                                notifyItemRemoved(position);
                                notifyItemRangeChanged(position, 1);
                                Toast.makeText(mContext, "Post removed!", Toast.LENGTH_SHORT).show();
//                                adapter.notifyItemRangeChanged(position, mPostAction.size());
//                                adapter.notifyDataSetChanged();
                            }
                        });


                    } catch (Exception e) {
                        Crashlytics.log(e.toString());
                        Log.e("LOG_DATA", e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private class CustomTagStyleSpan extends ClickableSpan{
        String Id;
        Boolean isClicked;
        public CustomTagStyleSpan(String Id) {
            this.Id = Id;
            isClicked=false;
        }

        @Override
        public void onClick(@NonNull View view) {
            if(!isClicked) {
                isClicked=true;
                goToProfile(Id);
            }
            else    isClicked=false;
            Log.d("OnClickProfile", "Clicked");
//            Toast.makeText(mContext, Id, Toast.LENGTH_SHORT).show();
        }
    }


    public void goToProfile(String User_Id) {
        Intent intent = new Intent(mContext, ProfilePage.class);
        intent.putExtra("USER_ID", User_Id);
        mContext.startActivity(intent);
    }
}