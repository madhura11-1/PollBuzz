package co.revidly.android.helpers;


import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.sip.SipSession;
import android.provider.SyncStateContract;
import android.util.Log;

import com.crashlytics.android.Crashlytics;

import co.revidly.android.FullscreenActivity;
import co.revidly.android.HomeFeed;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.SplashScreenActivity;

public class InternetConnector_Checker extends BroadcastReceiver {

    FullscreenActivity fullscreenActivityContext;
    NetworkInfo.State wifiState = null;
    NetworkInfo.State mobileState = null;
    public static boolean isOnline = true;
    //public static ConnectivityReceiverListener connectivityReceiverListener;

    public InternetConnector_Checker() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        try {

           // boolean isVisible = FullscreenActivity.isActivityVisible();// Check if
            // activity
            // is
            // visible
            // or not
            //Log.i("Activity is Visible ", "Is activity visible : " + isVisible);

            // If it is visible then trigger the task else do nothing
            if (true) {
                ConnectivityManager connectivityManager = (ConnectivityManager) context
                        .getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = connectivityManager
                        .getActiveNetworkInfo();
                wifiState = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
                mobileState = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState();
                /*
                if(context instanceof FullscreenActivity) {
                     fullscreenActivityContext = (FullscreenActivity) context;
                }
                */
                // Check internet connection and according to state change the
                // text of activity by calling method
                if (networkInfo != null && networkInfo.isConnected() && (NetworkInfo.State.CONNECTED == wifiState || NetworkInfo.State.CONNECTED == mobileState)) {

                    //new FullscreenActivity().changeTextStatus(true);
                    //FullscreenActivity.isOnline = true;
                    isOnline = true;
                    Log.d("InternetConnector", "I am connected isOnline = " + true);

                } else {
                    //new FullscreenActivity().changeTextStatus(false);
                    //FullscreenActivity.isOnline = false;
                    isOnline = false;
                    Log.d("InternetConnector", "I am not connected isOnline = " + false);
                    if (context instanceof HomeFeed)
                        new HomeFeed().getInstance().displayInternetDialogue();
                    else if (context instanceof HomeScreen_Activity)
                        new HomeScreen_Activity().getInstance().displayInternetDialogue();
                    else if (context instanceof SplashScreenActivity)
                        new SplashScreenActivity().getInstance().displayInternetDialogue();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Crashlytics.logException(e);
        }

    }


}
