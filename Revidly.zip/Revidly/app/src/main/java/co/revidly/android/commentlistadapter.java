package co.revidly.android;

import com.bumptech.glide.Glide;
import com.crashlytics.android.Crashlytics;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import co.revidly.android.helpers.LoggedInUser;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;


public class commentlistadapter extends RecyclerView.Adapter<commentlistadapter.MyViewHolder> {

    Context mContext;
    List<JSONObject> mData;
    private static String TAG = "CommentActivity";
    String authorId = "";

    @NonNull
    @Override
    public commentlistadapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View vw = inflater.inflate(R.layout.comment_card_item,parent,false);
        return new commentlistadapter.MyViewHolder(vw);    }

    public commentlistadapter(Context mContext, List<JSONObject> mData, String authorId) {
        this.mContext = mContext;
        this.mData = mData;
        this.authorId = authorId;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        Log.d("Data_format", authorId + " " + LoggedInUser.userId);
        /*** Change the Below url to the url of the dp of user who posted the comment***/
        holder.delete.setVisibility(View.INVISIBLE);
//        if(mData.get(position).optString("avatar").isEmpty() || !mData.get(position).has("avatar") || mData.get(position).optString("avatar") == "null" )
//            Picasso.get().load(R.drawable.propic1).placeholder(R.drawable.propic1).into(holder.propic);
//        else
//            Picasso.get().load(mData.get(position).optString("avatar")).into(holder.propic);
        final String userId;
        if(mData.get(position).has("userId"))
            userId = mData.get(position).optString("userId");
        else
            userId = "";

        Glide.with(mContext)
                .load(BASE_URL + "/app/profilePic/" +  userId + ".jpg")
                .placeholder(R.drawable.propic1)
                .into(holder.propic);

        holder.username.setText(mData.get(position).optString("userName"));
        if (LoggedInUser.userId.equals(userId) || LoggedInUser.userId.equals(authorId)) {
            holder.delete.setVisibility(View.VISIBLE);
        }
        else{
            holder.delete.setVisibility(View.INVISIBLE);
        }
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OkHttpClient client = new OkHttpClient();
                String url = BASE_URL + "/api/comment/delete";
                JSONObject commentDelObj = new JSONObject();
                try {
                    commentDelObj.put("commentId", mData.get(position).optString("_id"));
                    commentDelObj.put("postId", mData.get(position).optString("postId"));
                    Log.d("commentDelObj", commentDelObj.toString());
                }
                catch(Exception e) {
                    e.printStackTrace();
                    Crashlytics.logException(e);
                }
                String auth_token_local = LoggedInUser.auth_token_global;
                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, commentDelObj.toString());
                Request request = new Request.Builder()
                        .url(url)
                        .post(body)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Authorization", auth_token_local)
                        .build();
                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        Toast.makeText(mContext, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if(!response.isSuccessful()){
                            throw new IOException("Unexpected code " + response);
                        }
                        else{
                            Handler mainHandler;
                            mainHandler = new Handler(mContext.getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    mData.remove(position);
                                    notifyDataSetChanged();
                                    //System.out.println(mlist+"    "+mAdapter.mData.get(0).comment);
                                }
                            });
                            response.body().close();
                        }
                    }
                });
            }
        });
        try {
            JSONArray taggedInfo = mData.get(position).optJSONArray("taggedUsers");
            List<String> names = new ArrayList<>(), UIDs = new ArrayList<>();
            for (int i = 0; i < taggedInfo.length(); i++) {
                JSONObject obj = taggedInfo.optJSONObject(i);
                names.add(obj.optString("name"));
                UIDs.add(obj.optString("userId"));
            }
            String text1 = mData.get(position).optString("content");
            text1 = text1.replace("\n", "\n ");
            SpannableString text = new SpannableString(text1);
            String[] arr = text1.split(" ");
            for (int i = 0; i < arr.length - 1; i++) {
                if (arr[i].trim().startsWith("@")) {
                    String tag_name = arr[i] + " " + arr[i + 1].trim();
                    tag_name = tag_name.substring(1);
                    Log.d("CommentAdapter123", tag_name);
                    if (names.contains(tag_name)) {
                        Log.d("Countung", "Hi");
                        text.setSpan(new CustomStyleSpan(UIDs.get(names.indexOf(tag_name))),
                                text1.indexOf(tag_name) - 1,
                                text1.indexOf(tag_name) + tag_name.length(),
                                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                }
            }
            holder.comment.setText(text);
            holder.comment.setMovementMethod(LinkMovementMethod.getInstance());
        }catch (Exception e){
            Crashlytics.log(e.getMessage());
        }
        Log.d("UserId", userId);
        holder.username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("CommentAdapter->", "Profile Pic Clicked");
                if(mContext instanceof ProfilePage) {
                    //if(userId.equals(LoggedInUser.userId))
                    //{
                    //  Toast.makeText(mContext,"You are already in your Profile", Toast.LENGTH_SHORT);
                    //}
                    //else {
                    Intent intent = new Intent(mContext, ProfilePage.class);
                    intent.putExtra("USER_ID", userId);
                    mContext.startActivity(intent);
                    ((ProfilePage) mContext).finish();
                    //}
                }
                else
                {
                    Intent intent = new Intent(mContext, ProfilePage.class);
                    intent.putExtra("USER_ID", userId);
                    mContext.startActivity(intent);
                }

            }
        });
        holder.propic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("CommentAdapter->", "Profile Pic Clicked");
                if (mContext instanceof ProfilePage) {
                    //if(userId.equals(LoggedInUser.userId))
                    //{
                    //  Toast.makeText(mContext,"You are already in your Profile", Toast.LENGTH_SHORT);
                    //}
                    //else {
                    Intent intent = new Intent(mContext, ProfilePage.class);
                    intent.putExtra("USER_ID", userId);
                    mContext.startActivity(intent);
                    ((ProfilePage) mContext).finish();
                    //}
                } else {
                    Intent intent = new Intent(mContext, ProfilePage.class);
                    intent.putExtra("USER_ID", userId);
                    mContext.startActivity(intent);
                }
            }
        });
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView propic;
        TextView username,comment;
        ImageButton like, delete;
        ConstraintLayout containerCL;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.commusername);
            comment= itemView.findViewById(R.id.commenttext);
            propic = itemView.findViewById(R.id.commpropic);
            like = itemView.findViewById(R.id.commlike);
            delete = itemView.findViewById(R.id.commdel);
            containerCL = itemView.findViewById(R.id.containerCL);
        }
    }



    @Override
    public int getItemCount() {
        return mData.size();
    }
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    private void removeItem(int position){
        mData.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,mData.size());
    }
    private class CustomStyleSpan extends ClickableSpan{
        String Id;
        Boolean isClicked;
        public CustomStyleSpan(String Id) {
            this.Id = Id;
            isClicked=false;
        }

        @Override
        public void onClick(@NonNull View view) {
            if(!isClicked) {
                isClicked=true;
                goToProfile(Id);
            }
            else    isClicked=false;
            Log.d("OnClickProfile", "Clicked");
//            Toast.makeText(mContext, Id, Toast.LENGTH_SHORT).show();
        }
    }

    public void goToProfile(String User_Id) {
        Intent intent = new Intent(mContext, ProfilePage.class);
        intent.putExtra("USER_ID", User_Id);
        mContext.startActivity(intent);
    }
}
