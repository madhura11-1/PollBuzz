package co.revidly.android;

public class FollowerList {
    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    String img;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    String userId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String name;
    public FollowerList(String img, String name, String userId) {
        this.img = img;
        this.name = name;
        this.userId = userId;
    }

}
