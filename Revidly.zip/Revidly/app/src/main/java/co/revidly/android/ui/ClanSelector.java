package co.revidly.android.ui;

import org.json.JSONArray;

import java.util.List;

public class ClanSelector {
    private String TAG = "Revidly:Users:ClanSelector";
    List<String> mData;
//    JSONArray selectedTopicsArray;
//    boolean clanAppeared[];

    public ClanSelector(List<String> mData)
    {
//        selectedTopicsArray = new JSONArray();
//        clanAppeared = null;
        this.mData = mData;

    }

    public void addId(String Id) {
        mData.add(Id);
    }

    public void removeId(String Id) {
        mData.remove(Id);
    }
//    public void setUserTopics(JSONObject object)
//    {
//        mData.add(object);
//        clanAppeared = new boolean[mData.size()];
//        int i = 0;
//        Log.d(TAG, "setAllTopics called looping mData.size: " + (mData.size() - 1) + " and userTopics size:" + (userTopics.length()-1) );
//
//        while(i <= mData.size() - 1) {
//            clanAppeared[i] = false;
//            i++;
//        }
        //setSelectedTopics();
//    }

    //    public void addUserTopic(int position)
//    {
//        Log.d(TAG, "addUserTopic: mData:"+mData.toString());
//        selectedTopicsArray.put( mData.get(position).optString("_id"));
//        Log.d(TAG,"addUserTopic selectedTopicsArray = " + selectedTopicsArray );
//        Log.d(TAG,"addUserTopic, position = " + position );
//        Log.d(TAG,"addUserTopic, length = " + selectedTopicsArray.length() );
//    }
//    public void removeUserTopic(int position) {
//        Log.d(TAG, "removeUserTopic: called for position:"+position);
//        try{
//            JSONArray list = new JSONArray();
//            //JSONArray jsonArray = new JSONArray(jsonstring);
//            if (selectedTopicsArray != null) {
//                int len = selectedTopicsArray.length();
//                Log.d(TAG, "removeUserTopic: len = selectedTopicsArray.length(): "+selectedTopicsArray.length());
//                if(len == 1) {
//                    selectedTopicsArray = new JSONArray();
//                }
//                else {
//                    for (int i = 0; i < len; i++) {
//                        //Excluding the item at position
//                        Log.d(TAG, "removeUserTopic: selectedTopicsArray.get(i): "+selectedTopicsArray.get(i)+" mData._id: "+mData.get(position).optString("_id"));
//                        if (selectedTopicsArray.get(i) !=  mData.get(position).optString("_id")) {
//                            Log.d(TAG, "removeUserTopic: putting in selected topicsArray");
//                            list.put(selectedTopicsArray.get(i));
//                        }
//                    }
//                    selectedTopicsArray = list;
//                }
//            }
//            else {
//                Log.d(TAG, "selectedTopicsArray is null. not doing anything");
//            }
//        }catch (Exception e)
//        {
//            e.printStackTrace();
//        }
//        Log.d(TAG,"removeUserTopic = " + selectedTopicsArray );
//        Log.d(TAG,"removeUserTopic, position = " + position );
//        Log.d(TAG,"removeUserTopic, length = " + selectedTopicsArray.length() );
//    }
    public List<String> getSelectedTopics()
    {
        return mData;
    }
//    public void setPositionAppeared(int position)
//    {
//        clanAppeared[position] = true;
//        Log.d(TAG, "setPosition ClanAppeared" + clanAppeared[position]);
//    }
//    public void setPositionDisappeared(int position)
//    {
//        clanAppeared[position] = false;
//        Log.d(TAG, "setPosition ClanAppeared" + clanAppeared[position]);
//    }
//    public boolean getPositionAppeared(int position)
//    {
//        Log.d(TAG, "getPosition ClanAppeared" + clanAppeared[position]);
//        return clanAppeared[position];
//    }
}
