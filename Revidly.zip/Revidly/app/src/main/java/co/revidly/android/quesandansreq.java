package co.revidly.android;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;

import com.jaeger.library.StatusBarUtil;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.ViewPager;

public class quesandansreq extends FullscreenActivity {

    private TabAdapter adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    BottomNavigationView bottomNavigationView;
    AddAnswer addAnswer;
    inviteSheet inviteSheet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        main=false;
        setContentView(R.layout.listofques_ansrequest);
        StatusBarUtil.setColor(this, Color.LTGRAY, 2);
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        ConstraintLayout flo = findViewById(R.id.lisqanda);
        flo.setPadding(0, result, 0, 0);
        addAnswer= new AddAnswer();
        inviteSheet= new inviteSheet();
        viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);

        adapter = new TabAdapter(getSupportFragmentManager());
        adapter.addFragment(new quesforyou(), "For You");
        adapter.addFragment(new requests(), "Requests");
        adapter.addFragment(new yourquestions(), "Your Questions");
        viewPager.setOffscreenPageLimit(2);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        /*
        bottomNavigationView.getMenu().findItem(R.id.action_answer).setChecked(true);
        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(false);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_home:
                        finish();
                        break;
                    case R.id.action_discover:
                        bottomNavigationView.getMenu().findItem(R.id.action_discover).setEnabled(false);
                        finish();
                        View viewdi = findViewById(R.id.viewPager);
                        Intent discover = new Intent(viewdi.getContext(), searchView.class);
                        startActivityForResult(discover, 0);
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(true);
                        break;
                    case R.id.action_answer:
                        viewPager.setCurrentItem(0);
                        Toast.makeText(quesandansreq.this,"Answer Questions",Toast.LENGTH_SHORT);
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(false);
                        break;
                    case R.id.action_ask_ques:
                        qaup=true;
                        finish();
                        //BottomSheetFragment fragment = new BottomSheetFragment();
                        //fragment.show(getSupportFragmentManager(), "TAG");
                        break;
                    case R.id.action_profile:
                        viewPager.setCurrentItem(2);
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(true);
                        break;

                }
                return true;
            }
        });


        if(prof){
            viewPager.setCurrentItem(2);
            bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(true);
            bottomNavigationView.getMenu().findItem(R.id.action_profile).setChecked(true);
            prof=false;
        }

         */
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1)
        if (resultCode == RESULT_OK) {
            Uri selectedMediaUri = data.getData();
            /*if (selectedMediaUri.toString().contains("image")) {
                //handle image
            } else  */
            if (selectedMediaUri.toString().contains("video")) {
                //handle video
                System.out.println("Video Selected");
                Uri selectedImageUri = data.getData();

                // OI FILE Manager
                String filemanagerstring = selectedImageUri.getPath();

                /*Uri uri = data.getData();
                File file = new File(uri.getPath());//create path from uri
                final String[] split = file.getPath().split(":");//split the path.
                String filePath = split[1];*/
                // MEDIA GALLERY
                String selectedImagePath = selectedImageUri.getPath();
                System.out.println("Uri "+selectedMediaUri);
                System.out.println("Path "+filemanagerstring);

            }
            System.out.println(data.getData());
            System.out.println(data.getData().toString());
        }
    }
    void queClk(String q_id,String question){
        qaquestion=question;
        qa_ques_id=q_id;
        finish();
        Intent myIntent = new Intent(getWindow().getContext(), QuesAndAns.class);
        startActivityForResult(myIntent, 0);
    }

}
