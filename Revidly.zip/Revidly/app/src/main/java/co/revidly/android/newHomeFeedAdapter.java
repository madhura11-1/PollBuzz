package co.revidly.android;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

import co.revidly.android.helpers.Config;


public class newHomeFeedAdapter extends RecyclerView.Adapter<newHomeFeedAdapter.MyViewHolder> {

    Context mContext;
    List<JSONObject> mData;
    private static String TAG = "NewHomeFeed";

    public newHomeFeedAdapter(Context mContext, List<JSONObject> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public newHomeFeedAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View vw = inflater.inflate(R.layout.new_home_item, parent, false);
        return new newHomeFeedAdapter.MyViewHolder(vw);
    }


    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        if (mData.get(position) == null) {
            holder.clanName.setText("All Posts");
            holder.clanDesc.setText("Posts from your Chosen Clans");
            holder.clanPic.setImageResource(R.drawable.ic_person_black_24dp);
            Glide.with(mContext)
                    .asBitmap()
                    .circleCrop()
                    .load(R.drawable.revidly_icon)
                    .into(holder.clanPic);
            holder.clickClan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, HomeFeed.class);
                    mContext.startActivity(intent);
                }
            });
        } else {
            Log.d("Testing", mData.get(position).toString());
            Log.d("Testing", Config.BASE_URL + "/app/topic/" + mData.get(position).optString("topicId") + ".jpg");
            holder.clanName.setText(mData.get(position).optString("name"));
            Log.d("NewPosts", "" + mData.get(position).optInt("postsCount"));
            if (mData.get(position).optInt("postsCount") == 0) {
                holder.postCount.setVisibility(View.GONE);
                holder.clanDesc.setText("No New Post");
            }
            else if (mData.get(position).optInt("postsCount") == 1) {
                holder.postCount.setText(""+mData.get(position).optInt("postsCount"));
                holder.postCount.setVisibility(View.VISIBLE);
                holder.clanDesc.setText("1 New Post");
            }
            else if (mData.get(position).optInt("postsCount") <= 50) {
                holder.postCount.setText(""+mData.get(position).optInt("postsCount"));
                holder.postCount.setVisibility(View.VISIBLE);
                holder.clanDesc.setText(mData.get(position).optInt("postsCount") + " New Posts");
            }
            else {
                holder.postCount.setText("50+");
                holder.postCount.setVisibility(View.VISIBLE);
                holder.clanDesc.setText("50+ New Posts");
            }
            holder.clanPic.setImageResource(R.drawable.ic_person_black_24dp);
            Glide.with(mContext)
                    .asBitmap()
                    .circleCrop()
                    .load(Config.BASE_URL + "/app/topic/" + mData.get(position).optString("topicId") + ".jpg")
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            holder.clanPic.setImageBitmap(resource);
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {

                        }
                    });
            holder.clickClan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, CommunityFeed.class);
                    JSONArray temp = new JSONArray();
                    temp.put(mData.get(position));
                    intent.putExtra("COMMUNITY_TOKEN", temp.toString());
                    mContext.startActivity(intent);
                    holder.clanDesc.setText("No New Post");
                    holder.postCount.setVisibility(View.GONE);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView clanPic;
        TextView clanName, clanDesc;
        ConstraintLayout clickClan;
        TextView postCount;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            clickClan = itemView.findViewById(R.id.clickClan);
            clanPic = itemView.findViewById(R.id.clanPic);
            clanName = itemView.findViewById(R.id.clanName);
            clanDesc = itemView.findViewById(R.id.clanDesc);
            postCount=itemView.findViewById(R.id.postCount);
        }
    }

    void filterList(List<JSONObject> filteredList) {
        mData = filteredList;
        notifyDataSetChanged();
    }
}
