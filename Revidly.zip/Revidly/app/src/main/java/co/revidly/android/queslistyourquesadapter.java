package co.revidly.android;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.FullscreenActivity.auth_token;
import static co.revidly.android.FullscreenActivity.invite_ques_id;
import static co.revidly.android.FullscreenActivity.uplque_id;
import static co.revidly.android.FullscreenActivity.uplquestion;
import static co.revidly.android.helpers.Config.BASE_URL;

public class queslistyourquesadapter extends RecyclerView.Adapter<queslistyourquesadapter.MyViewHolder> {
    Context mContext;
    List<JSONObject> mData;
    FirebaseAnalytics mFirebaseAnalytics;
    public queslistyourquesadapter(Context mContext, List<JSONObject> mData) {
        this.mContext = mContext;
        this.mData = mData;
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(mContext);

    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        holder.question.setText(mData.get(position).optString("title"));
        holder.question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((quesandansreq) mContext).queClk(mData.get(position).optString("_id"), mData.get(position).optString("title"));
            }
        });
        if (mData.get(position).optJSONArray("answered").length() == 0)
            holder.noans.setText("No answer yet - ");
        else if (mData.get(position).optJSONArray("answered").length() == 1)
            holder.noans.setText("1 Answer - ");
        else
            holder.noans.setText(String.format("%d Answers - ", mData.get(position).optJSONArray("answered").length()));
        holder.lastfoll.setText((mData.get(position).optString("date")).subSequence(0, 10));
        holder.close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.question.setClickable(false);
                holder.close.setClickable(false);
                OkHttpClient client = new OkHttpClient();

                MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");

                String url = BASE_URL + "/api/app/quesdelete";
                RequestBody body = RequestBody.create(mediaType, "ques_id=" + mData.get(position).optString("_id"));
                Request request = new Request.Builder()
                        .url(url)
                        .post(body)
                        .addHeader("Content-Type", "application/x-www-form-urlencoded")
                        .addHeader("Authorization", auth_token)
                        .addHeader("cache-control", "no-cache")
                        .addHeader("Postman-Token", "c0a80ba4-05aa-4e9b-8eb2-aed267bc376e")
                        .build();
                Call call = client.newCall(request);
                removeItem(holder.getAdapterPosition());
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        holder.question.setClickable(true);
                        holder.close.setClickable(true);
                        //Toast.makeText(mContext,"Failed",Toast.LENGTH_SHORT).show();
                        Log.i("Failed ",e.getStackTrace().toString());
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        //Toast.makeText(mContext,"Passed",Toast.LENGTH_SHORT).show();
                        Log.i("Passed " + mData.get(position).optString("_id"), response.toString());
                        if(response.isSuccessful()){
                            Handler mainHandler;
                            mainHandler = new Handler(mContext.getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(mContext,"Deleted",Toast.LENGTH_SHORT).show();
                                }
                            });
                            response.body().close();
                        } else {
                            Handler mainHandler;
                            mainHandler = new Handler(mContext.getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(mContext,"Unable to delete",Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                });

            }
        });
        holder.answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] PERMISSIONS = {android.Manifest.permission.WRITE_EXTERNAL_STORAGE};
                for (String permission : PERMISSIONS) {
                    if (ActivityCompat.checkSelfPermission(mContext, permission) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions((Activity) mContext, PERMISSIONS,0);
                    }
                }
                uplque_id = mData.get(position).optString("_id");
                uplquestion = mData.get(position).optString("title");
//                ///////////////////((quesandansreq) mContext).qu= mData.get(position).quesno;
                ((quesandansreq) mContext).addAnswer.show(((quesandansreq) mContext).getSupportFragmentManager(),"TAG");
            }
        });
        holder.invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                invite_ques_id = mData.get(position).optString("_id");
                ((quesandansreq) mContext).inviteSheet.show(((quesandansreq) mContext).getSupportFragmentManager(),"Invite");

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"invite");
                mFirebaseAnalytics.logEvent("inviteClicked",bundle);
            }
        });
        holder.bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bookmark(mData.get(position).optString("_id"));
                Toast.makeText(mContext,"Bookmarked",Toast.LENGTH_SHORT).show();

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"bookmark");
                mFirebaseAnalytics.logEvent("bookmarkClicked",bundle);
            }
        });
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View vw = inflater.inflate(R.layout.your_ques_item, parent, false);
        return new MyViewHolder(vw);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView question, noans, lastfoll;
        ImageButton close;
        Button answer, invite, bookmark;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            question = itemView.findViewById(R.id.qaquestion);
            noans = itemView.findViewById(R.id.noofanswers);
            lastfoll = itemView.findViewById(R.id.qalastfollowed);
            close = itemView.findViewById(R.id.close);
            answer = itemView.findViewById(R.id.qaanswerbtn);
            invite = itemView.findViewById(R.id.qaaskother);
            bookmark = itemView.findViewById(R.id.qabookmark);
        }
    }


    @Override
    public int getItemCount() {
        return mData.size();
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }
    private void removeItem(int position){
        mData.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,mData.size());
    }

    void bookmark(String ques_id){
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ques_id="+ques_id);
        Request request = new Request.Builder()
                .url(BASE_URL+"/api/app/bookmarkonques")
                .post(body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token)
                .addHeader("cache-control", "no-cache")
                .addHeader("Postman-Token", "3a9400f7-d573-4473-88a2-e0839df00330")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ", response.toString());

                    throw new IOException("Unexpected code " + response);
                } else {
                    Log.i("Response Success ", response.toString());
                    Handler mainHandler = new Handler(mContext.getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {

                        }
                    });
                    response.body().close();
                }

            }
        });

    }

}
