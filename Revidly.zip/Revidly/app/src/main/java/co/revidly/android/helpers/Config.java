package co.revidly.android.helpers;

public class Config {

    public static final String BASE_URL = "https://dev-api.revidly.co";

    public static final String BASE_HOST = "dev-api.revidly.co";

    public static final String API_MEDIA_URL = BASE_URL + "/media/";

    public static final String VIDEO_THUMB = "video_thumbnail2-1580816876526.jpg";

}
