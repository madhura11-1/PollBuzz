package co.revidly.android;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;

public class FollowerListActivity extends AppCompatActivity {
    private static String TAG = "getUserDetails:FollowerList";
    String followerUrl;
    ArrayList<FollowerList> followerLists;
    JSONArray data;
    static public String auth_token;
    private JSONObject data1;
    RecyclerView recyclerView;
    ImageView backButton;
    ProgressBar progressBar;
    boolean follow = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follower_list);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        followerLists = new ArrayList<>();
        auth_token = Utils.getAuthToken(getApplicationContext());
        backButton = findViewById(R.id.backArrow);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setClickable(false);
        getUserDetails();
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    public void getUserDetails(){
        progressBar.setVisibility(View.VISIBLE);
        followerUrl = BASE_URL + "/api/follow/followers?countOnly=no&userId=" + getIntent().getStringExtra("userId");

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(followerUrl)
                .method("GET", null)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e(TAG,e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                if(response.isSuccessful())
                {
                    try {
                        String resp = response.body().string();
                        Log.d(TAG,"Response body: "+resp);
                        data1 = new JSONObject(resp);
                        data = data1.getJSONArray("data");
                        Log.d(TAG,"dataBody:" + data);
                        String followerAvatar,followerName,followerUserId;
                        Log.d(TAG, "onResponse: "+ data.length());
                        for(int i=0;i<data.length();i++){
                            JSONObject object = data.getJSONObject(i);
                            followerAvatar = object.getString("followerAvatar");
                            Log.d(TAG, "FollowerAvatar: " + followerAvatar);
                            followerName = object.getString("followerName");
                            followerUserId = object.getString("follower");
                            Log.d(TAG, "FollowerName: " + followerName);
                            followerLists.add(new FollowerList(followerAvatar,followerName,followerUserId));

                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                progressBar.setVisibility(View.GONE);
                                if(followerLists.isEmpty()){
                                    findViewById(R.id.noFollowers).setVisibility(View.VISIBLE);
                                }
                                else {
                                    FollowerListAdapter followerListAdapter = new FollowerListAdapter(followerLists, FollowerListActivity.this,follow);
                                    recyclerView.setAdapter(followerListAdapter);
                                    findViewById(R.id.noFollowers).setVisibility(View.GONE);
                                }
                            }
                        });
                        response.body().close();
                    }
                    catch (Exception e){
                        Log.e(TAG,e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        });
    }
}
