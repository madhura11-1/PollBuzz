package co.revidly.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.iceteck.silicompressorr.SiliCompressor;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static android.app.Activity.RESULT_OK;
import static co.revidly.android.FullscreenActivity.auth_token;
import static co.revidly.android.helpers.Config.BASE_URL;
import static co.revidly.android.helpers.Config.BASE_HOST;

public class inviteSheet extends BottomSheetDialogFragment {
    addquesrequestansadapter adapter;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.AppBottomSheetDialogTheme2);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                BottomSheetDialog d = (BottomSheetDialog) dialog;
                FrameLayout bottomSheet = (FrameLayout) d.findViewById(R.id.design_bottom_sheet);
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) bottomSheet.getParent();
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
                bottomSheetBehavior.setPeekHeight(bottomSheet.getHeight());
                coordinatorLayout.getParent().requestLayout();
            }
        });
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void setupDialog(final Dialog dialog, int style) {
        super.setupDialog(dialog, style);

        //Set the custom view
        View view = LayoutInflater.from(getContext()).inflate(R.layout.addquestion3, null);
        dialog.setContentView(view);
        ImageButton close = view.findViewById(R.id.imageButton);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        final EditText searchpeople = view.findViewById(R.id.Searchpeople);
        searchpeople.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchpeople.requestFocus();
            }
        });
        searchpeople.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.getFilter().filter(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        RecyclerView recyclerView2 = (RecyclerView) view.findViewById(R.id.people);
        if(getDialog()!=null)
        getuser(recyclerView2);
        Button done = view.findViewById(R.id.button4);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });
    }
    void getuser(final RecyclerView recyclerView2){
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(BASE_URL+"/api/app/fetchusers")
                .get()
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token)
                .addHeader("User-Agent", "PostmanRuntime/7.20.1")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "8d2c4b40-29dd-40fd-b728-a87bb1bd4404,f46460c7-2cd1-4983-b0b3-0ee91e175190")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();


        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    throw new IOException("Unexpected code " + response);
                } else {
                    if (getDialog() != null) {
                        Handler mainHandler = new Handler(getDialog().getContext().getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    String resp = response.body().string();
                                    JSONArray result = new JSONArray(resp);
                                    RecyclerView.LayoutManager layoutManager2;
                                    layoutManager2 = new LinearLayoutManager(getDialog().getContext());
                                    recyclerView2.setLayoutManager(layoutManager2);
                                    final List<JSONObject> mList = new ArrayList<>();
                                    for (int i = 0; i < result.length(); i++) {
                                        final JSONObject obj = new JSONObject(result.get(i).toString());
                                        mList.add(obj);
                                    }
                                    Handler mainHandler = new Handler(getContext().getMainLooper());
                                    mainHandler.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            adapter = new addquesrequestansadapter(getContext(), mList);
                                            recyclerView2.setAdapter(adapter);
                                        }
                                    });

                                } catch (JSONException | IOException e) {
                                    e.printStackTrace();
                                    Crashlytics.logException(e);
                                }
                            }
                        });
                    }
                    response.body().close();
                }
            }
        });

    }
}
