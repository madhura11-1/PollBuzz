package co.revidly.android;

import com.crashlytics.android.Crashlytics;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.ClanSelector;

import static co.revidly.android.helpers.LoggedInUser.userTopics;

public class UserClansAdapter extends RecyclerView.Adapter<UserClansAdapter.UserClansViewHolder> {

    Context mContext;
    List<JSONObject> mData;
    String auth_token_local;
    JSONArray selectedTopicsArray;
    ClanSelector clanSelector;
    boolean selectedTopics;
    JSONArray adminTopics;
    boolean userClicked = false;
    List<JSONObject> mDataFiltered;

    public UserClansAdapter(Context mContext, List<JSONObject> mData, ClanSelector clanSelector, boolean selectedTopics) {
        this.mContext = mContext;
        this.mData = mData;
        auth_token_local = UserClans.auth_token_local;
        this.clanSelector = clanSelector;
        this.selectedTopics = selectedTopics;
        adminTopics = LoggedInUser.topicAdmin;
        mDataFiltered = new ArrayList<>();
    }

    @Override
    public UserClansViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View v = inflater.inflate(R.layout.clans_card_item,parent,false);
        //service = Executors.newFixedThreadPool(4);
        Log.d("UserClansAdapter ->", "onCreateViewHolder called");
        return new UserClansViewHolder(v);

    }

    String urL;

    @SuppressLint({"ResourceAsColor", "ClickableViewAccessibility"})
    @Override
    public void onBindViewHolder(@NonNull final UserClansViewHolder holder, final int position) {

        String topicName;
        //if(!selectedTopics)
        topicName = mData.get(position).optString("name");
        //Drawable img = mContext.getResources().getDrawable( R.drawable.ic_settings_black_24dp );
        Drawable img = mContext.getResources().getDrawable( R.drawable.clan_admin );

            try{
                for(int i=0; i<adminTopics.length();i++){
                    JSONObject topic = adminTopics.getJSONObject(i);
                    Log.d("LOG_DATA","UserCLAN ID: "+ mData.get(position).optString("topicId"));
                    Log.d("LOG_DATA","AdminCLAN ID: "+topic.optString("topicId"));
                    if(topic.optString("topicId").equalsIgnoreCase(mData.get(position).optString("topicId"))){
                        img.setBounds( 0, 0, 60, 60 );
                        holder.clan.setCompoundDrawables( img, null, null, null );
                    }
                    else{

                    }

                }
            }
            catch (Exception e){
                Log.e("LOG_DATA",e.getMessage());
                e.printStackTrace();
            }



        //else
          //  topicName = mData.get(position).optString("topic_name");
        final String topicId = mData.get(position).optString("_id");
        Log.d("LOG_DATA","ID: "+topicId);
        Log.d("UserClan Adapter", "topicName = " + topicName);
        //holder.clan.setText(topicName + " - " + mData.get(position).optString("users"));
        holder.clan.setText(topicName);
        int clanHeight = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 30, mContext.getResources().getDisplayMetrics());
        if((mContext instanceof HomeFeed || mContext instanceof CommunityFeed) && !selectedTopics) {
            holder.userCount.setVisibility(View.VISIBLE);
            holder.userCountIcon.setVisibility(View.VISIBLE);
            holder.userCount.setText(mData.get(position).optString("users") + " Users");
            //holder.clan.setLayoutParams (new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, clanHeight));

        }
        else if(mContext instanceof HomeFeed && selectedTopics) {
            holder.userCount.setVisibility(View.GONE);
            holder.userCountIcon.setVisibility(View.GONE);
            holder.clan.setLayoutParams (new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, clanHeight));
            holder.clansCardCL.setLayoutParams (new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT));
        }
        else
        {
            holder.userCount.setVisibility(View.GONE);
            holder.userCountIcon.setVisibility(View.GONE);
            //holder.clan.setLayoutParams (new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, clanHeight));

        }
        try {
            if (!selectedTopics)
            {
//                if (!clanSelector.getPositionAppeared(position)) {
//                    for (int i = 0; i <= userTopics.length() - 1; i++) {
                Log.d("ClanSelectorListB",clanSelector.getSelectedTopics().toString());
                for(int i=0;i<clanSelector.getSelectedTopics().size();i++){
                    String _id=clanSelector.getSelectedTopics().get(i);
//                        JSONObject topic = clanSelector.getSelectedTopics().getJSONObject(i);
                        Log.d("UserClan Adapter", "before topic added  position = " + mData.get(position).optString("_id"));
//                        Log.d("UserClan Adapter", "before topic added  i = " + topic.getString("topicId"));
                        Log.d("Position",String.valueOf(position));
                        if ((mData.get(position).optString("_id")).equals(_id)) {
                            Log.d("UserClan Adapter", "earlier topics added  = " + mData.get(position).optString("_id"));
                            {
                                holder.clan.setPressed(true);
                                holder.clan.setSelected(true);
//                                clanSelector.addUserTopic(position);
                            }
                        }
//                        for (int z = 0; z < mData.size(); z++) {
//                            if (mData.get(z).optString("_id").equals(topic.getString("topicId"))) {
//                                holder.clan.setPressed(true);
//                                holder.clan.setSelected(true);
//                                clanSelector.addUserTopic(z);
//                            }
//                        }
//                    }
                }
//                Log.d("UserClan Adapter", "after earlier topics added  = " + clanSelector.getSelectedTopics());
            }
            else
            {
                //holder.clan.setPressed(true);
                //holder.clan.setSelected(true);
                Log.d("UserClan Adapter", "Inside Else");
                Log.d("UserClan Adapter", "isPressed?" + holder.clan.isPressed());
                Log.d("UserClan Adapter", "isSelected?" + holder.clan.isSelected());
            }
        }

        catch (Exception e)
        {
            e.printStackTrace();
            Crashlytics.logException(e);
        }

        /* changes Button state and add/removes topic id from selected Topics Array */
        holder.clan.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {


                     // show interest in events resulting from ACTION_DOWN
                    if (event.getAction() == MotionEvent.ACTION_DOWN)
                        return true;

                    // don't handle event unless its ACTION_UP so "doSomething()" only runs once.
                    if (event.getAction() != MotionEvent.ACTION_UP)
                        return false;

                if(!selectedTopics){
                    Log.d("UserClansAdapter -->", "clan.isSelected --> " + holder.clan.isSelected());
                    if (holder.clan.isSelected()) {
                        holder.clan.setPressed(false);
                        holder.clan.setSelected(false);
//                        clanSelector.removeUserTopic(position);
                        clanSelector.removeId(mData.get(position).optString("_id"));
                        Log.d("ClanSelectorListC",mData.get(position).toString());
                        Log.d("ClanSelectorListD",clanSelector.getSelectedTopics().toString());
//                        for (int z = 0; z < mData.size(); z++) {
//                            if (mData.get(z).optString("_id").equals(topicId)) {
//                                holder.clan.setPressed(true);
//                                holder.clan.setSelected(true);
//                                clanSelector.removeUserTopic(z);
//                            }
//                        }
                    } else {
                        holder.clan.setPressed(true);
                        holder.clan.setSelected(true);
//                        clanSelector.addUserTopic(position);
                        clanSelector.addId(mData.get(position).optString("_id"));
                        Log.d("ClanSelectorListE",mData.get(position).toString());
                        Log.d("ClanSelectorListF",clanSelector.getSelectedTopics().toString());
//                        for (int z = 0; z < mData.size(); z++) {
//                            if (mData.get(z).optString("_id").equals(topicId)) {
//                                holder.clan.setPressed(true);
//                                holder.clan.setSelected(true);
//                                clanSelector.addUserTopic(z);
//                            }
//                        }
                    }
                }
                else {
                    try {

                        if(mContext instanceof ProfilePage) {
                            UserClans fragment = (UserClans) ((ProfilePage) mContext).getSupportFragmentManager().getFragments().get(1);
                            JSONArray temp = new JSONArray();
                            temp.put(mData.get(position));
                            fragment.communityOnClick(temp);
                        }
                        else
                        {
                            UserClans fragment = (UserClans) ((HomeFeed) mContext).getSupportFragmentManager().findFragmentByTag("homefeed_user_clan");
                            JSONArray temp = new JSONArray();
                            temp.put(mData.get(position));
                            fragment.communityOnClick(temp);
                        }
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                }

                return true;
            }
        });
//        if(!selectedTopics)
//            clanSelector.setPositionAppeared(position);

    }
    @Override
    public int getItemCount() {
        return mData.size();
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public void filterList(List<JSONObject> mDataFiltered){
        this.mData = mDataFiltered;
        notifyDataSetChanged();
    }


    public class UserClansViewHolder extends RecyclerView.ViewHolder {

    Button clan;
    TextView userCount;
    ImageView userCountIcon;
    ConstraintLayout clansCardCL;

    @SuppressLint("ClickableViewAccessibility")
    public UserClansViewHolder(@NonNull View itemView) {
        super(itemView);
        Log.d("UserClansAdapter->", "myViewHolder constructor called");
        clan = itemView.findViewById(R.id.clan_button);
        userCount = itemView.findViewById(R.id.user_count);
        userCountIcon = itemView.findViewById(R.id.user_icon);
        clansCardCL = itemView.findViewById(R.id.clans_card_CL);
        /*
        clan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "I am selected", Toast.LENGTH_SHORT).show();
                //clan.setBackgroundResource(R.drawable.user_clans_button_pressed);


            }
        });
        */

    }
}

}