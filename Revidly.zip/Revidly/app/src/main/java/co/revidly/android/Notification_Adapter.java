package co.revidly.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;


import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Notification_Adapter extends RecyclerView.Adapter<Notification_Adapter.NotificationViewHolder> {
    Context context;
    List<JSONObject> details;
    List<String> isRead;
    private static ClickListener clickListener;

    public Notification_Adapter(Context context, List<JSONObject> details, List<String> isRead){
        this.context = context;
        this.details = details;
        this.isRead=isRead;

    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.list_item,parent,false);
        return new NotificationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NotificationViewHolder holder, int position) {
        Log.d("LOG_MSG","Id:"+details.get(position).optString("_id")+" isRead? "+details.get(position).optString("mark_read"));
        if(details.get(position).optString("mark_read").equals("false") && isRead.get(position).equals("false")){
            Log.d("LOG_DATA","Inside IF: " + " Id:"+details.get(position).optString("_id")+" isRead? "+details.get(position).optString("mark_read"));
            holder.constraintLayout.setBackgroundColor(context.getResources().getColor(R.color.notification_blue));
        }
        else{
            holder.constraintLayout.setBackgroundColor(context.getResources().getColor(R.color.white));

        }
        holder.Title.setText(details.get(position).optString("title"));
        holder.Desc.setText(details.get(position).optString("message"));

        Glide.with(context)
                .asBitmap()
                .load(details.get(position).optString("imageUrl"))
                    .into(holder.profile_photo);
    }

    @Override
    public int getItemCount() {
        return details.size();
    }

    public class NotificationViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener{
        ImageView profile_photo;
        TextView Title,Desc;
        ConstraintLayout constraintLayout;


        public NotificationViewHolder(@NonNull View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            profile_photo = itemView.findViewById(R.id.profile_pic);
            Title = itemView.findViewById(R.id.title);
            Desc = itemView.findViewById(R.id.desc);
            constraintLayout = itemView.findViewById(R.id.cons);
        }

        @Override
        public void onClick(View view) {
            clickListener.onItemClick(getAdapterPosition(), view);
        }
    }
    public void setOnItemClickListener(ClickListener clickListener) {
        Notification_Adapter.clickListener = clickListener;
    }

    public interface ClickListener {
        void onItemClick(int position, View v);
    }

}
