package co.revidly.android;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import android.app.Dialog;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.net.MalformedURLException;
import java.net.URL;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import static android.view.View.GONE;

public class InAppBrowser extends BottomSheetDialogFragment {

    private WebView mWebView;
    private String url;
    private ProgressBar load_progress;
    private BottomSheetBehavior mBehavior;
    private ImageButton close, prev, prev_block, next, next_block, refresh;
    private TextView link;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private LinearLayout WW_LL;

    public static InAppBrowser newInstance(String url){
        InAppBrowser inAppBrowser=new InAppBrowser();
        Bundle args=new Bundle();
        args.putString("URL",url);
        inAppBrowser.setArguments(args);
        return inAppBrowser;
    }

    private void readBundle(Bundle bundle){
        if(bundle!=null)
            url=bundle.getString("URL");
    }
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View view=inflater.inflate(R.layout.activity_in_app_browser,container,false);
//        readBundle(getArguments());
//        setGlobals(view);
//        mWebView.setWebViewClient(new WebViewClient());
//        mWebView.loadUrl(url);
//        return view;
//    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.AppBottomSheetDialogTheme2);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = (BottomSheetDialog) super.onCreateDialog(savedInstanceState);
        View view=View.inflate(getContext(),R.layout.activity_in_app_browser,null);
        readBundle(getArguments());
        setGlobals(view);
        load_progress.setMax(100);
        WebSettings webSettings=mWebView.getSettings();
        mWebView.setMinimumHeight(Resources.getSystem().getDisplayMetrics().heightPixels - 250);
        mWebView.loadUrl(url);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        mWebView.getSettings().setAppCacheEnabled(true);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        mWebView.setInitialScale(1);
        mWebView.getSettings().setSupportZoom(false);
        mWebView.getSettings().setBuiltInZoomControls(false);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        webSettings.setSavePassword(true);
        webSettings.setSaveFormData(true);
        webSettings.setEnableSmoothTransition(true);
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                load_progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                load_progress.setVisibility(GONE);
                mSwipeRefreshLayout.setRefreshing(false);
                URL url_temp=null;
                try {
                    url_temp = new URL(mWebView.getUrl());
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                if(url_temp!=null)
                link.setText(url_temp.getHost());
                if (view.canGoBack()) {
                    prev_block.setVisibility(View.GONE);
                    prev.setVisibility(View.VISIBLE);
                    prev.setEnabled(true);
                } else {
                    prev_block.setVisibility(View.VISIBLE);
                    prev.setVisibility(GONE);
                    prev.setEnabled(false);
                }
                if (view.canGoForward()) {
                    next_block.setVisibility(GONE);
                    next.setVisibility(View.VISIBLE);
                    next.setEnabled(true);
                } else {
                    next_block.setVisibility(View.VISIBLE);
                    next.setVisibility(GONE);
                    next.setEnabled(false);
                }
            }
        });
        mWebView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                load_progress.setProgress(newProgress);
            }
        });
        mWebView.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (i == KeyEvent.KEYCODE_BACK
                        && keyEvent.getAction() == MotionEvent.ACTION_UP
                        && mWebView.canGoBack()) {
                    mWebView.goBack();
                    return true;
                }
                return false;
            }
        });
        dialog.setContentView(view);
        mBehavior = BottomSheetBehavior.from((View) view.getParent());
        mBehavior.isFitToContents();
        mBehavior.setPeekHeight(Resources.getSystem().getDisplayMetrics().heightPixels - 200);
        mBehavior.addBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if(newState==BottomSheetBehavior.STATE_DRAGGING)
                    mBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        mBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        mBehavior.setPeekHeight(Resources.getSystem().getDisplayMetrics().heightPixels - 200);
    }

    private void setGlobals(View view){
        WW_LL = view.findViewById(R.id.WV_LL);
        WW_LL.setPadding(0, 0, 0, 200 - 85);
        mWebView=view.findViewById(R.id.webView);
        load_progress=view.findViewById(R.id.load_prog);
        link=view.findViewById(R.id.link);
        mSwipeRefreshLayout=view.findViewById(R.id.mySwipeLayout);
        mSwipeRefreshLayout.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {
                if(mWebView.getScrollY()==0)
                    mSwipeRefreshLayout.setEnabled(true);
                else
                    mSwipeRefreshLayout.setEnabled(false);
            }
        });
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mWebView.reload();
            }
        });
        close=view.findViewById(R.id.close);
        prev=view.findViewById(R.id.prev);
        prev.setEnabled(false);
        prev_block = view.findViewById(R.id.prev_block);
        prev_block.setEnabled(false);
        next=view.findViewById(R.id.next);
        next.setEnabled(false);
        next_block = view.findViewById(R.id.next_block);
        next_block.setEnabled(false);
        refresh=view.findViewById(R.id.refresh);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (getActivity() != null)
                    getActivity().getSupportFragmentManager().beginTransaction().remove(InAppBrowser.this).commit();
            }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mWebView.canGoBack()) {
                    mWebView.goBack();
                    if (mWebView.canGoBack()) {
                        prev_block.setVisibility(View.GONE);
                        prev.setVisibility(View.VISIBLE);
                        prev.setEnabled(true);
                    } else {
                        prev_block.setVisibility(View.VISIBLE);
                        prev.setVisibility(GONE);
                        prev.setEnabled(false);
                    }
                    if (mWebView.canGoForward()) {
                        next_block.setVisibility(GONE);
                        next.setVisibility(View.VISIBLE);
                        next.setEnabled(true);
                    } else {
                        next_block.setVisibility(View.VISIBLE);
                        next.setVisibility(GONE);
                        next.setEnabled(false);
                    }
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mWebView.canGoForward()) {
                    mWebView.goForward();
                    if (mWebView.canGoBack()) {
                        prev_block.setVisibility(View.GONE);
                        prev.setVisibility(View.VISIBLE);
                        prev.setEnabled(true);
                    } else {
                        prev_block.setVisibility(View.VISIBLE);
                        prev.setVisibility(GONE);
                        prev.setEnabled(false);
                    }
                    if (mWebView.canGoForward()) {
                        next_block.setVisibility(GONE);
                        next.setVisibility(View.VISIBLE);
                        next.setEnabled(true);
                    } else {
                        next_block.setVisibility(View.VISIBLE);
                        next.setVisibility(GONE);
                        next.setEnabled(false);
                    }
                }
            }
        });
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mWebView.reload();
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        if (getActivity() != null)
            getActivity().getSupportFragmentManager().beginTransaction().remove(InAppBrowser.this).commit();
    }

    @Override
    public void onStop() {
        mSwipeRefreshLayout.removeAllViews();
        super.onStop();
    }
}
