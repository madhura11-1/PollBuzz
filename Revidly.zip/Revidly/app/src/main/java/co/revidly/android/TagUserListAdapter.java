package co.revidly.android;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TagUserListAdapter extends RecyclerView.Adapter<TagUserListAdapter.TagUserViewHolder> {
    ArrayList<FollowerList> tagUserLists;
    Context context;
    AdapterCallBack adapterCallBack;
    public TagUserListAdapter(ArrayList<FollowerList> tagUserLists, Context context, AdapterCallBack adapterCallBack){
        this.context = context;
        this.tagUserLists = tagUserLists;
        this.adapterCallBack=adapterCallBack;
    }

    @NonNull
    @Override
    public TagUserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater =LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.tag_user_list_item,parent,false);
        return new TagUserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final TagUserViewHolder holder, final int position) {
        String followerName = tagUserLists.get(position).getName();
        holder.follower_name.setText(followerName);
        String followerAvatar = tagUserLists.get(position).getImg();
        Log.d("FollowerListAdapter", "onBindViewHolder: " + tagUserLists.size());
        if(!followerAvatar.equals("null")){
            Glide.with(context)
                    .load(followerAvatar)
                    .apply(new RequestOptions().centerCrop().fitCenter())
                    .into(holder.follower_img);
        }
        holder.ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adapterCallBack.onItemClicked(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return tagUserLists.size();
    }

    public class TagUserViewHolder extends RecyclerView.ViewHolder {
        ImageView follower_img;
        TextView follower_name;
        LinearLayout ll;
        public TagUserViewHolder(@NonNull View itemView) {
            super(itemView);
            follower_img = itemView.findViewById(R.id.follower_img);
            follower_name = itemView.findViewById(R.id.follower_name);
            ll=itemView.findViewById(R.id.ll);
        }
    }
    public interface AdapterCallBack{
        void onItemClicked(int position);
    }
}

