package co.revidly.android;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;

public class NotificationActivity extends AppCompatActivity {

    ArrayList<Notification_info> notification_info;
    ShimmerRecyclerView recyclerView;
    JSONObject data;
    List<JSONObject> mlist;
    List<String> isClicked;
    Notification_Adapter adapter;
    String notifId;
    ProgressBar pBar;
    String auth_token;
    int pageNo = 1, code = 1;
    SwipeRefreshLayout swipeRefreshLayout;
    BottomNavigationView bottomNavigationView;
    FirebaseAnalytics mFirebaseAnalytics;
    AppBarLayout appBarLayout;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_view);
        auth_token = null;
        auth_token = Utils.getAuthToken(this);
        if (auth_token == null) {
            startActivity(new Intent(this, HomeScreen_Activity.class));
            finish();
        }
        pBar = findViewById(R.id.pBar);
        appBarLayout=findViewById(R.id.profile_app_bar);
        bottomNavigationView=findViewById(R.id.bottom_navigation);
        notification_info = new ArrayList<>();
        recyclerView = findViewById(R.id.rc);
        swipeRefreshLayout = findViewById(R.id.simpleSwipeRefreshLayout);
        setRecyclerView();
        mFirebaseAnalytics=FirebaseAnalytics.getInstance(this);
        mlist = new ArrayList<>();
        isClicked=new ArrayList<>();
        BottomNavigationBar();
        getData();
        setSwipeRefresh();
    }

    private void setSwipeRefresh()
    {
        // init SwipeRefreshLayout and TextView

        // implement setOnRefreshListener event on SwipeRefreshLayout
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                if(recyclerView.getVisibility() == View.VISIBLE)
                {
                    // implement Handler to wait for 3 seconds and then update UI means update value of TextView
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            // cancel the Visual indication of a refresh
                            swipeRefreshLayout.setRefreshing(false);
                            // Generate a random integer number
                            getData();

                        }
                    }, 1000);
                }
                else
                {
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }


    private void getData() {
        Log.d("LOG_MSG", "PageNO: " + pageNo);
        String url = BASE_URL + "/api/pushnotif/getNotifs/" + pageNo;

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Authorization", LoggedInUser.auth_token_global)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("LOG_MSG", e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                try {
                    data = new JSONObject();
                    String resp = response.body().string();
                    JSONObject resultObject = new JSONObject(resp);
                    Log.d("LOG_MSG", "Result: " + resultObject);
                    JSONArray notifs = resultObject.optJSONArray("notifs");
                    if (notifs != null) {
                        if (!(notifs.length() == 0)) {
                            for (int i = 0; i < notifs.length(); i++) {
                                JSONObject temp = notifs.getJSONObject(i);
                                Log.d("LOG_MSG", temp.optString("message"));
                                Log.d("LOG_MSGS", temp.optString("kind"));
                                mlist.add(temp);
                                isClicked.add(temp.optString("mark_read"));
                            }
                            Log.d("LOG_MSG", "Size: " + mlist.size());
                            Log.d("LOG_MSG", "INSIDE IF");
                            pageNo++;
                            //                        getData();
                        } else {
                            Log.d("LOG_MSG", "INSIDE ELSE");
                        }
                    }

//                    if (pageNo == 2) {
//                        setRecyclerView();
//                    }
//                    else{
                    Handler mainHandler;
                    mainHandler = new Handler(getApplicationContext().getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                            if (pageNo == 2)
                                recyclerView.hideShimmerAdapter();
                            else
                                pBar.setVisibility(View.GONE);
                        }
                    });
//                    }


                } catch (Exception e) {
                    Log.e("LOG_MSG", e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }

    void setRecyclerView() {
        Handler mainHandler;
        mainHandler = new Handler(getApplicationContext().getMainLooper());
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                adapter = new Notification_Adapter(getApplicationContext(), mlist,isClicked);
                recyclerView.setAdapter(adapter);
                recyclerView.showShimmerAdapter();
                recyclerView.setHasFixedSize(true);
                final LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                    @Override
                    public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                        super.onScrollStateChanged(recyclerView, newState);
                    }

                    @Override
                    public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                        super.onScrolled(recyclerView, dx, dy);
                        Log.d("SizeSize", String.valueOf(layoutManager.findLastVisibleItemPosition()));
                        if (layoutManager.findLastVisibleItemPosition() == mlist.size() - 1) {
                            Log.d("SizeSize", String.valueOf(mlist.size()));
                            getData();
                            pBar.setVisibility(View.VISIBLE);
                        }
                    }
                });
                adapter.setOnItemClickListener(new Notification_Adapter.ClickListener() {
                    @Override
                    public void onItemClick(int position, View v) {
                        Log.d("LOG_MSG", "Position: " + position);
                        notifId = mlist.get(position).optString("_id");
                        Log.d("LOG_MSG", "NotifID: " + notifId);
                        isClicked.set(position,"true");
                        adapter.notifyItemChanged(position);
                        markAsRead();
                        Log.d("LOG_MSG", "CLICKED: " + position);
                        if (mlist.get(position).optString("kind").equals("new_follower")) {
                            Intent intent = new Intent(getApplicationContext(), ProfilePage.class);
                            intent.putExtra("USER_ID", mlist.get(position).optString("entityId"));
                            startActivity(intent);
                        } else if(mlist.get(position).optString("kind").equals("comment_recieved")){
                            Intent intent = new Intent(getApplicationContext(), DescribedPostsActivity.class);
                            intent.putExtra("postID", mlist.get(position).optString("entityId"));
                            intent.putExtra("Comment_Notif","Comment_Notif");
                            startActivity(intent);
                        }
                        else{
                            Intent intent = new Intent(getApplicationContext(), DescribedPostsActivity.class);
                            intent.putExtra("postID", mlist.get(position).optString("entityId"));
                            startActivity(intent);
                        }
                    }
                });
            }
        });


    }
    private void BottomNavigationBar() {
        bottomNavigationView.getMenu().findItem(R.id.action_notif).setChecked(true);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_new_home:
                        bottomNavigationView.getMenu().findItem(R.id.action_new_home).setChecked(true);
                        Intent intent = new Intent(NotificationActivity.this, newHomeFeed.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        break;
                    case R.id.action_home:
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
                        Intent intent1 = new Intent(NotificationActivity.this, HomeFeed.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivityForResult(intent1,0);
                        break;
                    case R.id.action_post:
                        startActivity(new Intent(getApplicationContext(), Add_Answer.class));
                        bottomNavigationView.getMenu().findItem(R.id.action_post).setCheckable(false);
                        break;
                    case R.id.action_notif:
                        break;
                    case R.id.action_profile:
                        //bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        Intent intent2 = new Intent(getApplicationContext(), ProfilePage.class);
                        intent2.putExtra("USER_ID", LoggedInUser.userId);
                        startActivityForResult(intent2, 0);

                        break;

                }
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        BottomNavigationBar();
        if (LoggedInUser.updateClans) {
            LoggedInUser.updateClans = false;
            setUserTopics();
        }
    }
    public void setUserTopics() {
        new Handler().post(new Runnable() {
            public void run() {
                // Begin the transaction
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                // Replace the contents of the container with the new fragment
                ft.replace(R.id.user_clans_fragment_manager, UserClans.newInstance1(auth_token));
                // or ft.add(R.id.your_placeholder, new FooFragment());
                // Complete the changes added above
                ft.commit();
            }
        });
        hideViews();
    }

    private void hideViews() {
        Log.d("HomeFeed", "hideView() I am running");
        recyclerView.setVisibility(View.GONE);
        pBar.setVisibility(View.GONE);
        bottomNavigationView.setVisibility(View.GONE);
        swipeRefreshLayout.setVisibility(View.GONE);
        bottomNavigationView.setVisibility(View.GONE);
        appBarLayout.setVisibility(View.GONE);
        //fragmentUserClans.setVisibility(View.GONE);
    }

    private void markAsRead() {
        String url = BASE_URL + "/api/pushnotif/markRead/" + notifId;
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Authorization", LoggedInUser.auth_token_global)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("LOG_MSG", e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                try {
                    String resp = response.body().string();
                    Log.d("LOG_MSG", "Marked: " + resp);
                } catch (Exception e) {
                    Log.e("LOG_MSF", e.getMessage());
                    e.printStackTrace();
                }

            }
        });
    }
}
