package co.revidly.android;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ClanArrayAdapter extends ArrayAdapter<String> {

    Context context;
    int resource;
    CheckBox checkBox;
    ArrayList<String> topicName;
    ArrayList<String> objects;


    public ClanArrayAdapter(@NonNull Context context, int resource, @NonNull ArrayList<String> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects =objects;
        topicName = new ArrayList<>();
    }


    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(resource,parent,false);
        checkBox = convertView.findViewById(R.id.checkTopic);
        checkBox.setText(objects.get(position));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Log.d("LOG_DATA", "Selected" + objects.get(position));
                Log.d("LOG_DATA", "Selected" + compoundButton.getText().toString());
                if(topicName.contains(objects.get(position))){
                    topicName.remove(objects.get(position));
                    Log.d("LOG_DATA",objects.get(position) + " removed");
                }
                else{
                    topicName.add(objects.get(position));
                    Log.d("LOG_DATA",objects.get(position) + " added");
                }

            }
        });




        return convertView;

    }

    public ArrayList<String> getSelectedTopics(){
        return topicName;
    }

}
