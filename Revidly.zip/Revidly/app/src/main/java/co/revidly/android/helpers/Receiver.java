package co.revidly.android.helpers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class Receiver extends BroadcastReceiver {
    static public String code="";
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent!=null && intent.getAction().equals("com.android.vending.INSTALL_REFERRER")) {
//            String referrer = "";
            Bundle extras = intent.getExtras();
            if (extras != null) {
//                referrer = extras.getString("referrer");
                code = extras.getString("referrer");
               }
//            Log.d("Referral", "Referral Code Is: " + referrer);
//            code=referrer.substring(referrer.indexOf("referrer=")+9);
            Log.d("Referral Code is:", code);
        }
    }
}
