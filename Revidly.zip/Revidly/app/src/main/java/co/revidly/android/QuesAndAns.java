package co.revidly.android;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.jaeger.library.StatusBarUtil;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;
import static java.lang.Math.abs;

import uk.co.deanwild.materialshowcaseview.MaterialShowcaseSequence;
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseView;
import uk.co.deanwild.materialshowcaseview.ShowcaseConfig;

public class QuesAndAns extends FullscreenActivity {

    static int fvi;
    List<JSONObject> mlist;
    Adapter adapter;
    AddAnswer addAnswer;
    inviteSheet invitesheet;
    public static boolean inqanda=false;
    public static JSONObject[] quanswers;
    private ShimmerFrameLayout mShimmerFrameLayout;
    private FirebaseAnalytics mFirebaseAnalytics;

    private static final String SHOWCASE_ID_QnA = "Simple Showcase Question and Answer Page";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("function call QandA", "inside onCreate");
        //StatusBarUtil.setTransparent(this);
        setContentView(R.layout.qanda);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        StatusBarUtil.setColor(this, Color.LTGRAY, 2);
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        ConstraintLayout flo = findViewById(R.id.constraintLayout);
        flo.setPadding(0, result, 0, 0);
        mlist = new ArrayList<>();
        Log.e("Response call 1","Nothing");
        getans(qa_ques_id);
        Log.e("Response call 2","Nothing");
        final BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        mShimmerFrameLayout=(ShimmerFrameLayout)findViewById(R.id.shimmer_qanda);
        /*
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                View view = findViewById(R.id.constraintLayout);
                switch (item.getItemId()) {
                    case R.id.action_home:
                        finish();
                        break;
                    case R.id.action_discover:
                        finish();
                        Intent discover = new Intent(view.getContext(), searchView.class);
                        startActivityForResult(discover, 0);
                        break;
                    case R.id.action_answer:
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(false);
                        finish();
                        Intent myIntent = new Intent(view.getContext(), quesandansreq.class);
                        startActivityForResult(myIntent, 0);
                        break;
                    case R.id.action_ask_ques:
                        qaup=true;
                        finish();
                        //fragment.show(getSupportFragmentManager(), "TAG");
                        break;
                    case R.id.action_profile:
                        bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(false);
                        finish();
                        prof=true;
                        Intent profile = new Intent(view.getContext(), quesandansreq.class);
                        startActivityForResult(profile, 0);
                        break;

                }
                return true;
            }
        });

         */
        ItemTouchHelper.SimpleCallback simpleCallback= new ItemTouchHelper.SimpleCallback(ItemTouchHelper.LEFT,ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                if(direction==ItemTouchHelper.LEFT)
                finish();
            }

            @Override
            public float getSwipeThreshold(@NonNull RecyclerView.ViewHolder viewHolder) {
                return 0.3f;
            }

            @Override
            public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {

            }
        };
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);


        main=false;
        TextView question = findViewById(R.id.textView7);
        findViewById(R.id.nullanswers).setVisibility(View.INVISIBLE);
        question.setText(qaquestion);
        final RecyclerView recyclerView = findViewById(R.id.recvw);
        Button answer=findViewById(R.id.qandaanswerbtn);
        Button invite = findViewById(R.id.qandainvite);


        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uplque_id=qa_ques_id;
                uplquestion=qaquestion;
                inqanda=true;
                addAnswer= new AddAnswer();
                addAnswer.show(getSupportFragmentManager(),"Answer");

                mShimmerFrameLayout.stopShimmer();
                mShimmerFrameLayout.setVisibility(View.GONE);


                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"addAnswer");
                mFirebaseAnalytics.logEvent("addAnswerClicked",bundle);
            }
        });
        invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                invite_ques_id = qa_ques_id;
                invitesheet = new inviteSheet();
                invitesheet.show(getSupportFragmentManager(), "Invite");

                mShimmerFrameLayout.stopShimmer();
                mShimmerFrameLayout.setVisibility(View.GONE);

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"invite");
                mFirebaseAnalytics.logEvent("inviteClicked",bundle);
            }
        });


        /*for(int i=0;i<qdata.ans.size();i++){
            mlist.add(new answers(i,qdata.propic.get(i),qdata.username.get(i),qdata.lang.get(i),qdata.ans.get(i),qdata.upvotes.get(i),qdata.downvotes.get(i),qdata.comments.get(i),qdata.shares.get(i)));
        }*/

        adapter = new Adapter(this,mlist, null);
        adapter.setHasStableIds(true);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        final LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        itemTouchHelper.attachToRecyclerView(recyclerView);
        recyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                fvi=layoutManager.findFirstCompletelyVisibleItemPosition();
                if(fvi==RecyclerView.NO_POSITION) fvi=layoutManager.findFirstVisibleItemPosition();

            }
        });
        //App ShowCase Tutorial Starts Here

            showTutorSequenceQuesAndAns(500);
    }

    private void showTutorSequenceQuesAndAns(int millis) {

        Log.d("showtutor", "In showTutorSequence function");
        ShowcaseConfig config = new ShowcaseConfig(); //create the showcase config
        config.setDelay(millis); //set the delay of each sequence using millis variable

        MaterialShowcaseSequence sequence = new MaterialShowcaseSequence(this, SHOWCASE_ID_QnA); // create the material showcase sequence

        sequence.setConfig(config); //set the showcase config to the sequence.

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.textView7))
                        .setTitleText("Question asked by user")
                        .setDismissText("Click Here : Next")
                        //.setDismissOnTargetTouch(false)
                        //.setContentText("Click on Next")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withRectangleShape(true)
                        .build()
        );

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.nullanswers))
                        .setTitleText("\nList of video answers")
                        .setDismissText("Click Here : Next")
                        //.setContentText("This video is uploaded by another user in response to the Question")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape(true)
                        //.withoutShape()
                        .setShapePadding(-300)
                        .build()
        ); // add view for the second sequence, in this case it is a textview.
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.qandaanswerbtn))
                        .setTitleText("Upload your Video Opinion from here")
                        .setDismissText("Click Here : Next")
                        //.setDismissOnTargetTouch(false)
                        .setContentText("")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape()
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.qandainvite))
                        .setTitleText("Want to ask others for an answer?")
                        .setDismissText("Click Here : End Tutorial")
                        //.setDismissOnTargetTouch(false)
                        .setContentText("Ask from here")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape(true)
                        .build()
        );

        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.propic))
                        .setTitleText("Profile Picture")
                        .setDismissText("Click Here : Next")
                        //.setContentText("The DP of the person who has uploaded the Video")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        ); // add view for the third sequence, in this case it is a checkbox.
         */
        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.upvote))
                        .setTitleText("UpVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Like the video? UpVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.downvote))
                        .setTitleText("DownVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Did not like the video? DownVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.comment))
                        .setTitleText("Comment on the Video")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Provide your views by commenting on the video")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.share))
                        .setTitleText("Share this video with your Friends")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Share this video with your friends.")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_home))
                        .setTitleText("Home Feed")
                        .setDismissText("Click Here : Next")
                        .setContentText("See videos uploaded by users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_discover))
                        .setTitleText("Search for Questions")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Search for questions asked by other users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_answer))
                        .setTitleText("Questions Tabs")
                        .setDismissText("Click Here : Next")
                        .setContentText("More Questions for you to browse")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_ask_ques))
                        .setTitleText("Want to ask a Question?")
                        .setDismissText("Click Here : Next")
                        .setContentText("Ask it from here")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Scroll Down")
                        .setDismissText("Click Here : Next")
                        .setContentText("Scroll down for more videos on questions")
                        //.withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Swipe Right for list of videos")
                        .setDismissText("Click Here : End Tutorial & Swipe Right")
                        //.setContentText("Swipe right for list of videos for the same question")
                        //.withCircleShape()
                        //.setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );
        */
        sequence.start(); //start the sequence showcase
        Log.d("showtutor", "at end of ShowTutor Function");
    }

    void call(int ans_no){
        Log.d("Inside QuesAndAns ", "Inside Call before finish");
        changed=true;
        ques=qaquestion;
        //qno=sqno;
        ano=ans_no;
        //nextQue();
        finish();
        Log.d("Inside QuesAndAns ", "Inside Call after finish");
    }
    void propicClick(int ans_no) throws JSONException {
        Toast.makeText(QuesAndAns.this,"Profile of "+quanswers[ans_no].getString("ans_auth_id"),Toast.LENGTH_SHORT).show();
    }
    void followClick(int ans_no) throws JSONException {
        Toast.makeText(QuesAndAns.this,"Followed "+quanswers[ans_no].getString("ans_auth_id"),Toast.LENGTH_SHORT).show();
    }
    void upvoteClick(int ans_no){
        Toast.makeText(QuesAndAns.this,"Upvoted",Toast.LENGTH_SHORT).show();
    }
    void commentclick(String ans_no){
        commans_id=ans_no;
        commentfragment = new CommentSheet();
        commentfragment.show(getSupportFragmentManager(),"Comments");
    }
    void shareOnClick(String ans_id){

        /*
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        //Use the below line to share revidly link with ans id
        //String shareBody = "http://revidly.co/share/" + tans_id;
        //Currently Sending it to Google Play Store to download app
        String shareBody = "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +  "&hl=en";
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));

         */
        Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        //Use the below line to share revidly link with ans id

        //String shareBody = "http://revidly.co/share?"+"qid="+tques_id+"&"+"aid="+ans_id;
        String shareBody = "http://revidly.co/share?"+"aid="+ans_id;

        //Currently Sending it to Google Play Store to download app
        //String shareBody = "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID +  "&hl=en";

        //sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
        sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
        startActivity(Intent.createChooser(sharingIntent, "Share via"));
    }

    public boolean onTouchEvent(MotionEvent touchEvent) {
        switch (touchEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2 = touchEvent.getX();
                y2 = touchEvent.getY();
                if (x1>x2 && abs(x1-x2)>200 && (abs(x1 - x2) > abs(y1 - y2))){
                    finish();
                }

                break;
        }
        return false;
    }

    @Override
    public void finish() {
        super.finish();
        //youTubePlayerView.release();
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
    }


    void getans(String ques_id){
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "ques_id="+ques_id);

        String url = BASE_URL + "/api/app/getallans";
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Authorization", auth_token)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("cache-control", "no-cache")
                .addHeader("Postman-Token", "558388c3-9fac-4dea-876e-e746984ac4fa")
                .build();

        Call call = client.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                System.out.println(e.getStackTrace().toString());
                Log.i("Failed : ", e.getStackTrace().toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    throw new IOException("Unexpected code " + response);
                } else {
                    final String resp = response.body().string();
                    mlist.clear();
                    try {
                        JSONArray result = new JSONArray(resp);
                        quanswers = new JSONObject[result.length()];
                        for (int i = 0; i < result.length(); i++) {
                            final JSONObject obj = new JSONObject(result.get(i).toString());
                            quanswers[i] = new JSONObject(result.get(i).toString());
                            mlist.add(obj);
                            Log.i("Question id "+i,obj.getString("ques_id"));
                            Log.i("Answer Id",obj.getString("_id"));
                            Log.i("Answer Description",obj.getString("ans_desc"));
                            Log.i("Answer URL",obj.getString("ans_url"));
                            Log.i("Answer Auth id",obj.getString("ans_auth_id"));
                            Log.i("Question Auth id",obj.getString("ques_auth_id"));

                        }
                        Handler mainHandler;
                        mainHandler = new Handler(QuesAndAns.this.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                                mShimmerFrameLayout.stopShimmer();
                                mShimmerFrameLayout.setVisibility(View.GONE);
                                adapter.notifyDataSetChanged();
                                findViewById(R.id.nullanswers).setVisibility(View.GONE);
                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                        Handler mainHandler;
                        mainHandler = new Handler(QuesAndAns.this.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (resp.equals("NO ANSWERS"))
                                    mShimmerFrameLayout.stopShimmer();
                                    mShimmerFrameLayout.setVisibility(View.GONE);
                                    findViewById(R.id.nullanswers).setVisibility(View.VISIBLE);
                            }
                        });
                    }
                    Log.i("Response:", response.toString());
                    Log.i("Response body:", response.body().toString());
                    Log.i("Response String: ", resp);
                    Log.i("Response message:", response.message());
                    response.body().close();
                }
            }
        });
    }
}

