package co.revidly.android;

import com.crashlytics.android.Crashlytics;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import java.io.IOException;
import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;


/**
 * Created by User on 2/28/2017.
 */

public class QuesNAnsProfile extends Fragment
{
    GridView gridView;
    ArrayList<String> ans_url;

    private static final String TAG = "OnCreate:ProfilePage";
    private String get_all_ques_url = BASE_URL + "/api/app/getallques";
    private static String auth_token,name;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_ques_n_ans_profile,container,false);
        gridView =  view.findViewById(R.id.gridView);
        auth_token = Utils.getAuthToken(getActivity());
        ans_url = new ArrayList();
        getAnsUrl();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG,"DEMO" + ans_url.size());
                    setupImageGrid();
                }
                catch (Exception e) {
                    Crashlytics.logException(e);
                }
            }
        },3000);


        return view;
    }


    private void setupImageGrid()
    {
        GridViewHelper adapter = new GridViewHelper(getContext(), R.layout.layout_gridview, "", ans_url);
        gridView.setAdapter(adapter);
    }

    private void getAnsUrl(){
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(get_all_ques_url)
                .get()
                .addHeader("Authorization", auth_token)
                .addHeader("User-Agent", "PostmanRuntime/7.20.1")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "4fcbb8f8-632b-4d2b-b918-b0981a54d71d,f5c9ab34-a74b-42e8-80ab-817a46b3f0ff")
                .addHeader("Host", "dev-api.revidly.co")
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e(TAG,e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.isSuccessful()){
                    try {
                        String resp = response.body().string();
                        Log.d(TAG,"Response: "+response);
                        Log.d(TAG,"Response String: "+ resp);
                        JSONArray jsonArray = new JSONArray(resp);
                        Log.d(TAG, "jsonArrayLength: "+jsonArray.length());
                        for(int i = 0;i<jsonArray.length();i++) {
                            JSONObject obj = jsonArray.getJSONObject(i);
                            Log.d(TAG,"ANSWER_URL: "+ obj.getString("ans_url"));
                            ans_url.add(obj.getString("ans_url"));

                        }
                        response.body().close();
                    }
                    catch (Exception e) {
                        Log.e(TAG,"JSONError: "+e.getMessage());
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                }
                else {
                    Log.e("Response ",response.toString());
                    throw new IOException("Unexpected code " + response);
                }
            }
        });
    }

//    private void getuserID(){
//        OkHttpClient client = new OkHttpClient().newBuilder()
//                .build();
//        Request request = new Request.Builder()
//                .url("https://dev-api.revidly.co/api/user/me")
//                .method("GET", null)
//                .addHeader("Content-Type", "application/x-www-form-urlencoded")
//                .addHeader("Authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZGVlNjA5NjJmYzFiMzJhNzg1ODJiN2YiLCJuYW1lIjoia2FydGlrIiwicGhvbmUiOm51bGwsImVtYWlsIjoidGVzdDEyQGdtYWlsLmNvbSIsInBlcm1pc3Npb25zIjpbXSwiaWF0IjoxNTc4MDczODQ0LCJleHAiOjE1Nzg2Nzg2NDR9.zkwOnhDceZqVgAu0C1rEfXzS0JHkpMxd1WQBJ5yJc88")
//                .build();
//
//        Call call = client.newCall(request);
//        call.enqueue(new Callback() {
//            @Override
//            public void onFailure(@NotNull Call call, @NotNull IOException e) {
//                Log.e(TAG,e.getMessage());
//                e.printStackTrace();
//            }
//
//            @Override
//            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
//                if(response.isSuccessful()){
//                    try {
//                        String resp = response.body().toString();
//                        Log.d("IDD","ID response" + resp);
//                        JSONArray jsonArray = new JSONArray(resp);
//                        for(int i=0; i<=jsonArray.length();i++){
//                            JSONObject jsonObject = jsonArray.getJSONObject(i);
//                            Log.d("IDD", "ID: " + jsonObject.getString("_id"));
//                            name = jsonObject.getString("_id");
//                        }
//                        response.body().close();
//                    }
//
//                    catch (Exception e){
//                        Log.e("ERROR",e.getMessage());
//                        e.printStackTrace();
//                    }
//                }
//            }
//        });
//
//    }
}