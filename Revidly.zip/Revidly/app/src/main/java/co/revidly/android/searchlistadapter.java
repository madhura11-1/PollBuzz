package co.revidly.android;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.crashlytics.android.Crashlytics;
import com.google.firebase.analytics.FirebaseAnalytics;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;
import static co.revidly.android.helpers.Config.BASE_HOST;

public class searchlistadapter extends RecyclerView.Adapter<searchlistadapter.MyViewHolder> implements Filterable {
    Context mContext;
    List<JSONObject> mData;
    List<JSONObject> mDataFull;
    View mView;
    boolean c=false;
    FirebaseAnalytics mFirebaseAnalytics;
    private Filter myFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            final List<JSONObject> filteredList = new ArrayList<>();

            if(constraint==null || constraint.length() == 0){
                filteredList.addAll(mDataFull);
            }else{
                String filterPattern = constraint.toString().toLowerCase().trim();

                /*for(questions item : mDataFull){
                    if(item.answers.toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }
                    else if(item.question.toLowerCase().contains(filterPattern)){
                        questions it = new questions();
                        it.question=item.question;
                        it.answers="";
                        it.ansname="";
                        filteredList.add(it);
                    }
                }*/
                OkHttpClient client = new OkHttpClient();
                String url = BASE_URL + "/api/app/getQuesByText?text=" + filterPattern;
                try{
                Request request = new Request.Builder()
                        .url(url)
                        .get()
                        .addHeader("Authorization", FullscreenActivity.auth_token)
                        .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                        .addHeader("Accept", "*/*")
                        .addHeader("Cache-Control", "no-cache")
                        .addHeader("Postman-Token", "a7f73585-77d4-48ea-959c-2028d773ecfe,89d9427c-320c-4de7-8a67-c2c09fad3597")
                        .addHeader("Host", BASE_HOST)
                        .addHeader("Accept-Encoding", "gzip, deflate")
                        .addHeader("Connection", "keep-alive")
                        .addHeader("cache-control", "no-cache")
                        .build();
                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        System.out.println(e.getStackTrace().toString());
                        Log.i("Failed : ", e.getStackTrace().toString());
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        System.out.println("Success : " + response.body().toString());
                        if (!response.isSuccessful()) {
                            // You can also throw your own custom exception
                            throw new IOException("Unexpected code " + response);
                        } else {
                            String resp = response.body().string();
                            Log.i("Output of questions ",resp);
                            try {
                                JSONArray result = new JSONArray(resp);
                                for (int i = 0; i < result.length(); i++) {
                                    final JSONObject obj = new JSONObject(result.get(i).toString());
                                    Handler mainHandler;
                                    try {
                                        mainHandler = new Handler(mContext.getMainLooper());
                                        mainHandler.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                filteredList.add(obj);
                                                FilterResults results = new FilterResults();
                                                results.values = filteredList;
                                                mData.clear();mData.addAll((List)results.values);
                                            }
                                        });
                                    }catch (NullPointerException e){Log.i("Null exception",e.getStackTrace().toString());
                                        Crashlytics.logException(e);
                                    }
                                    //Log.i("Response ",response.toString());
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Crashlytics.logException(e);
                            }
                            /*
                            FilterResults results = new FilterResults();
                            results.values = filteredList;
                            mData.clear();mData.addAll((List)results.values);
                            */
                            Handler mainHandler;
                            mainHandler = new Handler(mContext.getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    notifyDataSetChanged();
                                }
                            });
                            response.body().close();
                        }
                    }
                });
            }catch (Exception e){Log.i("Error ",e.getStackTrace().toString());
                    Crashlytics.logException(e);
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            //mData.clear();
            //mData.addAll((List)results.values);
            //notifyDataSetChanged();
        }
    };


    public searchlistadapter(Context mContext, List<JSONObject> mData) {
        this.mContext = mContext;
        this.mData = mData;
        mDataFull = new ArrayList<>(mData);
        //mData.clear();
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(mContext);
    }

    @NonNull
    @Override
    public searchlistadapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View vw = inflater.inflate(R.layout.search_list_item, parent, false);
        mView = vw;
        return new searchlistadapter.MyViewHolder(vw);
    }

    @Override
    public void onBindViewHolder(@NonNull final searchlistadapter.MyViewHolder holder, final int position) {
        holder.question.setText(mData.get(position).optString("title"));
        holder.user.setText(mData.get(position).optString("name"));
        //holder.answer.setText(mData.get(position).optString("description"));
        if (mData.get(position).optJSONArray("answered").length() == 0)
            holder.answer.setText("No answer yet ");
        else if (mData.get(position).optJSONArray("answered").length() == 1)
            holder.answer.setText("1 Answer ");
        else
            holder.answer.setText(String.format("%d Answers", mData.get(position).optJSONArray("answered").length()));
        /*
        if (mData.get(position).optString("answered") == "") {
            holder.user.setVisibility(View.GONE);
            holder.answer.setVisibility(View.GONE);
        } else {
            holder.user.setVisibility(View.VISIBLE);
            holder.answer.setVisibility(View.VISIBLE);
        }
         */
        holder.question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((searchView) mContext).queClk(mData.get(position).optString("_id"), mData.get(position).optString("title"));
            }
        });
        holder.ansbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] PERMISSIONS = {android.Manifest.permission.WRITE_EXTERNAL_STORAGE};
                for (String permission : PERMISSIONS) {
                    if (ActivityCompat.checkSelfPermission(mContext, permission) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions((Activity) mContext, PERMISSIONS, 0);
                    }
                }

                //////////////////////////((searchView) mContext).qu= mData.get(position).quesno;
                FullscreenActivity.uplquestion = mData.get(position).optString("title");
                FullscreenActivity.uplque_id = mData.get(position).optString("_id");

                ((searchView) mContext).addAnswer.show(((searchView) mContext).getSupportFragmentManager(), "Ans");
            }
        });
    }


    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    private void removeItem(int position) {
        mData.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mData.size());
    }

    @Override
    public Filter getFilter() {
        return myFilter;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView user, question, answer;
        Button ansbutton;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            question = itemView.findViewById(R.id.searchques);
            user = itemView.findViewById(R.id.searchuser);
            answer = itemView.findViewById(R.id.searchanswer);
            ansbutton = itemView.findViewById(R.id.searchanswerbtn);
        }
    }
}
