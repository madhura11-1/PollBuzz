package co.revidly.android.ui;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import com.crashlytics.android.Crashlytics;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.SyncStateContract;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Arrays;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import co.revidly.android.HomeFeed;
import co.revidly.android.R;
import co.revidly.android.ReferCatcher;
import co.revidly.android.helpers.InternetConnector_Checker;
import co.revidly.android.helpers.Receiver;
import io.fabric.sdk.android.Fabric;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

public class HomeScreen_Activity extends AppCompatActivity {

    TextView textView;
    Button Login_txt, signup_txt;

    CallbackManager callbackManager;
    private final BroadcastReceiver referCatcher = new ReferCatcher();

    private static final String EMAIL = "email";

    LoginButton loginButton;

    int RC_SIGN_IN = 1;

    private int LOGIN_TYPE_FACEBOOK = 100;
    private int LOGIN_TYPE_GOOGLE = 101;

    ProgressDialog dialog;

    private static HomeScreen_Activity mInstance;
    private final BroadcastReceiver internetConnector = new InternetConnector_Checker();
    private boolean checkOnPause = false;
    private String auth_token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("HomeActivity", "onCreate Called");
        Fabric.with(this, new Crashlytics());
        mInstance = this;

        SharedPreferences getPrefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());

        checkOnPause = false;
        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        this.registerReceiver(internetConnector, intentFilter);
        IntentFilter intentFilter1 = new IntentFilter("com.android.vending.INSTALL_REFERRER");
        this.registerReceiver(referCatcher, intentFilter1);
        Log.d("LOG_DATA", "Registered referCatcher");


        //if user is logged in
        if (Utils.getAuthToken(this) != null) {
            //startActivity(new Intent(this, FullscreenActivity.class));
            Intent i = new Intent(this, HomeFeed.class);
//            i.putExtra("newHomeFeed", true);
            Log.d("NewHomeFeed","HomeScreen1st");
            startActivity(i);
            //overridePendingTransition(R.anim.slide_out_left, R.anim.slide_in_right);
            Log.d("HomeActivity", "FullscreenActivity being called");
            finish();
        } else {
            //  Create a new boolean and preference and set it to true
            boolean isFirstStart = getPrefs.getBoolean("firstStart", true);
            Log.d("HomeActivity", "FullscreenActivity not being called");

            //  If the activity has never started before...
            if (isFirstStart) {
                /*
                //  Launch app intro
                final Intent i = new Intent(this, IntroActivity.class);

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(i);
                    }
                });
                */

                //  Make a new preferences editor
                SharedPreferences.Editor e = getPrefs.edit();

                //  Edit preference to make it false because we don't want this to run again
                e.putBoolean("firstStart", false);

                //  Apply changes
                e.apply();
            }

            setContentView(R.layout.activity_home_screen);

            SetID();

            TermsofService();

            SignInButton sign_in_button = findViewById(R.id.sign_in_button);
            sign_in_button.setSize(SignInButton.SIZE_WIDE);
            sign_in_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onGoogleLoginClicked();
                }
            });
            setupFacebookLogin();
        }
    }

    private void SetID() {
        Log.d("HomeActivity", "SetID Called");
        textView = findViewById(R.id.terms_of_use_textView);
//        Login_txt = findViewById(R.id.login);
//        signup_txt = findViewById(R.id.signup);

    }

    private void onGoogleLoginClicked() {
        Log.d("HomeActivity", "onGoogleLoginClicked Called");
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("468180243266-2tm8r9v58g6qpikvhlbho1h8ugvk2h5e.apps.googleusercontent.com")
                .requestEmail()
                .build();

        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    //TODO: to be called when logout function is implemented.
    private void logout() {
        Log.d("HomeActivity", "logout Called");
        AccessToken fbAccessToken = AccessToken.getCurrentAccessToken();
        if (fbAccessToken != null) {
            Log.d("prashant:home:fb", "user was loggedin in facebook. logging them out");
            LoginManager.getInstance().logOut();
        }
    }

    private void setupFacebookLogin() {

        Log.d("HomeActivity", "setupFacebookLogin Called");
        loginButton = findViewById(R.id.login_button);
        loginButton.setReadPermissions(Arrays.asList(EMAIL));
        callbackManager = CallbackManager.Factory.create();

        // Callback registration
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // App code
                Log.d("prashant:home:fb", "fb callback success: " + loginResult);
                AccessToken accessToken = loginResult.getAccessToken();
                String token = accessToken.getToken();
                Log.d("prashant:home:fb", "fb callback success token: " + token);
                registerFacebookLoginToken(token, LOGIN_TYPE_FACEBOOK);
            }

            @Override
            public void onCancel() {
                // App code
                Log.d("prashant:home:fb", "fb callback cancelled");
                Toast.makeText(HomeScreen_Activity.this, "Cancel", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(FacebookException exception) {
                // App code
                Toast.makeText(HomeScreen_Activity.this, "" + exception.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                Log.e("prashant:home:fb", "exception in facebook login:" + exception);
                exception.printStackTrace();
            }
        });

    }

    private void registerFacebookLoginToken(String token, int LoginType) {

        Log.d("HomeActivity", "registerFacebookLoginToken Called");
        Log.v("token12", token);

        dialog = ProgressDialog.show(this, "", "Loading. Please wait...", true);

        String url = BASE_URL + "/api/auth/signin/social";
        if (LoginType == LOGIN_TYPE_FACEBOOK)
            url += "/facebook/token";
        if (LoginType == LOGIN_TYPE_GOOGLE)
            url += "/google/token2";

        url += "?access_token=" + token;

        Log.v("test123", "" + url);

        OkHttpClient client = new OkHttpClient();
        RequestBody reqbody = RequestBody.create(null, new byte[0]);

        Request request = new Request.Builder()
                .url(url)
                .post(reqbody)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "75dcac22-9e90-4fd6-952c-0bd046d5ca5e,59f1b37b-32b8-456b-a828-6b3bd0300102")
                .addHeader("Host", BASE_HOST)
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "56")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();
        //Response response = client.newCall(request).execute();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.i("Response:", e.toString());

                dialog.dismiss();
                // Toast.makeText(HomeScreen_Activity.this, "oops, something went wrong!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                dialog.cancel();
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    Log.i("Response: not success", response.toString());

                    // You can also throw your own custom exception
                    //  Toast.makeText(HomeScreen_Activity.this, "oops, something went wrong!", Toast.LENGTH_SHORT).show();
                } else {
                    Log.i("Response:", response.toString());
                    Log.i("Response body:", response.body().toString());
                    String resp = response.body().string();
                    Log.i("Response String: ", resp);
                    Log.i("Response message:", response.message());
                    try {
                        JSONObject res = new JSONObject(resp);
                        auth_token = res.getString("data");
                        Utils.setLoginAuthToken(HomeScreen_Activity.this, auth_token);
                        Log.i("Auth Token is ", auth_token);
                        launchMainScreen();
                        response.body().close();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }

                }
            }
        });
    }

    private void launchMainScreen() {
        Log.d("HomeActivity", "launchMainScreen Called");
        //startActivity(new Intent(this, FullscreenActivity.class));
        String code = Receiver.code;
        if (code != null && code.length() == 6) {
            Log.d("ReferalObject", code);
            final String TAG = "OnCreate:Referral Used";
            String url = BASE_URL + "/api/user/saveReferInfo";
            OkHttpClient client = new OkHttpClient().newBuilder()
                    .build();
            MediaType mediaType = MediaType.parse("application/json");
            JSONObject obj = new JSONObject();
            try {
                obj.put("code", code);
                Log.d("ReferalObject", obj.toString());
            } catch (JSONException e) {
                e.printStackTrace();
                Crashlytics.logException(e);
            }
            RequestBody body = RequestBody.create(mediaType, obj.toString());
            Request request = new Request.Builder()
                    .url(url)
                    .post(body)
                    .addHeader("Authorization", auth_token)
                    .addHeader("Content-Type", "application/json")
                    .build();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    Log.e(TAG, e.getMessage());
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    if (response.isSuccessful()) {
                        Log.d("Referral", "Referred Successful");
                        response.body().close();
                    } else {
                        Log.d("Referral", "Failed");
                    }
                }
            });
        }
        Intent i = new Intent(this, HomeFeed.class);
        i.putExtra("newHomeFeed", true);
        Log.d("NewHomeFeed","HomeScreen2nd");
        startActivity(i);
        //overridePendingTransition(R.anim.slide_out_left, R.anim.slide_in_right);
        finish();
    }

    private void TermsofService() {

        String text = "By Continuing you indicate that you have read and agree to Revidly Terms of Service and Privacy Policy";

        Spannable ss = new SpannableString(text);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {

                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    String URL = "https://revidly.co/terms";
                    intent.setData(Uri.parse(URL));
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Log.d("error", e.getMessage());
                    Crashlytics.logException(e);
                }
            }
        };
        ClickableSpan clickableSpan1 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View view) {

                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    String URL = "https://revidly.co";
                    intent.setData(Uri.parse(URL));
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Log.d("error", e.getMessage());
                    Crashlytics.logException(e);
                }
            }
        };

        ss.setSpan(clickableSpan, 67, 83, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        ss.setSpan(clickableSpan1, 88, 102, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());

    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        Log.d("HomeActivity", "handleSignInResult Called");
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            // Signed in successfully, show authenticated UI.
            if (account != null) {
                String token = account.getIdToken();
                registerFacebookLoginToken(token, LOGIN_TYPE_GOOGLE);
            }
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.d("prashant", "exception in google signin: " + e.getMessage());
            e.printStackTrace();
            Log.w(HomeScreen_Activity.class.getSimpleName(), "signInResult:failed code=" + e.getStatusCode());
            Crashlytics.logException(e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.d("HomeActivity", "onActivityResult Called");
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    public static synchronized HomeScreen_Activity getInstance() {
        return mInstance;
    }

    @Override
    protected void onResume() {
        super.onResume();
        //initExoPlayer();
        Log.d("HomeActivity ", "onResume");
        //activityResumed();
        //FullscreenActivity.getInstance().setConnectivityListener(this);
        //if (checkOnPause)
        if (true) {
            IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
            this.registerReceiver(internetConnector, intentFilter);
            IntentFilter intentFilter1 = new IntentFilter("com.android.vending.INSTALL_REFERRER");
            this.registerReceiver(referCatcher, intentFilter1);
            Log.d("LOG_DATA", "ReferCatcher Registered");
            checkOnPause = false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("HomeActivity ", "onPause");
        checkOnPause = true;
        unregisterReceiver(internetConnector);
        unregisterReceiver(referCatcher);
    }

    public void displayInternetDialogue() {
        try {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();

            alertDialog.setTitle("No Connection");
            alertDialog.setMessage("Internet not available, Cross check your internet connection and try again");
            alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Log.d("FullScreenActivity", "I am finishing");
                    finish();
                    //new FullscreenActivity().isOnline();
                }
            });

            alertDialog.show();
        } catch (Exception e) {
            Crashlytics.logException(e);
            Log.d(SyncStateContract.Constants._ID, "Show Dialog: " + e.getMessage());
        }
    }

    @Override
    public void onDestroy() {

        super.onDestroy();
        if (checkOnPause == false) {
            unregisterReceiver(internetConnector);
            unregisterReceiver(referCatcher);
        }


    }


}
