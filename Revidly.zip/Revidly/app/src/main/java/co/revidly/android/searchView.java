package co.revidly.android;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.jaeger.library.StatusBarUtil;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static android.view.inputmethod.EditorInfo.IME_ACTION_DONE;

public class searchView extends FullscreenActivity {

    static RecyclerView recyclerView1;
    private RecyclerView.LayoutManager layoutManager1;
    private searchlistadapter mAdapter;
    //public searchlistadapter adapter;
    Context mContext;
    AddAnswer addAnswer;
    ShimmerFrameLayout mShimmerFrameLayout;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchview);

        mShimmerFrameLayout=(ShimmerFrameLayout)findViewById(R.id.shimmer_search);
        StatusBarUtil.setColor(this, Color.LTGRAY, 2);
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        ConstraintLayout flo = findViewById(R.id.searchview);
        flo.setPadding(0, result, 0, 0);
        final BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        /*
        bottomNavigationView.getMenu().findItem(R.id.action_discover).setChecked(true);
        bottomNavigationView.getMenu().findItem(R.id.action_discover).setEnabled(false);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_home:
                        finish();
                        break;
                    case R.id.action_discover:
                        Toast.makeText(searchView.this, "Discover", Toast.LENGTH_SHORT).show();
                        bottomNavigationView.getMenu().findItem(R.id.action_discover).setEnabled(false);
                        break;
                    case R.id.action_answer:
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(false);
                        finish();
                        View view = findViewById(R.id.listview);
                        Intent myIntent = new Intent(view.getContext(), quesandansreq.class);
                        startActivityForResult(myIntent, 0);
                        break;
                    case R.id.action_ask_ques:
                        qaup=true;
                        finish();
                        //BottomSheetFragment fragment = new BottomSheetFragment();
                        //fragment.show(getSupportFragmentManager(), "TAG");
                        break;
                    case R.id.action_profile:
                        bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(false);
                        finish();
                        prof=true;
                        View some = findViewById(R.id.listview);
                        Intent profile = new Intent(some.getContext(), ProfilePage.class);
                        startActivity(profile);
                        break;

                }
                return true;
            }
        });

         */
        addAnswer= new AddAnswer();
        recyclerView1 = findViewById(R.id.listview);
        layoutManager1 = new LinearLayoutManager(this);
        recyclerView1.setLayoutManager(layoutManager1);
        List<JSONObject> mlist = new ArrayList<>();
        mAdapter = new searchlistadapter(this, mlist);
        recyclerView1.setAdapter(mAdapter);

        SearchView sv = findViewById(R.id.search);
        View mView = sv;
        sv.clearFocus();
        sv.setImeOptions(IME_ACTION_DONE);
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                mShimmerFrameLayout.setVisibility(View.GONE);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                mShimmerFrameLayout.setVisibility(View.GONE);
                mAdapter.getFilter().filter(newText);
                return false;
            }
        });

    }

    void queClk(String q_id,String question){
        qaquestion=question;
        qa_ques_id=q_id;
        finish();
        Intent myIntent = new Intent(getWindow().getContext(), QuesAndAns.class);
        startActivityForResult(myIntent, 0);
    }


}