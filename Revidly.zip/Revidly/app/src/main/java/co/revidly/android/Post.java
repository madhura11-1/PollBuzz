package co.revidly.android;

public class Post {
    String type,url,previewURL, previewTitle, previewDesc;

    public Post(String url , String type) {
        this.type = type;
        this.url = url;
    }
    public Post(String url , String type, String previewURL, String previewTitle, String previewDesc) {
        this.type = type;
        this.url = url;
        this.previewURL = previewURL;
        this.previewTitle = previewTitle;
        this.previewDesc = previewDesc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPreviewURL() {
        return previewURL;
    }
    public String getPreviewTitle() {
        return previewTitle;
    }
    public String getPreviewDesc() {
        return previewDesc;
    }

}
