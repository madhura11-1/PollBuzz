package co.revidly.android;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.LoopingMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

@SuppressWarnings("ALL")
public class PostAdapter extends RecyclerView.Adapter<MyPostViewHolder> {
    private DefaultBandwidthMeter mBandwidthMeter;
    private AdaptiveTrackSelection.Factory mAdaptiveTrackSelectionFactory;
    private TrackSelector mTrackSelector;
    private SimpleExoPlayer mSimpleExoPlayer;
    private SimpleExoPlayerView mSimpleExoPlayerView;
    private LoopingMediaSource mLoopingMediaSource;
    private LoadControl mLoadControl;
    private ProgressBar mProgressBar;
    private Context context;
    private ArrayList<Post> postArrayList;
    public PostAdapter(Context context,ArrayList<Post> postArrayList) {
        this.context = context;
        this.postArrayList = postArrayList;
    }
    @NonNull
    @Override
    public MyPostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater =LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.post_item,parent,false);
        return new MyPostViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull final MyPostViewHolder holder, final int position) {
        if (postArrayList.get(position).getType().equals("video")||postArrayList.get(position).getType().equals("self_video")) {
            holder.setIsRecyclable(false);
            holder.img.setVisibility(View.GONE);
            holder.previewCL.setVisibility(View.GONE);
            mSimpleExoPlayerView = holder.exoPlayerView;
            mProgressBar=holder.myspinner;
            holder.myspinner.setVisibility(View.VISIBLE);
            holder.img.setVisibility(View.GONE);
            holder.exoPlayerView.setVisibility(View.VISIBLE);
            initExoPlayer();
            playvideoExoPlayer(postArrayList.get(position).getUrl(),holder);
            }
        else if(postArrayList.get(position).getType().equals("image")){
            holder.img.setVisibility(View.VISIBLE);
            holder.previewCL.setVisibility(View.GONE);
            holder.exoPlayerView.setVisibility(View.GONE);
            String url = postArrayList.get(position).getUrl();
            //Picasso.get().load(url).into(holder.img);
            Glide.with(context)
                    .load(url)
                    .apply(new RequestOptions().centerCrop().fitCenter())
                    .into(holder.img);
        }
        else if(postArrayList.get(position).getType().equals("preview")){
            holder.img.setVisibility(View.VISIBLE);
            holder.previewCL.setVisibility(View.VISIBLE);
            holder.exoPlayerView.setVisibility(View.GONE);
            String url = postArrayList.get(position).getUrl();
            //Picasso.get().load(url).into(holder.img);
            Glide.with(context)
                    .load(url)
                    .apply(new RequestOptions().centerCrop().fitCenter())
                    .into(holder.img);

            holder.previewTitle.setText(postArrayList.get(position).getPreviewTitle());
            holder.previewDesc.setText(postArrayList.get(position).getPreviewDesc());
            holder.img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoPreviewLink(holder, position);
                }
            });
            holder.previewCL.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoPreviewLink(holder, position);
                }
            });
        }
        holder.exoPlayerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.exoPlayerView.showController();
            }
        });

        holder.exoPlayerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.exoPlayerView.showController();
            }
        });

    }
    private void gotoPreviewLink(MyPostViewHolder holder, int position)
    {
        Log.d("Post adapter : ", "I am called inside img on click");
        {
            final int positionHolder = position;
            String previewUrl = postArrayList.get(positionHolder).getPreviewURL();
            String link = "";
            if(previewUrl.startsWith("https") || previewUrl.startsWith("http") )
                link = previewUrl;
            else
                link = "https://" + previewUrl;
            //String link = url;
            Uri webpage = Uri.parse(link);
            Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
        //if ( mContext instanceof HomeFeed)
        //((HomeFeed) mContext).call(position);
        //  ((HomeFeed) mContext).call(mData.get(position).optString("ans_id"));
        //else
        //  ((QuesAndAns) mContext).call(position);
        Log.d("Post adapter : ", "I am called inside img on click");
    }
    private void initExoPlayer() {
        Log.d("function call ", "initExoPlayer");
        mBandwidthMeter = new DefaultBandwidthMeter();
        mAdaptiveTrackSelectionFactory = new AdaptiveTrackSelection.Factory(mBandwidthMeter);
        mTrackSelector = new DefaultTrackSelector(mAdaptiveTrackSelectionFactory);
        mLoadControl = new DefaultLoadControl();
        mSimpleExoPlayer = ExoPlayerFactory.newSimpleInstance(context,mTrackSelector,mLoadControl);
        mSimpleExoPlayerView.setPlayer(mSimpleExoPlayer);
    }
    @Override
    public int getItemCount() {
        return postArrayList.size();
    }

    @Override
    public void onViewRecycled(@NonNull MyPostViewHolder holder) {
        int position = holder.getAdapterPosition();
        if (holder.exoPlayerView.getVisibility() == View.VISIBLE) {
            mSimpleExoPlayer.stop();
        }
        super.onViewRecycled(holder);
    }


    private void playvideoExoPlayer(String playUrl,MyPostViewHolder holder) {

        Log.d("function call ", "playvideoExoPlayer");
        // Produces DataSource instances through which media data is loaded.
        DefaultBandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
        DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(context,
                Util.getUserAgent(context, "com.exoplayerdemo"), bandwidthMeter);

        // Produces Extractor instances for parsing the media data.
        ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();

        // This is the MediaSource representing the media to be played.
        MediaSource videoSource = new ExtractorMediaSource(Uri.parse(playUrl),
                dataSourceFactory, extractorsFactory, null, null);

        // Prepare the player with the source.
        mLoopingMediaSource = new LoopingMediaSource(videoSource);

        mSimpleExoPlayer.prepare(videoSource);

        mSimpleExoPlayer.setPlayWhenReady(false);

        mSimpleExoPlayer.addListener(new ExoPlayer.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest, int i) {

            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

            }

            @Override
            public void onLoadingChanged(boolean isLoading) {

            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState)
            {
                if (playbackState == ExoPlayer.STATE_BUFFERING)
                    {
                    mProgressBar.setVisibility(View.VISIBLE);
                    }
                else
                    {
                    mProgressBar.setVisibility(View.GONE);
                    }
                if (playbackState == ExoPlayer.STATE_ENDED)
                {
                    mSimpleExoPlayer.seekToDefaultPosition();
                }
            }

            @Override
            public void onRepeatModeChanged(int repeatMode) {

            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {

            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {
            }

            @Override
            public void onPositionDiscontinuity(int reason) {

            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

            }
            @Override
            public void onSeekProcessed() {
            }
            public void onPositionDiscontinuity() {
            }

        });
    }
}