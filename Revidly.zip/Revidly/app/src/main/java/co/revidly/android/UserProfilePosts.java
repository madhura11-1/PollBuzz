package co.revidly.android;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import co.revidly.android.ui.Utils;

public class UserProfilePosts extends Fragment {
    private String userId;
    private String auth_token;
    List<JSONObject> mlist;
    ShimmerRecyclerView recyclerView;
    Adapter adapter;

    PostFeed postFeed = null;
    ProgressBar mProgressBar;
    TextView textView;
    public static UserProfilePosts newInstance(String userId)
    {
        UserProfilePosts UC = new UserProfilePosts();
        Bundle args = new Bundle();
        args.putString("userId", userId);
        UC.setArguments(args);
        return UC;
    }

    private void readBundle(Bundle bundle){
        if(bundle!=null){
            userId=bundle.getString("userId");
        }
    }
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.fragment_user_profile_posts,container,false);
        readBundle(getArguments());
        auth_token = Utils.getAuthToken(getActivity());
        mlist = new ArrayList<>();
        //getUserPosts(HomeFeed.userId);
        textView = view.findViewById(R.id.notposted);
        mProgressBar=view.findViewById(R.id.loadPosts);
        recyclerView = view.findViewById(R.id.user_posts_rec_view);
        postFeed = new PostFeed(getContext(), auth_token, userId );
        postFeed.setRecyclerView();
        postFeed.getPosts();
        if(PostFeed.timer!=null)    PostFeed.timer.cancel();
        postFeed.setViews();
        Log.d("UserProfilePosts ---> ","before Adapter constructor auth_token "+auth_token);


        /*
        adapter = new Adapter(getContext(), mlist);

        Log.d("UserProfilePosts ---> ","after adapter -->" + adapter);


        adapter.setHasStableIds(true);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setHasFixedSize(true);
        //recyclerView.setNestedScrollingEnabled(false);

        final LinearLayoutManager layoutManager=new LinearLayoutManager(this.getContext());
        ////itemTouchHelper.attachToRecyclerView(recyclerView);
        recyclerView.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                /*
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING || newState == RecyclerView.SCROLL_STATE_SETTLING || newState == RecyclerView.SCROLL_STATE_IDLE) {
                    adapter.onScrolled(recyclerView);
                }
                 //
            }


            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int fvi;
                fvi = layoutManager.findFirstCompletelyVisibleItemPosition();
                if(fvi==RecyclerView.NO_POSITION)
                    fvi=layoutManager.findFirstVisibleItemPosition();

            }
        });
        */

        return view;
    }
    PostFeed getPostFeedClass()
    {
        return postFeed;
    }
    ShimmerRecyclerView recyvlerView()
    {
        return recyclerView;
    }
    ProgressBar getProgressBar(){
        return mProgressBar;
    }
    TextView textView(){ return  textView; }
}
