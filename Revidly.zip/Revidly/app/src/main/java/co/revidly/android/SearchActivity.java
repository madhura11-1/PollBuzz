package co.revidly.android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.coremedia.iso.boxes.vodafone.AlbumArtistBox;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;

public class SearchActivity extends AppCompatActivity {
    JSONArray data;
    private static String TAG = "SearchActivity";
    JSONObject data1;
    ArrayList<FollowerList> users;
    private Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        users = new ArrayList<>();
        final RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        final EditText searchQuery = findViewById(R.id.searchQuery);
        searchQuery.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String searchUrl = BASE_URL + "/api/user/search";
                findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
                findViewById(R.id.noResult).setVisibility(View.GONE);
                if(timer!=null){
                    timer.cancel();
                }
                String search = searchQuery.getText().toString();
                OkHttpClient client = new OkHttpClient().newBuilder()
                        .build();
                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, "{\n\t\"text\": \""+search+"\"\n}");
                Request request = new Request.Builder()
                        .url(searchUrl)
                        .method("POST", body)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                        .build();
                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {

                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if(response.isSuccessful()){
                            try {
                                users.clear();
                                String resp = response.body().string();
                                Log.d(TAG,"Response body: "+resp);
                                data1 = new JSONObject(resp);
                                data = data1.getJSONArray("users");
                                Log.d(TAG,"dataBody:" + data);
                                String avatar,name,userId;
                                Log.d(TAG, "onResponse: "+ data.length());
                                for(int i=0;i<data.length();i++){
                                    JSONObject object = data.getJSONObject(i);
                                    avatar = object.getString("avatar");
                                    Log.d(TAG, "FollowerAvatar: " + avatar);
                                    name = object.getString("name");
                                    userId = object.getString("_id");
                                    Log.d(TAG, "FollowerName: " + name);
                                    users.add(new FollowerList(avatar,name,userId));
                                }
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        if(!users.isEmpty()){
                                            findViewById(R.id.noResult).setVisibility(View.GONE);
                                            FollowerListAdapter searchAdapter = new FollowerListAdapter(users,SearchActivity.this,false);
                                            recyclerView.setAdapter(searchAdapter);
                                            findViewById(R.id.progressBar).setVisibility(View.GONE);
                                        }
                                        else{
                                            findViewById(R.id.progressBar).setVisibility(View.GONE);
                                            findViewById(R.id.noResult).setVisibility(View.VISIBLE);
                                        }

                                    }
                                });
                                response.body().close();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
            }

            @Override
            public void afterTextChanged(Editable editable) {
                timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                            }
                        });
                    }
                },600);

            }
        });
    }
}