package co.revidly.android;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.crashlytics.android.BuildConfig;
import com.crashlytics.android.Crashlytics;
import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import org.jsoup.Jsoup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.OkHttpClient;

import static co.revidly.android.helpers.Config.BASE_URL;

public class newHomeFeed extends AppCompatActivity {
    RecyclerView recyclerView;
    Toolbar toolbar;
    newHomeFeedAdapter mAdapter;
    List<JSONObject> mData;
    LinearLayoutManager mLayout;
    BottomNavigationView bottomNavigationView;
    String auth_token;
    AppBarLayout collapsing;
    TextInputEditText search;
    private FirebaseAnalytics mFirebaseAnalytics;
    int flag = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_home_feed);
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getApplicationContext().getResources().getColor(R.color.light_GREY));
        setGlobals();
        checkNotificationStatus();

        mData.add(null);
        for (int i = 0; i < LoggedInUser.userTopics.length(); i++) {
            mData.add(LoggedInUser.userTopics.optJSONObject(i));
        }
        mAdapter.notifyDataSetChanged();

        search.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus)
                    search.setHint("Search Clan");
                else
                    search.setHint("");
            }
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
                if (!s.toString().isEmpty()) {
                    flag = 1;
                    search.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_arrow_back_black_24dp, 0, 0, 0);
                } else {
                    flag = 0;
                    search.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_search_black_24dp, 0, 0, 0);
                }
            }
        });
        search.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                final int DRAWABLE_LEFT = 0;

                if (event.getAction() == MotionEvent.ACTION_UP) {
                    Log.d("Points", "value: " + search.getCompoundDrawables()[DRAWABLE_LEFT].getBounds().width());
                    Log.d("Points", "value: " + event.getRawX() + " " + search.getPaddingLeft());
                    if (event.getRawX() <= (search.getCompoundDrawables()[DRAWABLE_LEFT].getBounds().width()) + search.getPaddingLeft() + 30) {
                        if (flag == 1) {
                            search.setText("");
                            filter("");
                            closeKeyboard();
                            search.clearFocus();
                        }
                        return true;
                    }
                }
                return false;
            }
        });
    }

    private void setGlobals() {
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        auth_token = null;
        auth_token = Utils.getAuthToken(this);
        if (auth_token == null) {
            startActivity(new Intent(this, HomeScreen_Activity.class));
            finish();
        }
        recyclerView = findViewById(R.id.recycler_view);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        BottomNavigationBar();
        toolbar = findViewById(R.id.toolbar);
        toolbar.inflateMenu(R.menu.new_homefeed_menu);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.change_clan) {
                    setUserTopics();
                }
                return true;
            }
        });
        search = findViewById(R.id.search);
        collapsing = findViewById(R.id.htab_appbar);
        mData = new ArrayList<>();
        mLayout = new LinearLayoutManager(this);
        mLayout.setOrientation(RecyclerView.VERTICAL);
        mAdapter = new newHomeFeedAdapter(this, mData);
        recyclerView.setLayoutManager(mLayout);
        recyclerView.setAdapter(mAdapter);
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                Log.d("CheckForUpdate()", "running");
                CheckForUpdate();
            }

        });
    }

    private void BottomNavigationBar() {
        bottomNavigationView.getMenu().findItem(R.id.action_new_home).setChecked(true);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_new_home:
                        break;
                    case R.id.action_home:
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
                        Intent intent = new Intent(newHomeFeed.this, HomeFeed.class);
                        startActivityForResult(intent,0);
                        break;
                    case R.id.action_post:
                        startActivity(new Intent(getApplicationContext(), Add_Answer.class));
                        bottomNavigationView.getMenu().findItem(R.id.action_post).setCheckable(false);
                        break;
                    case R.id.action_notif:
                        bottomNavigationView.getMenu().getItem(3).setIcon(R.drawable.ic_notifications);
                        Intent i = new Intent(getApplicationContext(), NotificationActivity.class);
                        startActivityForResult(i,0);
                        Bundle bundle = new Bundle();
                        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "notificationActivity");
                        mFirebaseAnalytics.logEvent("notificationIntent", bundle);
                        break;
                    case R.id.action_profile:
                        //bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        Intent intent1 = new Intent(getApplicationContext(), ProfilePage.class);
                        intent1.putExtra("USER_ID", LoggedInUser.userId);
                        startActivityForResult(intent1, 0);
                        break;

                }
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        BottomNavigationBar();
        if (LoggedInUser.updateClans) {
            LoggedInUser.updateClans = false;
            setUserTopics();
        }

    }

    public void setUserTopics() {
        new Handler().post(new Runnable() {
            public void run() {
                // Begin the transaction
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                // Replace the contents of the container with the new fragment
                ft.replace(R.id.user_clans_fragment_manager, UserClans.newInstance1(auth_token));
                // or ft.add(R.id.your_placeholder, new FooFragment());
                // Complete the changes added above
                ft.commit();
            }
        });
        hideViews();
    }

    private void hideViews() {
        Log.d("HomeFeed", "hideView() I am running");
        recyclerView.setVisibility(View.GONE);
        toolbar.setVisibility(View.GONE);
        bottomNavigationView.setVisibility(View.GONE);
        search.setVisibility(View.GONE);
        collapsing.setVisibility(View.GONE);
        //fragmentUserClans.setVisibility(View.GONE);
    }

    private void CheckForUpdate() {
        /* Executing class to check app update */
        if (!LoggedInUser.checkVerUpdateOnce) {
            String latestVersion = "";
            String currentVersion = getCurrentVersion();
            Log.d("Home Feed -->", "inside CheckForUpdate Current version = " + currentVersion);
            try {

                /* Get version Code */
                String newVersion = null;

                try {
                    Log.d("HomeFeed -->", "I am inside CheckForUpdate before response");
                    String response = Jsoup.connect("https://api.revidly.co/api/app/current-version")
                            .timeout(3000)
                            .ignoreContentType(true)
                            .get()
                            .body()
                            .text();
                    if (response != null) {
                        Log.d("HomeFeed -->", "I am inside CheckForUpdate inside if statement");
                        Log.d("prashant", "Got response: " + response);
                        JSONObject jsonObject = new JSONObject(response);
                        newVersion = jsonObject.getString("version");
                        Log.d("prashant", "newVersion: " + newVersion);

                    }
                    Log.d("HomeFeed -->", "I am inside CheckForUpdate after if statement");
                } catch (org.json.JSONException e) {
                    e.printStackTrace();
                    Crashlytics.logException(e);
                } catch (IOException e) {
                    e.printStackTrace();
                    Crashlytics.logException(e);
                }
                latestVersion = newVersion;
                LoggedInUser.checkVerUpdateOnce = true;
                //////////////////////

                Log.d("prashant -->", "I am inside CheckfForUpdate before GetVersionCode");
                //latestVersion = new GetVersionCode().execute().get();
                Log.d("prashant", "Latest version = " + latestVersion);
            } catch (Exception e) {
                e.printStackTrace();
                Crashlytics.logException(e);
            }
            //catch (ExecutionException e) {
            //  e.printStackTrace();
            //}

            //If the versions are not the same & app is available on PlayStore
            if (!currentVersion.equals(latestVersion) && latestVersion != null) {
                newHomeFeed.this.runOnUiThread(new Runnable() {
                    public void run() {
                        final AlertDialog.Builder builder = new AlertDialog.Builder(newHomeFeed.this);
                        builder.setTitle("A new version of the app is available with added features");
                        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //Click button action
                                logout();
                                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(("https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "&hl=en"))));
                                dialog.dismiss();
                                Bundle bundle = new Bundle();
                                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "update");
                                mFirebaseAnalytics.logEvent("UpdateClicked", bundle);
                            }
                        });

                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //Cancel button action
                                Bundle bundle = new Bundle();
                                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "updateCancelled");
                                mFirebaseAnalytics.logEvent("UpdateCancelled", bundle);
                            }
                        });

                        builder.setCancelable(false);
                        builder.show();
                    }
                });
            }
        }
        /* Code to check app version and show dialogue box ends*/
    }

    private String getCurrentVersion() {
        PackageManager pm = this.getPackageManager();
        PackageInfo pInfo = null;

        try {
            pInfo = pm.getPackageInfo(this.getPackageName(), 0);

        } catch (PackageManager.NameNotFoundException e1) {
            e1.printStackTrace();
            Crashlytics.logException(e1);
        }
        String currentVersion = pInfo.versionName;

        return currentVersion;
    }

    private void logout() {
        Utils.removeLoginAuthToken(getApplicationContext());
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "logout");
        mFirebaseAnalytics.logEvent("logoutClicked", bundle);
        startActivity(new Intent(getApplicationContext(), HomeScreen_Activity.class));
        Log.d("HomeActivity", "logout Called");
        AccessToken fbAccessToken = AccessToken.getCurrentAccessToken();
        if (fbAccessToken != null) {
            Log.d("LOG_DATA", "Logged out");
            LoginManager.getInstance().logOut();
        }
    }

    void filter(String text) {
        List<JSONObject> filteredList = new ArrayList<>();
        for (JSONObject obj : mData) {
            if (obj == null) {
                if ("All Posts".toLowerCase().contains(text.toLowerCase())) {
                    filteredList.add(obj);
                }
            } else {
                if (obj.optString("name").toLowerCase().contains(text.toLowerCase())) {
                    filteredList.add(obj);
                }
            }
            mAdapter.filterList(filteredList);
        }
    }

    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void checkNotificationStatus() {
        String url = BASE_URL + "/api/pushnotif/unreadStatus";
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Authorization", LoggedInUser.auth_token_global)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e("LOG_MSG", e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull okhttp3.Response response) throws IOException {
                try {
                    JSONObject data = new JSONObject();
                    String resp = response.body().string();
                    JSONObject resultObject = new JSONObject(resp);
                    Log.d("LOG_MSG", "Result: " + resultObject);
                    Log.d("LOG_MSGS", "Unread: " + resultObject.optBoolean("unread_notification_exist"));
                    final Boolean isUnRead = resultObject.optBoolean("unread_notification_exist");
                    Handler mainHandler;
                    mainHandler = new Handler(getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if (isUnRead) {
                                    bottomNavigationView.getMenu().getItem(3).setIcon(R.drawable.notification_blank_dot);
                                } else {
                                    bottomNavigationView.getMenu().getItem(3).setIcon(R.drawable.ic_notifications);
                                }
                            } catch (Exception e) {
                                Log.e("LOG_DATA", e.getMessage());
                                e.printStackTrace();
                            }
                        }
                    });
                } catch (Exception e) {
                    Log.e("LOG_MSG", e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }
}
