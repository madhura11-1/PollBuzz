package co.revidly.android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;

public class FollowingListActivity extends AppCompatActivity {
    private static String TAG = "getUserDetails:FollowingList";
    String subjectUrl;
    ArrayList<FollowerList> subjectLists;
    JSONArray data;
    static public String auth_token;
    private JSONObject data1;
    RecyclerView recyclerView;
    ImageView backButton;
    ProgressBar progressBar;
    boolean follow = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_following_list);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        subjectLists = new ArrayList<>();
        auth_token = Utils.getAuthToken(getApplicationContext());
        backButton = findViewById(R.id.backArrow);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setClickable(false);
        if(getIntent().getStringExtra("userId").equals(LoggedInUser.userId)){
            follow = true;
        }
        else {
            follow = false;
        }
        getUserDetails();
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    public void getUserDetails(){
        progressBar.setVisibility(View.VISIBLE);
        subjectUrl = BASE_URL + "/api/follow/followedBy?countOnly=no&userId=" + getIntent().getStringExtra("userId");

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(subjectUrl)
                .method("GET", null)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", auth_token)
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.e(TAG,e.getMessage());
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                if(response.isSuccessful())
                {
                    try {
                        String resp = response.body().string();
                        Log.d(TAG,"Response body: "+resp);
                        data1 = new JSONObject(resp);
                        data = data1.getJSONArray("data");
                        Log.d(TAG,"dataBody:" + data);
                        String subjectAvatar,subjectName,subjectUserId;
                        Log.d(TAG, "onResponse: "+ data.length());
                        for(int i=0;i<data.length();i++){
                            JSONObject object = data.getJSONObject(i);
                            if(object.has("subjectAvatar")){
                                subjectAvatar = object.getString("subjectAvatar");
                            }
                            else{
                                subjectAvatar = "null";
                            }
                            subjectName = object.getString("subjectName");
                            subjectUserId = object.getString("subject");
                            Log.d(TAG, "FollowerName: " + subjectName);
                            subjectLists.add(new FollowerList(subjectAvatar,subjectName,subjectUserId));

                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                progressBar.setVisibility(View.GONE);
                                if(subjectLists.isEmpty()){
                                    findViewById(R.id.noFollowers).setVisibility(View.VISIBLE);
                                }
                                else {
                                    FollowerListAdapter followerListAdapter = new FollowerListAdapter(subjectLists, FollowingListActivity.this,follow);
                                    recyclerView.setAdapter(followerListAdapter);
                                    findViewById(R.id.noFollowers).setVisibility(View.GONE);
                                }
                            }
                        });
                        response.body().close();
                    }
                    catch (Exception e){
                        Log.e(TAG,e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        });
    }
}
