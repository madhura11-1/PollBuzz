package co.revidly.android;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.crashlytics.android.Crashlytics;
import com.google.firebase.messaging.FirebaseMessaging;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_URL;

public class FollowerListAdapter extends RecyclerView.Adapter<FollowerViewHolder> {
    ArrayList<FollowerList> followerLists;
    boolean follow;
    Context context;

    public FollowerListAdapter(ArrayList<FollowerList> followerLists, Context context, boolean follow) {
        this.context = context;
        this.followerLists = followerLists;
        this.follow = follow;
    }

    @NonNull
    @Override
    public FollowerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.follower_list_item, parent, false);
        return new FollowerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final FollowerViewHolder holder, final int position) {
        if (follow ) {
            holder.unfollow.setVisibility(View.VISIBLE);
        } else {
            holder.unfollow.setVisibility(View.GONE);
        }
        holder.unfollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (holder.unfollow.getText().equals("Unfollow")) {
                    unfollowUser(followerLists.get(position).getUserId(), holder);
                } else {
                    followUser(followerLists.get(position).getUserId(), holder);
                }
            }
        });
        String followerName = followerLists.get(position).getName();
        holder.follower_name.setText(followerName);
        String followerAvatar = BASE_URL + "/app/profilePic/" +  followerLists.get(position).getUserId() + ".jpg";
        Log.d("FollowerListAdapter", "onBindViewHolder: " + followerLists.size());

            Glide.with(context)
                    .load(followerAvatar)
                    .apply(new RequestOptions().centerCrop().fitCenter())
                    .placeholder(R.drawable.propic1)
                    .into(holder.follower_img);

            holder.ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToProfile(position);
            }
        });
        holder.follower_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToProfile(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return followerLists.size();
    }

    public void goToProfile(int position) {
        Intent intent = new Intent(context, ProfilePage.class);
        intent.putExtra("USER_ID", followerLists.get(position).getUserId());
        context.startActivity(intent);
    }

    private void unfollowUser(String askedUserId, final FollowerViewHolder holder) {
        holder.unfollow.setClickable(false);
        holder.unfollow.setText("Follow");
        holder.unfollow.setBackgroundResource(R.color.grey);
        Toast.makeText(context, "Unfollowed", Toast.LENGTH_SHORT).show();
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\n\t\"userId\": \"" + askedUserId + "\"\n}");
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/follow/unfollow")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", Utils.getAuthToken(context))
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                try {
                    Log.e("LOG_DATA", e.getMessage());
                    e.printStackTrace();

                    ((FollowingListActivity) context).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            holder.unfollow.setText("Unfollow");
                            holder.unfollow.setClickable(true);
                            holder.unfollow.setBackgroundResource(R.drawable.revidlybutton);
                        }
                    });
                } catch (Exception x) {
                    Log.e("LOG_DATA", x.getMessage());
                    Crashlytics.log(String.valueOf(x.getMessage()));
                }
            }
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        Log.d("LOG_DATA", "Response String: " + response.toString());
                        String resp = response.body().string();
                        JSONObject result = new JSONObject(resp);
                        LoggedInUser.following = LoggedInUser.following - 1;
                        Log.i("LOG_DATA", "Result : " + result.toString());
                        Log.d("LOG_DATA", "Follower ID:" + result.getString("data"));
                        Log.d("LOG_DATA", "notification-user_following-" + result.getString("data"));
                        FirebaseMessaging.getInstance().unsubscribeFromTopic("notification-user_following-" + result.getString("data"));
                        ((FollowingListActivity) context).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                holder.unfollow.setBackgroundResource(R.drawable.revidlybutton);
                                holder.unfollow.setClickable(true);

                            }
                        });
                        response.body().close();
                    } catch (Exception e) {
                        Log.e("LOG_DATA", e.getMessage());
                        Crashlytics.log(e.getMessage());
                    }
                } else {

                    ((FollowingListActivity) context).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            holder.unfollow.setText("Unfollow");
                            holder.unfollow.setClickable(true);
                            holder.unfollow.setBackgroundResource(R.drawable.revidlybutton);
                        }
                    });}
            }
        });
    }

    private void followUser(String askedUserId, final FollowerViewHolder holder) {
        holder.unfollow.setClickable(false);
        holder.unfollow.setText("Unfollow");
        holder.unfollow.setBackgroundResource(R.color.grey);
        try {
            JSONObject postObj = new JSONObject();
                Toast.makeText(context, "Followed", Toast.LENGTH_SHORT).show();
                postObj.put("id", askedUserId);
                OkHttpClient client = new OkHttpClient().newBuilder()
                        .build();
                MediaType mediaType = MediaType.parse("application/json");
                RequestBody body = RequestBody.create(mediaType, "{\n\t\"userId\": \"" + askedUserId + "\"\n}");
                Request request = new Request.Builder()
                        .url(BASE_URL + "/api/follow/follow")
                        .method("POST", body)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Authorization", Utils.getAuthToken(context))
                        .build();

                Call call = client.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        try {
                            Log.e("LOG_DATA", e.getMessage());
                            e.printStackTrace();
                            } catch (Exception x) {
                            Log.e("LOG_DATA", x.getMessage());
                            ((FollowingListActivity) context).runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    holder.unfollow.setText("Follow");
                                    holder.unfollow.setClickable(true);
                                    holder.unfollow.setBackgroundResource(R.drawable.revidlybutton);
                                }
                            });
                        }

                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            try {
                                Log.d("LOG_DATA", "Response String: " + response.toString());
                                String resp = response.body().string();
                                JSONObject result = new JSONObject(resp);
                                LoggedInUser.following = LoggedInUser.following + 1;
                                Log.d("LOG_DATA", "Result : " + result.toString());
                                Log.d("LOG_DATA", result.getJSONObject("data").get("subject").toString());
                                Log.d("LOG_DATA", "notification-user_following-" + result.getJSONObject("data").get("subject").toString());
                                FirebaseMessaging.getInstance().subscribeToTopic("notification-user_following-" + result.getJSONObject("data").get("subject").toString());
                                ((FollowingListActivity) context).runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        holder.unfollow.setText("Unfollow");
                                        holder.unfollow.setBackgroundResource(R.drawable.revidlybutton);
                                        holder.unfollow.setClickable(true);
                                    }
                                });
                                response.body().close();
                            } catch (Exception e) {
                                e.printStackTrace();

                                Crashlytics.log(e.toString());
                            }

                        } else {
                            ((FollowingListActivity) context).runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    holder.unfollow.setText("Follow");
                                    holder.unfollow.setBackgroundResource(R.drawable.revidlybutton);
                                    holder.unfollow.setClickable(true);
                                }
                            });}
                    }
                });
            } catch (JSONException ex) {
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();

            Crashlytics.log(e.toString());
        }
    }
}
