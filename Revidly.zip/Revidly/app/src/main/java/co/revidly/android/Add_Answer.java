package co.revidly.android;

import com.bumptech.glide.Glide;
import com.crashlytics.android.Crashlytics;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.iceteck.silicompressorr.SiliCompressor;
import com.koushikdutta.urlimageviewhelper.UrlImageViewCallback;
import com.koushikdutta.urlimageviewhelper.UrlImageViewHelper;
import com.leocardz.link.preview.library.LinkPreviewCallback;
import com.leocardz.link.preview.library.SourceContent;
import com.leocardz.link.preview.library.TextCrawler;

import net.ypresto.qtfaststart.QtFastStart;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.PostFeed.timer;
import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;


public class Add_Answer extends AppCompatActivity implements TagUserListAdapter.AdapterCallBack {

    private static final int REQUEST_VIDEO_CAPTURE = 0;
    private static final int REQUEST_GALLERY = 1;
    ImageView close,linkClose;
    EditText description, link;
    Button upload, addlink, submit, uploadImg;
    TextView title,linkTitle,linkDesc, uploadText;
    ConstraintLayout preview;
    ImageView linkImg;
    String desc,url,imageEncoded;
    ConstraintLayout constraintLayout;
    private boolean videoSelected=false,imageSelected=false,isCompressed=false;
    TextCrawler textCrawler;
    ArrayList links;
    Uri mImageUri;
    boolean isLoaded = false;
    ArrayList<String> mArrayUri;
    ArrayList<Uri> URI;
    ArrayList<String> kind;
    ArrayList<String> names;
    ArrayList<String> UID = new ArrayList<>();
    ArrayList<FollowerList> users = new ArrayList<>();
    Boolean flag1 = false, flag2 = false;
    TagUserListAdapter userAdapter;
    List<String> names1 = new ArrayList<>();
    JSONArray data = new JSONArray();
    String name = "";
    LinearLayoutManager layoutmanager_User;
    RecyclerView recyclerView_User;
    Call call;
    File output;
    private boolean isNextEnabled = true;
    String previewImageURL;
    String previewTitle;
    String previewDesc;
    CountDownTimer c;
    String previewUrl;

    boolean previewPresent = false;

    private String currentTitle, currentUrl, currentCannonicalUrl,
            currentDescription;

    private Bitmap[] currentImageSet;
    private Bitmap currentImage;
    private int currentItem = 0;
    private int countBigImages = 0;
    private boolean noThumb;
    ArrayList<String> imageList;
    private boolean single=false,multiple=false,compressing=false,uploaded=false;
    private String ansname;
    private ProgressDialog progressDialogArray[];
    private ProgressDialog progressDialogSingle;
    public static Activity addAnswer;
    private LinearLayout preview_view;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addAnswer = this;
        String[] PERMISSIONS = {android.Manifest.permission.WRITE_EXTERNAL_STORAGE};
        for (String permission : PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, PERMISSIONS,0);
            }
        }
        setContentView(R.layout.add_a_answer);
        Intent intent = getIntent();
        String extra_text = intent.getStringExtra("EXTRA_TEXT");
        Log.d("extra_text", extra_text + "");
        handleSendText(extra_text);
        links = new ArrayList();
        kind = new ArrayList<>();
        constraintLayout = findViewById(R.id.preview);


        names = new ArrayList<>();
        preview_view = findViewById(R.id.preview_view);
        constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(links.size()>0){
                    String link = url;
                    //String link = url;
                    Uri webpage = Uri.parse(link);
                    Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(intent);
                }

            }
        });
        URI = new ArrayList<>();
        description = findViewById(R.id.desc);
        close = findViewById(R.id.closeButton);
        upload = findViewById(R.id.upload);
        submit = findViewById(R.id.button);
        link = findViewById(R.id.link);
        linkTitle = findViewById(R.id.title);
        linkDesc = findViewById(R.id.linkDesc);
        linkImg = findViewById(R.id.contentImg);
        linkClose = findViewById(R.id.close);
        preview = findViewById(R.id.preview);
        uploadText = findViewById(R.id.textView8);
        recyclerView_User = findViewById(R.id.taguser);
        textCrawler = new TextCrawler();
        mArrayUri = new ArrayList();

        linkClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                linkImg.setImageResource(android.R.color.transparent);
                linkTitle.setText("");
                linkDesc.setText("");
                previewImageURL="";
                previewDesc="";
                previewTitle="";
                previewUrl="";
                previewPresent = false;
                linkClose.setVisibility(View.GONE);
                preview.setVisibility(View.GONE);
                upload.setVisibility(View.VISIBLE);
                uploadText.setVisibility(View.VISIBLE);

            }
        });

        description.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (v.getId() == R.id.desc) {
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                    switch (event.getAction() & MotionEvent.ACTION_MASK) {
                        case MotionEvent.ACTION_UP:
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            break;
                    }
                }
                return false;
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(new Intent(getApplicationContext(), FullscreenActivity.class));
                finish();
            }
        });

        upload.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Add_Answer.this);

                //alertDialogBuilder.setMessage("Upload Media only from Gallery").setPositiveButton("Camera", new DialogInterface.OnClickListener() {
                //@Override
                //public void onClick(DialogInterface dialog, int which) {
                //  Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                //takeVideoIntent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 120); // 2 mins
                //startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
                //}
                //})

                //alertDialogBuilder.setMessage("Upload Media only from Gallery").setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
                //  @Override
                //public void onClick(DialogInterface dialog, int which) {
                upload.setClickable(false);
                upload.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_rounded_corners_gray));

                //Intent mediaChooser = new Intent(Intent.ACTION_GET_CONTENT);
                //mediaChooser.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                //mediaChooser.putExtra(Intent.EXTRA_AUTO_LAUNCH_SINGLE_CHOICE,true);
                //mediaChooser.setType("*/*");
                //mediaChooser.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*"});
                //startActivityForResult(mediaChooser, REQUEST_GALLERY);

                //Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
                //getIntent.setType("image/*");

                //Intent pickIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                //pickIntent.setType("image/*");

                //Intent chooserIntent = Intent.createChooser(getIntent, "Select Image");
                //chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] {pickIntent});

                //startActivityForResult(chooserIntent, 1);

                //Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                galleryIntent.setType("image/*");
                galleryIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(galleryIntent, REQUEST_GALLERY);


                //    }
                //}).create().show();

            }
        });


        layoutmanager_User = new LinearLayoutManager(this);
        layoutmanager_User.setOrientation(RecyclerView.VERTICAL);
        layoutmanager_User.setSmoothScrollbarEnabled(true);
        layoutmanager_User.setStackFromEnd(true);
        recyclerView_User.setLayoutManager(layoutmanager_User);
        userAdapter = new TagUserListAdapter(users, getApplicationContext(), Add_Answer.this);
        recyclerView_User.setAdapter(userAdapter);

        description.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

//                    pullLinks(charSequence.toString());
//                    if(links.size()>0){
//                        Toast.makeText(Add_Answer.this, "Links: " + links.get(0), Toast.LENGTH_LONG).show();
//                        textCrawler.makePreview(callback,links.get(0).toString());

                if (upload.isClickable()) {
                    pullLinks(charSequence.toString());
                    if (links.size() > 0) {
//                    Toast.makeText(Add_Answer.this, "Links: " + links.get(0), Toast.LENGTH_LONG).show();
                        Log.d("Add_answer", links.get(0).toString());

                        Log.d("Add_answer", "inside space if");
                        textCrawler.makePreview(callback, links.get(0).toString());
                         c = new CountDownTimer(12000,1000) {
                            @Override
                            public void onFinish() {
                                if (preview_view.getVisibility()==View.VISIBLE) {
                                    links.clear();
                                    if (!isLoaded)
                                        Toast.makeText(Add_Answer.this, "Unable to Fetch", Toast.LENGTH_SHORT).show();
                                    isLoaded = true;
                                    preview_view.setVisibility(View.GONE);
                                    uploadText.setVisibility(View.VISIBLE);
                                    upload.setVisibility(View.VISIBLE);
                                    preview.setVisibility(View.GONE);
                                    linkClose.setVisibility(View.GONE);
                                    isNextEnabled = true;
                                    submit.setBackground(getDrawable(R.drawable.revidlybutton1));
                                }
                            }

                            @Override
                            public void onTick(long millisUntilFinished) {

                            }
                        }.start();
                    }

                }
                if (!users.isEmpty()) {
                    users.clear();
                    userAdapter.notifyDataSetChanged();
                    flag1 = false;
                    flag2 = false;
                }
                int cursorPos = description.getSelectionStart();
                Log.d("ADDANSWERPOS", String.valueOf(cursorPos));
                if (cursorPos != -1) {
                    String selectedWord = "", prevWord = "";
                    int length_temp = 0;

                    for (String currentWord : charSequence.toString().split(" |\n")) {
                        length_temp += currentWord.length() + 1;
                        if (length_temp > cursorPos) {
                            selectedWord = currentWord;
                            break;
                        } else prevWord = currentWord;
                    }
                    Log.d("ADDANSWERFEED", prevWord + " " + selectedWord);
                    if (selectedWord.trim().startsWith("@")) {
//                            index = charSequence.toString().length();
                        flag1 = true;
                        name = "";
//                            text = charSequence.toString().substring(0, index - 1);
                    } else if (prevWord.trim().startsWith("@")) {
//                            index = charSequence.toString().length();
                        flag2 = true;
                        name = "";
//                            text = charSequence.toString().substring(0, index - 1);
                    } else {
                        flag1 = false;
                        flag2 = false;
                        users.clear();
                        userAdapter.notifyDataSetChanged();
                        findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
//                        view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                    }
                    try {
                        if (flag1) {
                            if (selectedWord.length() > 0) {
                                Log.d("TagUsers", users.toString());
                                String searchUrl = BASE_URL + "/api/user/search";
                                findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
//                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                if (timer != null) {
                                    timer.cancel();
                                }
                                if (call != null) call.cancel();
                                OkHttpClient client = new OkHttpClient().newBuilder()
                                        .build();
                                MediaType mediaType = MediaType.parse("application/json");
                                Log.d("SelectedWordChange", selectedWord);
                                RequestBody body = RequestBody.create(mediaType, "{\n\t\"text\": \"" + selectedWord.substring(1) + "\"\n}");
                                Log.d("SelectedWordChange", "{\n\t\"text\": \"" + selectedWord.substring(1) + "\"\n}");
                                Request request = new Request.Builder()
                                        .url(searchUrl)
                                        .method("POST", body)
                                        .addHeader("Content-Type", "application/json")
                                        .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                                        .build();
                                call = client.newCall(request);
                                call.enqueue(new Callback() {
                                    @Override
                                    public void onFailure(@NotNull Call call, @NotNull IOException e) {

                                    }

                                    @Override
                                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                        if (response.isSuccessful()) {
                                            try {
                                                String resp = response.body().string();
//                                            Log.d(TAG, "Response body: " + resp);
                                                JSONObject data1 = new JSONObject(resp);
                                                data = data1.getJSONArray("users");
//                                            Log.d(TAG, "dataBody:" + data);
                                                String avatar, name, userId;
//                                            Log.d(TAG, "onResponse: " + data.length());
                                                for (int i = 0; i < data.length(); i++) {
                                                    JSONObject object = data.getJSONObject(i);
                                                    avatar = object.getString("avatar");
//                                                Log.d(TAG, "FollowerAvatar: " + avatar);
                                                    name = object.getString("name");
                                                    userId = object.getString("_id");
//                                                Log.d(TAG, "FollowerName: " + name);
                                                    users.add(new FollowerList(avatar, name, userId));
                                                }

                                                    runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            if (!users.isEmpty()) {
                                                                Log.d("TagUser", users.toString());
//                                                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                                                findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
                                                                userAdapter.notifyDataSetChanged();
                                                            } else {
                                                                findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
//                                                            view.findViewById(R.id.noResult).setVisibility(View.VISIBLE);
                                                            }

                                                        }
                                                    });
                                                response.body().close();
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                });
                            } else {
                                if (!users.isEmpty()) {
                                    users.clear();
                                    userAdapter.notifyDataSetChanged();
                                }
                            }
                        } else if (flag2) {
                            if ((prevWord.length() + selectedWord.length()) > 0) {
                                Log.d("TagUsers", users.toString());
                                String searchUrl = BASE_URL + "/api/user/search";
                                findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
//                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                if (timer != null) {
                                    timer.cancel();
                                }
                                if (call != null) call.cancel();
                                OkHttpClient client = new OkHttpClient().newBuilder()
                                        .build();
                                MediaType mediaType = MediaType.parse("application/json");
                                Log.d("SelectedWordChange", selectedWord);
                                if (prevWord.length() > 1) {
                                    RequestBody body = RequestBody.create(mediaType, "{\n\t\"text\": \"" + prevWord.substring(1) + " " + selectedWord + "\"\n}");
                                    Log.d("SelectedWordChange", "{\n\t\"text\": \"" + prevWord.substring(1) + " " + selectedWord + "\"\n}");
                                    Request request = new Request.Builder()
                                            .url(searchUrl)
                                            .method("POST", body)
                                            .addHeader("Content-Type", "application/json")
                                            .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                                            .build();
                                    call = client.newCall(request);
                                    call.enqueue(new Callback() {
                                        @Override
                                        public void onFailure(@NotNull Call call, @NotNull IOException e) {

                                        }

                                        @Override
                                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                            if (response.isSuccessful()) {
                                                try {
                                                    String resp = response.body().string();
//                                            Log.d(TAG, "Response body: " + resp);
                                                    JSONObject data1 = new JSONObject(resp);
                                                    data = data1.getJSONArray("users");
//                                            Log.d(TAG, "dataBody:" + data);
                                                    String avatar, name, userId;
//                                            Log.d(TAG, "onResponse: " + data.length());
                                                    for (int i = 0; i < data.length(); i++) {
                                                        JSONObject object = data.getJSONObject(i);
                                                        avatar = object.getString("avatar");
//                                                Log.d(TAG, "FollowerAvatar: " + avatar);
                                                        name = object.getString("name");
                                                        userId = object.getString("_id");
//                                                Log.d(TAG, "FollowerName: " + name);
                                                        users.add(new FollowerList(avatar, name, userId));
                                                    }
                                                        runOnUiThread(new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                if (!users.isEmpty()) {
                                                                    Log.d("TagUser", users.toString());
//                                                            view.findViewById(R.id.noResult).setVisibility(View.INVISIBLE);
                                                                    findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
                                                                    userAdapter.notifyDataSetChanged();
                                                                } else {
                                                                    findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
//                                                            view.findViewById(R.id.noResult).setVisibility(View.VISIBLE);
                                                                }

                                                            }
                                                        });
                                                    response.body().close();
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        }
                                    });
                                }
                            } else {
                                if (!users.isEmpty()) {
                                    users.clear();
                                    userAdapter.notifyDataSetChanged();
                                }
                            }
                        }
                    }catch (Exception e){
                        FirebaseCrashlytics.getInstance().log(e.getMessage());
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable){
                if (TextUtils.isEmpty(editable)) {
                    if (c != null)
                        c.cancel();
                    links.clear();
                    preview_view.setVisibility(View.GONE);
                    uploadText.setVisibility(View.VISIBLE);
                    upload.setVisibility(View.VISIBLE);
                    preview.setVisibility(View.GONE);
                    linkClose.setVisibility(View.GONE);
                    isNextEnabled = true;
                    submit.setBackground(getDrawable(R.drawable.revidlybutton1));
                    String comment = editable.toString();
                    comment = comment.replace("\n", "\n ");
                    String[] arr = comment.split(" ");
                    Add_Answer.CustomStyleSpan[] styles = editable.getSpans(0, comment.length(), Add_Answer.CustomStyleSpan.class);
                    List<String> namesTemp = new ArrayList<>();
                    List<String> UIDTemp = new ArrayList<>();
                    for (int i = 0; i < arr.length - 1; i++) {
                        if (arr[i].trim().startsWith("@")) {
                            String temp = (arr[i] + " " + arr[i + 1]).trim();
                            Log.d("CommentSheetTemp", i + " " + temp + " " + names1.toString());
                            if (names1.contains(temp)) {
                                int index = names1.indexOf(temp);
                                Log.d("CommentSheetTemp", String.valueOf(index));
                                namesTemp.add(names1.get(index));
                                names1.remove(index);
                                names1.add(index, null);
                                UIDTemp.add(UID.get(index));
                            }
                        }
                    }
                    for (int i = 0; i < names1.size(); i++) {
                        if (names1.get(i) != null && i < styles.length) {
                            Log.d("AddAnswerTemp", names1.get(i));
                            editable.removeSpan(styles[i]);
                        }
                    }
                    names1.clear();
                    names1.addAll(namesTemp);
                    UID.clear();
                    UID.addAll(UIDTemp);
                    timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                               runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                    }
                                });
                        }
                    }, 600);
                }


            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(compressing){
                    Toast.makeText(Add_Answer.this, "Compressing Video please wait", Toast.LENGTH_SHORT).show();

                }
                else{
                    Log.d("LOG_DATA","Submit Button Clicked");
                   if (isNextEnabled) {

                       desc = description.getText().toString();
                       validateData();
                   }else {
                       Toast.makeText(Add_Answer.this, "Loading preview", Toast.LENGTH_SHORT).show();
                   }
                }


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri selectedMediaUri = data.getData();
//                try {

            String[] filePathColumn = { MediaStore.Images.Media.DATA };
            imageList = new ArrayList();

            if(data.getData()!=null){
                mImageUri=data.getData();
                final File[] file = {new File(getPath(getApplicationContext(), selectedMediaUri))};
                Log.d("LOG_TAG",mImageUri.toString());
                mArrayUri.add(0,mImageUri.toString());
                Log.d("LOG_TAG", "Selected Images" + imageEncoded);
                //if(mImageUri.toString().contains("jpg") || mImageUri.toString().contains("jpeg") || mImageUri.toString().contains("png")){
                Log.d("LOG_TAG", "ImageUri.getPath() " + mImageUri.getPath());
                Log.d("LOG_TAG", "gwtMimeType = " + getMimeType(mImageUri));

                if(isImageFile(mImageUri)){
                    progressDialogSingle = ProgressDialog.show(Add_Answer.this,
                            "Uploading Your File",
                            "Please Wait...");

                    getImagePath(selectedMediaUri,file, false, 0);
                    Toast.makeText(this, "One Image Uploading", Toast.LENGTH_SHORT).show();
                    kind.add(0,"image");
                }
                else if(isVideoFile(mImageUri))
                {
                    compressing=true;
                    progressDialogSingle = ProgressDialog.show(Add_Answer.this,
                            "Uploading Your File",
                            "Please Wait...");
                    checkSize(file, false, 0);
                    Toast.makeText(this, "One Video Uploading", Toast.LENGTH_SHORT).show();
                    kind.add(0,"video");
                }
                else
                {
                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Add_Answer.this);

                    alertDialogBuilder.setMessage("Failed to Upload.\n Please try again later").setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    }).create().show();
                }
            }
            else{
                if (data.getClipData() != null) {
                    multiple = true;
                    ClipData mClipData = data.getClipData();

                    for (int i = 0; i < mClipData.getItemCount(); i++) {
                        ClipData.Item item = mClipData.getItemAt(i);
                        Uri uri = item.getUri();
                        mArrayUri.add(uri.toString());
                        URI.add(uri);
                        Log.d("TAG","DATAAA: "+ URI.get(i));
                        Cursor cursor = getContentResolver().query(uri, filePathColumn, null, null, null);
                        cursor.moveToFirst();
                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        imageEncoded  = cursor.getString(columnIndex);
                        imageList.add(imageEncoded);
                        cursor.close();
                        Log.d("LOG_TAG", "Selected Images" + mArrayUri.size());
                    }

                    progressDialogArray = new ProgressDialog[URI.size()];
                    for(int i=0;i<URI.size();i++) {
                        if (getPath(getApplicationContext(), URI.get(i)) != null) {
                            final File[] file = {new File(Objects.requireNonNull(getPath(getApplicationContext(), URI.get(i))))};
                            if (isImageFile(URI.get(i))) {

                                //if(progressDialog == null)
                                progressDialogArray[i] = ProgressDialog.show(Add_Answer.this,
                                        "Uploading Files",
                                        "Please Wait...");


                                getImagePath(URI.get(i), file, true, i);
                                Log.d("LOG_DATA", "DATA: " + URI.get(i));
                                kind.add(i, "image");
                            } else if (isVideoFile(URI.get(i))) {
                                compressing = true;
                                progressDialogArray[i] = ProgressDialog.show(Add_Answer.this,
                                        "Uploading Files",
                                        "Please Wait...");
                                checkSize(file, true, i);
                                kind.add(i, "self_video");
                            } else {
                                final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Add_Answer.this);

                                alertDialogBuilder.setMessage("Failed to Upload.\n Please try again later").setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                    }
                                }).create().show();
                            }
                        }
                        else {
                            final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Add_Answer.this);

                            alertDialogBuilder.setMessage("Failed to Upload.\n Please try again later").setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                }
                            }).create().show();
                        }
                    }
                }

            }

//                    }
//                    catch (Exception e) {
//                        Log.e("LOG_TAG",e.getMessage());
//                        Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
//                }
        }


    }

    public boolean isImageFile(Uri path) {
        //String mimeType = URLConnection.guessContentTypeFromName(path);
        String mimeType = getMimeType(path);
        return mimeType != null && mimeType.startsWith("image");
    }
    public boolean isVideoFile(Uri path) {
        String mimeType = getMimeType(path);
        return mimeType != null && mimeType.startsWith("video");
    }

    public String getMimeType(Uri uri) {
        String mimeType = null;
        if (uri.getScheme().equals(ContentResolver.SCHEME_CONTENT)) {
            ContentResolver cr = getApplicationContext().getContentResolver();
            mimeType = cr.getType(uri);
        } else {
            String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uri
                    .toString());
            mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileExtension.toLowerCase());
        }
        return mimeType;
    }
    private LinkPreviewCallback callback = new LinkPreviewCallback() {
        @Override
        public void onPre() {
            if (preview.getVisibility()==View.VISIBLE) {
                preview_view.setVisibility(View.GONE);
            }else {
                preview_view.setVisibility(View.VISIBLE);
                upload.setVisibility(View.GONE);
                uploadText.setVisibility(View.GONE);
                isNextEnabled = false;
                submit.setBackground(getDrawable(R.drawable.revidlybutton1_disabled));
            }
        }

        @Override
        public void onPos(SourceContent sourceContent, boolean b) {
            if (sourceContent.getFinalUrl()==null) {
                Toast.makeText(Add_Answer.this, "Failed", Toast.LENGTH_SHORT).show();
            }
            else{
                currentImageSet = new Bitmap[sourceContent.getImages().size()];
                if (sourceContent.getTitle().equals("")){
                    sourceContent.setTitle("No Title");
                }

                else{
                    try {
                    UrlImageViewHelper.setUrlDrawable(linkImg, sourceContent
                            .getImages().get(0), new UrlImageViewCallback(){
                        @Override
                        public void onLoaded(ImageView imageView,
                                             Bitmap loadedBitmap, String url,
                                             boolean loadedFromCache){
                            if (loadedBitmap != null) {
                                currentImage = loadedBitmap;
                                currentImageSet[0] = loadedBitmap;
                                Log.d("Add_answer", "inside if");
                                Log.d("Add_answer","ANS: " + currentImageSet);
                                Log.d("Add_answer", "URL: "+ url);
                                previewImageURL = url;
                                Log.d("Add_Answer", "link Image = " + linkImg + "Current Image = " + linkImg);
//                            imageView.setImageURI(Uri.parse(url));
//                            imageView.setImageBitmap(getBitmapFromURL(url));
                                try {
                                    Glide.with(getApplicationContext())
                                            .load(new URL(url))
                                            .into(linkImg);
                                } catch (MalformedURLException e) {
                                    e.printStackTrace();
                                    Crashlytics.logException(e);
                                }
                            }
                            else{
                                Log.d("Add_answer","Outside if");
                            }
                        }
                    });

                    linkTitle.setText(sourceContent.getTitle());
                    Log.d("Add_answer","linkTitle : sourceContent Title = " + sourceContent.getTitle());
                    url =  sourceContent.getUrl();
                    Log.d("Add_answer","url = sourceContent.getUrl() = "+sourceContent.getUrl());
                    linkDesc.setText(sourceContent.getDescription());
                    Log.d("Add_answer","linkDesc : sourceContent Desc= " + sourceContent.getDescription());
                    preview.setVisibility(View.VISIBLE);
                    linkClose.setVisibility(View.VISIBLE);
                    upload.setVisibility(View.GONE);
                    uploadText.setVisibility(View.GONE);
                    previewDesc = sourceContent.getDescription();
                    previewTitle = sourceContent.getTitle();
                    previewUrl = sourceContent.getUrl();
                    previewPresent = true;
                    preview_view.setVisibility(View.GONE);
                        isNextEnabled = true;
                        submit.setBackground(getDrawable(R.drawable.revidlybutton1));
                }catch (Exception e) {
//                        isNextEnabled = true;
//                        submit.setBackground(getDrawable(R.drawable.revidlybutton1));
                    }
                }

            }

        }


    };

    private void compressVideo(final MediaMetadataRetriever retriever, final File[] file, final boolean multiple, final int position) {
//        final Button uplv = (Button) getDialog().findViewById(R.id.button2);
        Log.d("Inside compressVideo-->","First line of compress video" );
        upload.setClickable(false);
        upload.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_rounded_corners_gray));
//        ((TextView) getDialog().findViewById(R.id.status)).setText("Optimizing...");
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                String filePath = null;
                String filePath2 = null;
                try {
                    int width = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                    int height = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                    int rotation = Integer.valueOf(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
                    filePath =
                            SiliCompressor
                                    .with(getApplicationContext())
                                    .compressVideo(file[0].getPath(), file[0].getParent(), rotation == 0 ? width : 0, rotation == 0 ? height : 0, 1000000);
                    Log.d("LOG_DATA",filePath);
                    //filePath = SiliCompressor.with(getContext()).compressVideo(file[0].getPath(), file[0].getParent());
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                    Crashlytics.logException(e);
                }
                file[0] = new File(filePath);
                Log.d("File path:" + file[0].getPath(), filePath);
                Log.d("Video Size:", String.format("%d Mb", file[0].length() / (1024 * 1024)));
                Log.d("Video Size:", String.format("%d Kb", file[0].length() / (1024)));
                Log.d("Video Size:", String.format("%d Bytes", file[0].length()));

                //Code to to move meta data of video file to the beginning
                File input = new File(filePath); // Your input file
                filePath2 = filePath.substring(0, filePath.lastIndexOf('/'));
                String filename = filePath.substring(filePath.lastIndexOf('/'), filePath.lastIndexOf('.'));
                File output = new File(filePath2 + filename + "upload.mp4"); // Your output file
                String fileOutput = filePath2 + filename + "upload.mp4";

                Log.d("File Path input", "FilePath1 :" + filePath);
                Log.d("File Path input", "name :" + filename);
                Log.d("File Path input", "filePath2 :" + filePath2);
                Log.d("File Path input", "output :" + output);
                Log.d("File Path input", "fileOutput :" + fileOutput);

                try {
                    if (!output.exists()) // if there is no output file we'll create one
                        output.createNewFile();
                } catch (IOException e) {
                    Log.e("TAG", e.toString());
                    Crashlytics.logException(e);
                }

                try {
                    QtFastStart.fastStart(input, output);
                } catch (QtFastStart.MalformedFileException m) {
                    Log.e("QT", m.toString());
                } catch (QtFastStart.UnsupportedFileException q) {
                    Log.e("QT", q.toString());
                } catch (IOException i) {
                    Log.e("QT", i.toString());
                }
                input.delete();
                File file1 = new File(fileOutput);
                Log.d("LOG_DATA","FILE ::"+file1.getName());
                //names.add(BASE_URL+"/media/"+file1.getName());
                UploadAns(fileOutput, multiple, position);
                compressing=false;
            }

        });
    }

    private ArrayList pullLinks(String text) {
        String regex = "\\(?\\b(http://|www[.])[-A-Za-z0-9+&@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&@#/%=~_()|]";
//        Pattern p = Pattern.compile(regex);
        Pattern p = Pattern.compile(
                "(?:^|[\\W])((ht|f)tp(s?):\\/\\/|www\\.)"
                        + "(([\\w\\-]+\\.){1,}?([\\w\\-.~]+\\/?)*"
                        + "[\\p{Alnum}.,%_=?&#\\-+()\\[\\]\\*$~@!:/{};']*)",
                Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
        Matcher m = p.matcher(text);
        while(m.find()) {
            String urlStr = m.group();
            Log.d("Add_answer",urlStr);
            if (urlStr.startsWith("(") && urlStr.endsWith(")")) {
                urlStr = urlStr.substring(1, urlStr.length() - 1);
            }
            links.clear();
            links.add(0,urlStr);
        }
        return links;
    }

    private void validateData(){
        if(single || multiple || (!desc.isEmpty())){
            Intent intent = new Intent(getApplicationContext(),selectClan.class);
            if(!previewPresent) {
                intent.putStringArrayListExtra("mult_data", names);
                Log.d("ValidateData -->", "mult_data " + names.toString());
                intent.putExtra("type", kind);
                Log.d("ValidateData -->", "type " + kind.toString());
            }
            else
            {
                intent.putExtra("previewImageURL", previewImageURL);
                Log.d("ValidateData -->", "preview " + previewImageURL);
                intent.putExtra("type", "preview");
                Log.d("ValidateData -->", "type " + previewDesc);
                intent.putExtra("previewDesc", previewDesc);
                intent.putExtra("previewTitle", previewTitle);
                intent.putExtra("previewUrl", previewUrl);
            }
            intent.putExtra("description", description.getText().toString());
            if(!UID.isEmpty())
                intent.putStringArrayListExtra("taggedUsers", UID);
            startActivity(intent);
        }
        else{
            Toast.makeText(Add_Answer.this, "Please write something in text box", Toast.LENGTH_LONG).show();
        }
    }


    private void checkSize(final File[] file, boolean multiple, int position){
        final MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(file[0].getPath());
        String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        final long timeInMillisec = Long.parseLong(time );
        Log.i("Duration",time);
        if(timeInMillisec>120000) {
            Toast.makeText(this, "Max video size is 2min", Toast.LENGTH_SHORT).show();
        } else {
            compressVideo(retriever, file, multiple, position);
        }
    }

    public static String getPath(final Context context, final Uri uri) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }
                // TODO handle non-primary volumes
                else{
                    return System.getenv("SECONDARY_STORAGE") + "/" +split[1];
                }
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    private void getImagePath(final Uri uri, final File[] file, final boolean multiple, final int position ){
        AsyncTask.execute(new Runnable() {
            @Override
            public void run(){
                String filePath = file[0].getPath();
                String filePath2;

                Log.d("File path: ", filePath);
                Log.d("Video Size:", String.format("%d Mb", file[0].length() / (1024 * 1024)));
                Log.d("Video Size:", String.format("%d Kb", file[0].length() / (1024)));
                Log.d("Video Size:", String.format("%d Bytes", file[0].length()));

                //Code to to move meta data of video file to the beginning
                File input = new File(filePath); // Your input file
                filePath2 = filePath.substring(0, filePath.lastIndexOf('/'));
                String filename = filePath.substring(filePath.lastIndexOf('/'), filePath.lastIndexOf('.'));
                File output = new File(filePath2 + filename); // Your output file
                //String fileOutput = filePath2 + filename + "upload" + "."+MimeTypeMap.getFileExtensionFromUrl(input.getAbsolutePath());
                String fileOutput = filePath;
                Log.d("File Path input", "FilePath1 :" + filePath);
                Log.d("File Path input", "name :" + filename);
                Log.d("File Path input", "filePath2 :" + filePath2);
                Log.d("File Path input", "output :" + output);
                Log.d("File Path input", "fileOutput :" + fileOutput);

                try {
                    if (!output.exists()) // if there is no output file we'll create one
                        output.createNewFile();
                } catch (IOException e) {
                    Log.e("TAG", e.toString());
                    Crashlytics.logException(e);
                }
                /*
                try {
                    QtFastStart.fastStart(input, output);
                } catch (QtFastStart.MalformedFileException m) {
                    Log.e("QT", m.toString());
                } catch (QtFastStart.UnsupportedFileException q) {
                    Log.e("QT", q.toString());
                } catch (IOException i) {
                    Log.e("QT", i.toString());
                }
                input.delete();
                */
                File file1 = new File(fileOutput);
                Log.d("LOG_DATA","FILE ::"+file1.getName());
                //names.add(BASE_URL+"/media/"+file1.getName()+ GetMimeType(MimeTypeMap.getFileExtensionFromUrl(
                //      getPath(getApplicationContext(),uri))));

                Log.d("TAGDD","DATA: "+mArrayUri.size());
                File file = new File(fileOutput);
                long length = file.length()/1024;
                Log.d("LOG_DATA","Length of image: "+ length+ " kb");
                Log.d("LOG_DATA","EX: "+ GetMimeType(MimeTypeMap.getFileExtensionFromUrl(file.getAbsolutePath())));
                if(length>300){
                    isCompressed=true;
                    compressImage(file,position);
                }
                else{
                    UploadAns(fileOutput, multiple, position);
                }
            }

        });
    }

    private void compressImage(File file, final int position) {
        try{
            Log.d("LOG_DATA","Inside Upload Answer");
            Log.d("LOG_DATA","File Path "+ file.getAbsolutePath());
            String filePath = file.getPath();
            File f = new File(file.getPath());
            String filePath2 = filePath.substring(0, filePath.lastIndexOf('/'));
            String filename = filePath.substring(filePath.lastIndexOf('/'), filePath.lastIndexOf('.'));
            String fileOutput = filePath2 + filename + "upload" + "."+ MimeTypeMap.getFileExtensionFromUrl(file.toString());
            output = new File(fileOutput); // Your output file
            Bitmap bitmap = BitmapFactory.decodeFile(f.getPath());
            ByteArrayOutputStream byteArrayOS = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 20, byteArrayOS);
            byte[] byteArray = byteArrayOS.toByteArray();
            FileOutputStream fos = new FileOutputStream(output);
            fos.write(byteArray);
            fos.flush();
            fos.close();
            Log.d("LOG_DATA","FILE LENGTH: " + output.length()/1024 + " kb");
            UploadAns(fileOutput, multiple, position);


        }
        catch (Exception e){
            Log.e("LOG_DATA",e.getMessage());
            e.printStackTrace();
        }
    }

    public static String GetMimeType(String extension) {
        if (extension == null)
            throw new IllegalArgumentException("extension") ;

        if (extension.contains("."))
            extension = extension.substring(1);


        switch (extension.toLowerCase())
        {
            case "323": return "text/h323";
            case "3g2": return "video/3gpp2";
            case "3gp": return "video/3gpp";
            case "3gp2": return "video/3gpp2";
            case "3gpp": return "video/3gpp";
            case "7z": return "application/x-7z-compressed";
            case "aa": return "audio/audible";
            case "aac": return "audio/aac";
            case "aaf": return "application/octet-stream";
            case "aax": return "audio/vnd.audible.aax";
            case "ac3": return "audio/ac3";
            case "aca": return "application/octet-stream";
            case "accda": return "application/msaccess.addin";
            case "accdb": return "application/msaccess";
            case "accdc": return "application/msaccess.cab";
            case "accde": return "application/msaccess";
            case "accdr": return "application/msaccess.runtime";
            case "accdt": return "application/msaccess";
            case "accdw": return "application/msaccess.webapplication";
            case "accft": return "application/msaccess.ftemplate";
            case "acx": return "application/internet-property-stream";
            case "addin": return "text/xml";
            case "ade": return "application/msaccess";
            case "adobebridge": return "application/x-bridge-url";
            case "adp": return "application/msaccess";
            case "adt": return "audio/vnd.dlna.adts";
            case "adts": return "audio/aac";
            case "afm": return "application/octet-stream";
            case "ai": return "application/postscript";
            case "aif": return "audio/x-aiff";
            case "aifc": return "audio/aiff";
            case "aiff": return "audio/aiff";
            case "air": return "application/vnd.adobe.air-application-installer-package+zip";
            case "amc": return "application/x-mpeg";
            case "application": return "application/x-ms-application";
            case "art": return "image/x-jg";
            case "asa": return "application/xml";
            case "asax": return "application/xml";
            case "ascx": return "application/xml";
            case "asd": return "application/octet-stream";
            case "asf": return "video/x-ms-asf";
            case "ashx": return "application/xml";
            case "asi": return "application/octet-stream";
            case "asm": return "text/plain";
            case "asmx": return "application/xml";
            case "aspx": return "application/xml";
            case "asr": return "video/x-ms-asf";
            case "asx": return "video/x-ms-asf";
            case "atom": return "application/atom+xml";
            case "au": return "audio/basic";
            case "avi": return "video/x-msvideo";
            case "axs": return "application/olescript";
            case "bas": return "text/plain";
            case "bcpio": return "application/x-bcpio";
            case "bin": return "application/octet-stream";
            case "bmp": return "image/bmp";
            case "c": return "text/plain";
            case "cab": return "application/octet-stream";
            case "caf": return "audio/x-caf";
            case "calx": return "application/vnd.ms-office.calx";
            case "cat": return "application/vnd.ms-pki.seccat";
            case "cc": return "text/plain";
            case "cd": return "text/plain";
            case "cdda": return "audio/aiff";
            case "cdf": return "application/x-cdf";
            case "cer": return "application/x-x509-ca-cert";
            case "chm": return "application/octet-stream";
            case "class": return "application/x-java-applet";
            case "clp": return "application/x-msclip";
            case "cmx": return "image/x-cmx";
            case "cnf": return "text/plain";
            case "cod": return "image/cis-cod";
            case "config": return "application/xml";
            case "contact": return "text/x-ms-contact";
            case "coverage": return "application/xml";
            case "cpio": return "application/x-cpio";
            case "cpp": return "text/plain";
            case "crd": return "application/x-mscardfile";
            case "crl": return "application/pkix-crl";
            case "crt": return "application/x-x509-ca-cert";
            case "cs": return "text/plain";
            case "csdproj": return "text/plain";
            case "csh": return "application/x-csh";
            case "csproj": return "text/plain";
            case "css": return "text/css";
            case "csv": return "text/csv";
            case "cur": return "application/octet-stream";
            case "cxx": return "text/plain";
            case "dat": return "application/octet-stream";
            case "datasource": return "application/xml";
            case "dbproj": return "text/plain";
            case "dcr": return "application/x-director";
            case "def": return "text/plain";
            case "deploy": return "application/octet-stream";
            case "der": return "application/x-x509-ca-cert";
            case "dgml": return "application/xml";
            case "dib": return "image/bmp";
            case "dif": return "video/x-dv";
            case "dir": return "application/x-director";
            case "disco": return "text/xml";
            case "dll": return "application/x-msdownload";
            case "dll.config": return "text/xml";
            case "dlm": return "text/dlm";
            case "doc": return "application/msword";
            case "docm": return "application/vnd.ms-word.document.macroenabled.12";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "dot": return "application/msword";
            case "dotm": return "application/vnd.ms-word.template.macroenabled.12";
            case "dotx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.template";
            case "dsp": return "application/octet-stream";
            case "dsw": return "text/plain";
            case "dtd": return "text/xml";
            case "dtsconfig": return "text/xml";
            case "dv": return "video/x-dv";
            case "dvi": return "application/x-dvi";
            case "dwf": return "drawing/x-dwf";
            case "dwp": return "application/octet-stream";
            case "dxr": return "application/x-director";
            case "eml": return "message/rfc822";
            case "emz": return "application/octet-stream";
            case "eot": return "application/octet-stream";
            case "eps": return "application/postscript";
            case "etl": return "application/etl";
            case "etx": return "text/x-setext";
            case "evy": return "application/envoy";
            case "exe": return "application/octet-stream";
            case "exe.config": return "text/xml";
            case "fdf": return "application/vnd.fdf";
            case "fif": return "application/fractals";
            case "filters": return "application/xml";
            case "fla": return "application/octet-stream";
            case "flr": return "x-world/x-vrml";
            case "flv": return "video/x-flv";
            case "fsscript": return "application/fsharp-script";
            case "fsx": return "application/fsharp-script";
            case "generictest": return "application/xml";
            case "gif": return "image/gif";
            case "group": return "text/x-ms-group";
            case "gsm": return "audio/x-gsm";
            case "gtar": return "application/x-gtar";
            case "gz": return "application/x-gzip";
            case "h": return "text/plain";
            case "hdf": return "application/x-hdf";
            case "hdml": return "text/x-hdml";
            case "hhc": return "application/x-oleobject";
            case "hhk": return "application/octet-stream";
            case "hhp": return "application/octet-stream";
            case "hlp": return "application/winhlp";
            case "hpp": return "text/plain";
            case "hqx": return "application/mac-binhex40";
            case "hta": return "application/hta";
            case "htc": return "text/x-component";
            case "htm": return "text/html";
            case "html": return "text/html";
            case "htt": return "text/webviewhtml";
            case "hxa": return "application/xml";
            case "hxc": return "application/xml";
            case "hxd": return "application/octet-stream";
            case "hxe": return "application/xml";
            case "hxf": return "application/xml";
            case "hxh": return "application/octet-stream";
            case "hxi": return "application/octet-stream";
            case "hxk": return "application/xml";
            case "hxq": return "application/octet-stream";
            case "hxr": return "application/octet-stream";
            case "hxs": return "application/octet-stream";
            case "hxt": return "text/html";
            case "hxv": return "application/xml";
            case "hxw": return "application/octet-stream";
            case "hxx": return "text/plain";
            case "i": return "text/plain";
            case "ico": return "image/x-icon";
            case "ics": return "application/octet-stream";
            case "idl": return "text/plain";
            case "ief": return "image/ief";
            case "iii": return "application/x-iphone";
            case "inc": return "text/plain";
            case "inf": return "application/octet-stream";
            case "inl": return "text/plain";
            case "ins": return "application/x-internet-signup";
            case "ipa": return "application/x-itunes-ipa";
            case "ipg": return "application/x-itunes-ipg";
            case "ipproj": return "text/plain";
            case "ipsw": return "application/x-itunes-ipsw";
            case "iqy": return "text/x-ms-iqy";
            case "isp": return "application/x-internet-signup";
            case "ite": return "application/x-itunes-ite";
            case "itlp": return "application/x-itunes-itlp";
            case "itms": return "application/x-itunes-itms";
            case "itpc": return "application/x-itunes-itpc";
            case "ivf": return "video/x-ivf";
            case "jar": return "application/java-archive";
            case "java": return "application/octet-stream";
            case "jck": return "application/liquidmotion";
            case "jcz": return "application/liquidmotion";
            case "jfif": return "image/pjpeg";
            case "jnlp": return "application/x-java-jnlp-file";
            case "jpb": return "application/octet-stream";
            case "jpe": return "image/jpeg";
            case "jpeg": return "image/jpeg";
            case "jpg": return "image/jpg";
            case "js": return "application/x-javascript";
            case "jsx": return "text/jscript";
            case "jsxbin": return "text/plain";
            case "latex": return "application/x-latex";
            case "library-ms": return "application/windows-library+xml";
            case "lit": return "application/x-ms-reader";
            case "loadtest": return "application/xml";
            case "lpk": return "application/octet-stream";
            case "lsf": return "video/x-la-asf";
            case "lst": return "text/plain";
            case "lsx": return "video/x-la-asf";
            case "lzh": return "application/octet-stream";
            case "m13": return "application/x-msmediaview";
            case "m14": return "application/x-msmediaview";
            case "m1v": return "video/mpeg";
            case "m2t": return "video/vnd.dlna.mpeg-tts";
            case "m2ts": return "video/vnd.dlna.mpeg-tts";
            case "m2v": return "video/mpeg";
            case "m3u": return "audio/x-mpegurl";
            case "m3u8": return "audio/x-mpegurl";
            case "m4a": return "audio/m4a";
            case "m4b": return "audio/m4b";
            case "m4p": return "audio/m4p";
            case "m4r": return "audio/x-m4r";
            case "m4v": return "video/x-m4v";
            case "mac": return "image/x-macpaint";
            case "mak": return "text/plain";
            case "man": return "application/x-troff-man";
            case "manifest": return "application/x-ms-manifest";
            case "map": return "text/plain";
            case "master": return "application/xml";
            case "mda": return "application/msaccess";
            case "mdb": return "application/x-msaccess";
            case "mde": return "application/msaccess";
            case "mdp": return "application/octet-stream";
            case "me": return "application/x-troff-me";
            case "mfp": return "application/x-shockwave-flash";
            case "mht": return "message/rfc822";
            case "mhtml": return "message/rfc822";
            case "mid": return "audio/mid";
            case "midi": return "audio/mid";
            case "mix": return "application/octet-stream";
            case "mk": return "text/plain";
            case "mmf": return "application/x-smaf";
            case "mno": return "text/xml";
            case "mny": return "application/x-msmoney";
            case "mod": return "video/mpeg";
            case "mov": return "video/quicktime";
            case "movie": return "video/x-sgi-movie";
            case "mp2": return "video/mpeg";
            case "mp2v": return "video/mpeg";
            case "mp3": return "audio/mpeg";
            case "mp4": return "video/mp4";
            case "mp4v": return "video/mp4";
            case "mpa": return "video/mpeg";
            case "mpe": return "video/mpeg";
            case "mpeg": return "video/mpeg";
            case "mpf": return "application/vnd.ms-mediapackage";
            case "mpg": return "video/mpeg";
            case "mpp": return "application/vnd.ms-project";
            case "mpv2": return "video/mpeg";
            case "mqv": return "video/quicktime";
            case "ms": return "application/x-troff-ms";
            case "msi": return "application/octet-stream";
            case "mso": return "application/octet-stream";
            case "mts": return "video/vnd.dlna.mpeg-tts";
            case "mtx": return "application/xml";
            case "mvb": return "application/x-msmediaview";
            case "mvc": return "application/x-miva-compiled";
            case "mxp": return "application/x-mmxp";
            case "nc": return "application/x-netcdf";
            case "nsc": return "video/x-ms-asf";
            case "nws": return "message/rfc822";
            case "ocx": return "application/octet-stream";
            case "oda": return "application/oda";
            case "odc": return "text/x-ms-odc";
            case "odh": return "text/plain";
            case "odl": return "text/plain";
            case "odp": return "application/vnd.oasis.opendocument.presentation";
            case "ods": return "application/oleobject";
            case "odt": return "application/vnd.oasis.opendocument.text";
            case "one": return "application/onenote";
            case "onea": return "application/onenote";
            case "onepkg": return "application/onenote";
            case "onetmp": return "application/onenote";
            case "onetoc": return "application/onenote";
            case "onetoc2": return "application/onenote";
            case "orderedtest": return "application/xml";
            case "osdx": return "application/opensearchdescription+xml";
            case "p10": return "application/pkcs10";
            case "p12": return "application/x-pkcs12";
            case "p7b": return "application/x-pkcs7-certificates";
            case "p7c": return "application/pkcs7-mime";
            case "p7m": return "application/pkcs7-mime";
            case "p7r": return "application/x-pkcs7-certreqresp";
            case "p7s": return "application/pkcs7-signature";
            case "pbm": return "image/x-portable-bitmap";
            case "pcast": return "application/x-podcast";
            case "pct": return "image/pict";
            case "pcx": return "application/octet-stream";
            case "pcz": return "application/octet-stream";
            case "pdf": return "application/pdf";
            case "pfb": return "application/octet-stream";
            case "pfm": return "application/octet-stream";
            case "pfx": return "application/x-pkcs12";
            case "pgm": return "image/x-portable-graymap";
            case "pic": return "image/pict";
            case "pict": return "image/pict";
            case "pkgdef": return "text/plain";
            case "pkgundef": return "text/plain";
            case "pko": return "application/vnd.ms-pki.pko";
            case "pls": return "audio/scpls";
            case "pma": return "application/x-perfmon";
            case "pmc": return "application/x-perfmon";
            case "pml": return "application/x-perfmon";
            case "pmr": return "application/x-perfmon";
            case "pmw": return "application/x-perfmon";
            case "png": return "image/png";
            case "pnm": return "image/x-portable-anymap";
            case "pnt": return "image/x-macpaint";
            case "pntg": return "image/x-macpaint";
            case "pnz": return "image/png";
            case "pot": return "application/vnd.ms-powerpoint";
            case "potm": return "application/vnd.ms-powerpoint.template.macroenabled.12";
            case "potx": return "application/vnd.openxmlformats-officedocument.presentationml.template";
            case "ppa": return "application/vnd.ms-powerpoint";
            case "ppam": return "application/vnd.ms-powerpoint.addin.macroenabled.12";
            case "ppm": return "image/x-portable-pixmap";
            case "pps": return "application/vnd.ms-powerpoint";
            case "ppsm": return "application/vnd.ms-powerpoint.slideshow.macroenabled.12";
            case "ppsx": return "application/vnd.openxmlformats-officedocument.presentationml.slideshow";
            case "ppt": return "application/vnd.ms-powerpoint";
            case "pptm": return "application/vnd.ms-powerpoint.presentation.macroenabled.12";
            case "pptx": return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "prf": return "application/pics-rules";
            case "prm": return "application/octet-stream";
            case "prx": return "application/octet-stream";
            case "ps": return "application/postscript";
            case "psc1": return "application/powershell";
            case "psd": return "application/octet-stream";
            case "psess": return "application/xml";
            case "psm": return "application/octet-stream";
            case "psp": return "application/octet-stream";
            case "pub": return "application/x-mspublisher";
            case "pwz": return "application/vnd.ms-powerpoint";
            case "qht": return "text/x-html-insertion";
            case "qhtm": return "text/x-html-insertion";
            case "qt": return "video/quicktime";
            case "qti": return "image/x-quicktime";
            case "qtif": return "image/x-quicktime";
            case "qtl": return "application/x-quicktimeplayer";
            case "qxd": return "application/octet-stream";
            case "ra": return "audio/x-pn-realaudio";
            case "ram": return "audio/x-pn-realaudio";
            case "rar": return "application/octet-stream";
            case "ras": return "image/x-cmu-raster";
            case "rat": return "application/rat-file";
            case "rc": return "text/plain";
            case "rc2": return "text/plain";
            case "rct": return "text/plain";
            case "rdlc": return "application/xml";
            case "resx": return "application/xml";
            case "rf": return "image/vnd.rn-realflash";
            case "rgb": return "image/x-rgb";
            case "rgs": return "text/plain";
            case "rm": return "application/vnd.rn-realmedia";
            case "rmi": return "audio/mid";
            case "rmp": return "application/vnd.rn-rn_music_package";
            case "roff": return "application/x-troff";
            case "rpm": return "audio/x-pn-realaudio-plugin";
            case "rqy": return "text/x-ms-rqy";
            case "rtf": return "application/rtf";
            case "rtx": return "text/richtext";
            case "ruleset": return "application/xml";
            case "s": return "text/plain";
            case "safariextz": return "application/x-safari-safariextz";
            case "scd": return "application/x-msschedule";
            case "sct": return "text/scriptlet";
            case "sd2": return "audio/x-sd2";
            case "sdp": return "application/sdp";
            case "sea": return "application/octet-stream";
            case "searchconnector-ms": return "application/windows-search-connector+xml";
            case "setpay": return "application/set-payment-initiation";
            case "setreg": return "application/set-registration-initiation";
            case "settings": return "application/xml";
            case "sgimb": return "application/x-sgimb";
            case "sgml": return "text/sgml";
            case "sh": return "application/x-sh";
            case "shar": return "application/x-shar";
            case "shtml": return "text/html";
            case "sit": return "application/x-stuffit";
            case "sitemap": return "application/xml";
            case "skin": return "application/xml";
            case "sldm": return "application/vnd.ms-powerpoint.slide.macroenabled.12";
            case "sldx": return "application/vnd.openxmlformats-officedocument.presentationml.slide";
            case "slk": return "application/vnd.ms-excel";
            case "sln": return "text/plain";
            case "slupkg-ms": return "application/x-ms-license";
            case "smd": return "audio/x-smd";
            case "smi": return "application/octet-stream";
            case "smx": return "audio/x-smd";
            case "smz": return "audio/x-smd";
            case "snd": return "audio/basic";
            case "snippet": return "application/xml";
            case "snp": return "application/octet-stream";
            case "sol": return "text/plain";
            case "sor": return "text/plain";
            case "spc": return "application/x-pkcs7-certificates";
            case "spl": return "application/futuresplash";
            case "src": return "application/x-wais-source";
            case "srf": return "text/plain";
            case "ssisdeploymentmanifest": return "text/xml";
            case "ssm": return "application/streamingmedia";
            case "sst": return "application/vnd.ms-pki.certstore";
            case "stl": return "application/vnd.ms-pki.stl";
            case "sv4cpio": return "application/x-sv4cpio";
            case "sv4crc": return "application/x-sv4crc";
            case "svc": return "application/xml";
            case "swf": return "application/x-shockwave-flash";
            case "t": return "application/x-troff";
            case "tar": return "application/x-tar";
            case "tcl": return "application/x-tcl";
            case "testrunconfig": return "application/xml";
            case "testsettings": return "application/xml";
            case "tex": return "application/x-tex";
            case "texi": return "application/x-texinfo";
            case "texinfo": return "application/x-texinfo";
            case "tgz": return "application/x-compressed";
            case "thmx": return "application/vnd.ms-officetheme";
            case "thn": return "application/octet-stream";
            case "tif": return "image/tiff";
            case "tiff": return "image/tiff";
            case "tlh": return "text/plain";
            case "tli": return "text/plain";
            case "toc": return "application/octet-stream";
            case "tr": return "application/x-troff";
            case "trm": return "application/x-msterminal";
            case "trx": return "application/xml";
            case "ts": return "video/vnd.dlna.mpeg-tts";
            case "tsv": return "text/tab-separated-values";
            case "ttf": return "application/octet-stream";
            case "tts": return "video/vnd.dlna.mpeg-tts";
            case "txt": return "text/plain";
            case "u32": return "application/octet-stream";
            case "uls": return "text/iuls";
            case "user": return "text/plain";
            case "ustar": return "application/x-ustar";
            case "vb": return "text/plain";
            case "vbdproj": return "text/plain";
            case "vbk": return "video/mpeg";
            case "vbproj": return "text/plain";
            case "vbs": return "text/vbscript";
            case "vcf": return "text/x-vcard";
            case "vcproj": return "application/xml";
            case "vcs": return "text/plain";
            case "vcxproj": return "application/xml";
            case "vddproj": return "text/plain";
            case "vdp": return "text/plain";
            case "vdproj": return "text/plain";
            case "vdx": return "application/vnd.ms-visio.viewer";
            case "vml": return "text/xml";
            case "vscontent": return "application/xml";
            case "vsct": return "text/xml";
            case "vsd": return "application/vnd.visio";
            case "vsi": return "application/ms-vsi";
            case "vsix": return "application/vsix";
            case "vsixlangpack": return "text/xml";
            case "vsixmanifest": return "text/xml";
            case "vsmdi": return "application/xml";
            case "vspscc": return "text/plain";
            case "vss": return "application/vnd.visio";
            case "vsscc": return "text/plain";
            case "vssettings": return "text/xml";
            case "vssscc": return "text/plain";
            case "vst": return "application/vnd.visio";
            case "vstemplate": return "text/xml";
            case "vsto": return "application/x-ms-vsto";
            case "vsw": return "application/vnd.visio";
            case "vsx": return "application/vnd.visio";
            case "vtx": return "application/vnd.visio";
            case "wav": return "audio/wav";
            case "wave": return "audio/wav";
            case "wax": return "audio/x-ms-wax";
            case "wbk": return "application/msword";
            case "wbmp": return "image/vnd.wap.wbmp";
            case "wcm": return "application/vnd.ms-works";
            case "wdb": return "application/vnd.ms-works";
            case "wdp": return "image/vnd.ms-photo";
            case "webarchive": return "application/x-safari-webarchive";
            case "webtest": return "application/xml";
            case "wiq": return "application/xml";
            case "wiz": return "application/msword";
            case "wks": return "application/vnd.ms-works";
            case "wlmp": return "application/wlmoviemaker";
            case "wlpginstall": return "application/x-wlpg-detect";
            case "wlpginstall3": return "application/x-wlpg3-detect";
            case "wm": return "video/x-ms-wm";
            case "wma": return "audio/x-ms-wma";
            case "wmd": return "application/x-ms-wmd";
            case "wmf": return "application/x-msmetafile";
            case "wml": return "text/vnd.wap.wml";
            case "wmlc": return "application/vnd.wap.wmlc";
            case "wmls": return "text/vnd.wap.wmlscript";
            case "wmlsc": return "application/vnd.wap.wmlscriptc";
            case "wmp": return "video/x-ms-wmp";
            case "wmv": return "video/x-ms-wmv";
            case "wmx": return "video/x-ms-wmx";
            case "wmz": return "application/x-ms-wmz";
            case "wpl": return "application/vnd.ms-wpl";
            case "wps": return "application/vnd.ms-works";
            case "wri": return "application/x-mswrite";
            case "wrl": return "x-world/x-vrml";
            case "wrz": return "x-world/x-vrml";
            case "wsc": return "text/scriptlet";
            case "wsdl": return "text/xml";
            case "wvx": return "video/x-ms-wvx";
            case "x": return "application/directx";
            case "xaf": return "x-world/x-vrml";
            case "xaml": return "application/xaml+xml";
            case "xap": return "application/x-silverlight-app";
            case "xbap": return "application/x-ms-xbap";
            case "xbm": return "image/x-xbitmap";
            case "xdr": return "text/plain";
            case "xht": return "application/xhtml+xml";
            case "xhtml": return "application/xhtml+xml";
            case "xla": return "application/vnd.ms-excel";
            case "xlam": return "application/vnd.ms-excel.addin.macroenabled.12";
            case "xlc": return "application/vnd.ms-excel";
            case "xld": return "application/vnd.ms-excel";
            case "xlk": return "application/vnd.ms-excel";
            case "xll": return "application/vnd.ms-excel";
            case "xlm": return "application/vnd.ms-excel";
            case "xls": return "application/vnd.ms-excel";
            case "xlsb": return "application/vnd.ms-excel.sheet.binary.macroenabled.12";
            case "xlsm": return "application/vnd.ms-excel.sheet.macroenabled.12";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "xlt": return "application/vnd.ms-excel";
            case "xltm": return "application/vnd.ms-excel.template.macroenabled.12";
            case "xltx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.template";
            case "xlw": return "application/vnd.ms-excel";
            case "xml": return "text/xml";
            case "xmta": return "application/xml";
            case "xof": return "x-world/x-vrml";
            case "xoml": return "text/plain";
            case "xpm": return "image/x-xpixmap";
            case "xps": return "application/vnd.ms-xpsdocument";
            case "xrm-ms": return "text/xml";
            case "xsc": return "application/xml";
            case "xsd": return "text/xml";
            case "xsf": return "text/xml";
            case "xsl": return "text/xml";
            case "xslt": return "text/xml";
            case "xsn": return "application/octet-stream";
            case "xss": return "application/xml";
            case "xtp": return "application/octet-stream";
            case "xwd": return "image/x-xwindowdump";
            case "z": return "application/x-compress";
            case "zip": return "application/x-zip-compressed";
            default: return "application/octet-stream";
        }
    }

    void UploadAns(String filedir, final boolean multiple, final int position){

        final File file = new File(filedir);
//        Log.d("LOG_DATA","NAME: "+file.getName());
//        OkHttpClient client = new OkHttpClient();

        Log.d("LOG_DATA",GetMimeType(MimeTypeMap.getFileExtensionFromUrl(file.getAbsolutePath())));
        Log.d("LOG_DATA",file.getName());
        OkHttpClient client1 = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).writeTimeout(60,TimeUnit.SECONDS).readTimeout(60,TimeUnit.SECONDS).build();
        RequestBody requestFile = RequestBody
                .create(MediaType.parse(GetMimeType(filedir)), file);
        MultipartBody.Part partbody =
                MultipartBody.Part.createFormData("myImage", file.getName(), requestFile);
        RequestBody built = new MultipartBody.Builder().setType(MultipartBody.FORM).addPart(requestFile).addPart(partbody).addFormDataPart("Content-Disposition","form-data").build();
// add another part within the multipart request
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/app/upload")
                .post(built)
                .addHeader("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW")
                .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                .addHeader("User-Agent", "PostmanRuntime/7.19.0")
                .addHeader("Accept", "*/*")
                .addHeader("Cache-Control", "no-cache")
                .addHeader("Postman-Token", "89aa34ee-35b1-47ff-93fa-c9771aacf88b,45ed4ed6-346c-48a3-a64c-cc4a81ac06ed")
                .addHeader("Host", BASE_HOST)
                .addHeader("Content-Type", "multipart/form-data; boundary=--------------------------585739556235766079136963")
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Content-Length", "442812")
                .addHeader("Connection", "keep-alive")
                .addHeader("cache-control", "no-cache")
                .build();
        Log.d("LOG_DATA","Inside UploadAns");
//        OkHttpClient client = new OkHttpClient().newBuilder()
//                .build();
//        MediaType mediaType = MediaType.parse("multipart/form-data; boundary=--------------------------136740180505061281571726");
//        RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
//                .addFormDataPart("myImage",file.getName(),
//                        RequestBody.create(MediaType.parse(GetMimeType(filedir)),
//                                file))
//                .build();
//        Request request = new Request.Builder()
//                .url("https://dev-api.revidly.co/api/app/upload")
//                .method("POST", body)
//                .addHeader("Authorization", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZTBmMzUyMjEyODE3ZDQwOWQ5YTU5NmYiLCJuYW1lIjoicHJhc2hhbnQiLCJwaG9uZSI6bnVsbCwiZW1haWwiOiJ0ZXN0MUBnbWFpbC5jb20iLCJwZXJtaXNzaW9ucyI6W10sImF2YXRhciI6bnVsbCwidG9waWNzIjpudWxsLCJpYXQiOjE1ODAxOTU3OTQsImV4cCI6MTU4MDgwMDU5NH0.TM0OW3gxmh8NL28onbMGUhOM8QzuuMVXc-kXsd4YbOs")
//                .addHeader("Content-Type", "multipart/form-data; boundary=--------------------------136740180505061281571726")
//                .build();

        Call call = client1.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
                Log.i("Failed : ", e.getStackTrace().toString());
                Handler mainHandler;
                mainHandler = new Handler(getApplicationContext().getMainLooper());
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        createAlertDialog("Something went wrong","Please Try again");
                        upload.setClickable(true);
                        if(isCompressed){
                            output.delete();
                        }
                        upload.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_rounded_corners));
                        if (!multiple)
                            progressDialogSingle.dismiss();
                        else
                            progressDialogArray[position].dismiss();
//                        ((TextView) getDialog().findViewById(R.id.status)).setText("Connection Error... Try Again");
                    }
                });
            }
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                System.out.println("Success : " + response.body().toString());
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    final Handler mainHandler;
                    Log.i("Response:", response.toString());
                    Log.i("Response body:", response.body().string());
                    mainHandler = new Handler(getApplicationContext().getMainLooper());
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {

                            Toast.makeText(Add_Answer.this, "Failed to Upload.\nOnly mp4, jpg, jpeg & png is supported", Toast.LENGTH_LONG).show();
                            upload.setClickable(true);
                            upload.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_rounded_corners));
                            if(isCompressed){
                                output.delete();
                            }
                            if (!multiple)
                                progressDialogSingle.dismiss();
                            else
                                progressDialogArray[position].dismiss();

                        }
                    });
                    throw new IOException("Unexpected code " + response);
                } else {
                    String resp = response.body().string();
                    single = true;
                    uploaded=true;
                    try {
                        //ansname=(new JSONObject(resp).getJSONObject("data").getString("filename"));
                        //JSONObject result=new JSONObject(response);
                        names.add(BASE_URL+"/media/"+(new JSONObject(resp).getJSONObject("data").getString("filename")));
                        Log.d("Uploaded Image URL ->", "URL --> " + (BASE_URL+"/media/"+(new JSONObject(resp).getJSONObject("data").getString("filename"))));
                        Handler mainHandler;
                        if(output!=null)
                            output.delete();
                        try {
                            mainHandler = new Handler(getApplicationContext().getMainLooper());
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {


                                    Toast.makeText(Add_Answer.this, "Uploaded", Toast.LENGTH_SHORT).show();

//                                    ((TextView) getDialog().findViewById(R.id.status)).setText("Uploaded");
                                    //Toast.makeText(getContext(), "Upload Successful "+ansname, Toast.LENGTH_SHORT).show();
                                    if (!multiple)
                                        progressDialogSingle.dismiss();
                                    else
                                        progressDialogArray[position].dismiss();
                                }
                            });
                        } catch (NullPointerException e) {
                            Log.i("Null exception", e.getStackTrace().toString());
                            Crashlytics.logException(e);
                        }
//                        Log.i("Response:", response.toString());
//                        Log.i("Response body:", response.body().toString());
//                        Log.i("Response String: ", resp);
//                        Log.i("Response message:", response.message());
                        response.body().close();
                        //file.delete();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                }
            }
        });
    }

    private void createAlertDialog(final String title, final String message){
        Handler mainHandler;
        mainHandler = new Handler(getApplication().getMainLooper());
        mainHandler.post(new Runnable(){
            @Override
            public void run() {
                new android.app.AlertDialog.Builder(Add_Answer.this)
                        .setTitle(title)
                        .setMessage(message)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });
    }
    private void handleSendText(String extra_text) {
        description = findViewById(R.id.desc);
        if (extra_text == null) return;
        description.setText("" + extra_text);
    }

    @Override
    public void onItemClicked(int position) {
        try{
        Log.d("COMMENTSHEETFEED", "Pressed");
        if (position < users.size()) {
            name = users.get(position).getName();
            if (name.split(" ").length == 2) {
                String userId = users.get(position).getUserId();
                String name = users.get(position).getName();
                if (!names1.contains(name) && !UID.contains(userId)) {
                    UID.add(userId);
                    names1.add("@" + name);
                }
                int cursorPos = description.getSelectionStart();
                Log.d("Add_AnswerCursorX", String.valueOf(cursorPos));
                String comment = description.getText().toString();
                comment = comment.replace("\n", "\n ");
                int length_temp = 0;
                String textToPut = "";
                int final_index = 0;
                String prevWord = "";
                for (String currentWord : comment.split(" ")) {
                    length_temp += currentWord.length() + 1;
                    Log.d("Add_AnswerCursor", String.valueOf(length_temp));
                    if (length_temp > cursorPos) {
                        if (currentWord.startsWith("@"))
                            textToPut += "@" + name + " ";
                        else if(prevWord.startsWith("@")) {
                            textToPut = textToPut.replace(prevWord,"") + "@" + name + " ";
                        }
                        final_index = textToPut.length();
                        cursorPos = Integer.MAX_VALUE;
                    } else {
                        if (currentWord.endsWith("\n")) {
                            textToPut += currentWord;
                            prevWord = currentWord + "\n";
                        } else {
                            textToPut += currentWord + " ";
                            prevWord = currentWord + " ";
                        }
                        Log.d("Add_AnswerPUT", currentWord);
                    }
                }
//                textToPut=textToPut.replace("\n","\n ");
                SpannableString put_text = new SpannableString(textToPut);
                String[] arr = textToPut.split(" |\n");
                for (int i = 0; i < arr.length - 1; i++) {
                    Log.d("CommentSheetArray", arr[i]);
                    if (arr[i].trim().startsWith("@")) {
                        Log.d("TagUser", arr[i]);
                        String tag_name = arr[i] + " " + arr[i + 1];
                        tag_name = tag_name.trim();
                        Log.d("ADD_ANSWER", names1.toString());
                        Log.d("ADD_ANSWERTAGNAME", tag_name);
                        Log.d("ADD_ANSWERCheck1", arr[i] + " " + arr[i + 1]);
                        if (names1.contains(tag_name)) {
                            Log.d("ADD_ANSWERTAGNAME", names1.toString());
                            put_text.setSpan(new CustomStyleSpan(UID.get(names1.indexOf(tag_name))),
                                    textToPut.indexOf(tag_name),
                                    textToPut.indexOf(tag_name) + tag_name.length(),
                                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                }
                users.clear();
                userAdapter.notifyDataSetChanged();
                description.setText(put_text);
                description.setSelection(final_index);
                description.setMovementMethod(LinkMovementMethod.getInstance());
            }
        } else {
            Toast.makeText(getApplicationContext(), "Select name of length 2", Toast.LENGTH_SHORT).show();
        }
    } catch (Exception e) {
        Crashlytics.log(e.toString());
    }
    }
    private class CustomStyleSpan extends ClickableSpan {
        String Id;

        public CustomStyleSpan(String Id) {
            this.Id = Id;
        }

        @Override
        public void onClick(@NonNull View view) {
            description.setSelection(description.getText().length());
            goToProfile(Id);
        }
    }

    public void goToProfile(String User_Id) {
        Intent intent = new Intent(Add_Answer.this, ProfilePage.class);
        intent.putExtra("USER_ID", User_Id);
        startActivity(intent);
    }
}