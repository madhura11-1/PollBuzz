package co.revidly.android;

public class Notification_info
{
    String title,profile,desc;

    public Notification_info(String title, String profile, String desc) {
        this.title = title;
        this.profile = profile;
        this.desc = desc;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
