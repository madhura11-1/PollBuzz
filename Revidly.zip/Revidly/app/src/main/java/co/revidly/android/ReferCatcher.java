package co.revidly.android;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;


/*--- This clas should be triggered ---*/

public class ReferCatcher extends BroadcastReceiver {

    private static String referrer = "";

    @Override
    public void onReceive(android.content.Context context, Intent intent) {
        referrer = "";
        Log.d("ReferCatcher","INSIDE onReceive");
        Bundle extras = intent.getExtras();
        if(extras != null){
            referrer = extras.getString("referrer");
            Log.d("LOG_DATA1",referrer);
        }
        else{
            Log.d("LOG_DATA1","Fail");
            Toast.makeText(context, "Fail", Toast.LENGTH_SHORT).show();
        }
    }


}
