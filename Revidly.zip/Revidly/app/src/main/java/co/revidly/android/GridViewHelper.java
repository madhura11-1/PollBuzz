package co.revidly.android;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.crashlytics.android.Crashlytics;

import java.util.ArrayList;

import static co.revidly.android.helpers.Config.BASE_URL;

public class GridViewHelper extends ArrayAdapter<String> {
    private Context mContext;
    private LayoutInflater layoutInflater;
    private int layoutResource;
    private String mAppend;
    private ArrayList<String> imgUrl;

    public GridViewHelper(Context mContext, int layoutResource, String mAppend, ArrayList<String> imgUrl){
        super(mContext,layoutResource,imgUrl);
        this.mContext = mContext;
        layoutInflater = (LayoutInflater) mContext.getSystemService(mContext.LAYOUT_INFLATER_SERVICE);
        this.layoutResource = layoutResource;
        this.mAppend = mAppend;
        this.imgUrl = imgUrl;
    }

    private static class ViewHolder{
        VideoView videoView;
        ProgressBar progressBar;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        final ViewHolder viewHolder;
        if(convertView == null){
            convertView = layoutInflater.inflate(layoutResource,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.progressBar = convertView.findViewById(R.id.gridViewProgressBar);
            viewHolder.videoView = convertView.findViewById(R.id.gridImage);
            convertView.setTag(viewHolder);
        }
        else {
            viewHolder = (ViewHolder)convertView.getTag();
        }
        try{
            String videoURL = getItem(position);
            Log.d("PRANIT" ,"Hello "+videoURL);
            Uri uri = Uri.parse(BASE_URL+"/media/"+videoURL.trim());
            viewHolder.videoView.setVideoURI(uri);
            viewHolder.videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp){

                    viewHolder.videoView.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            Toast.makeText(mContext, "Video Clicked", Toast.LENGTH_SHORT).show();
                            return true;
                        }
                    });
                }
            });
            viewHolder.videoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    Log.d("PRANIT","ERROR in videoPlayer");
                    return false;
                }
            });

            viewHolder.videoView.start();


//            viewHolder.videoView.setOnInfoListener(new MediaPlayer.OnInfoListener() {
//                @Override
//                public boolean onInfo(MediaPlayer mp, int what, int extra) {
//                    if (MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START == what) {
//                        viewHolder.progressBar.setVisibility(View.GONE);
//                    }
//                    if (MediaPlayer.MEDIA_INFO_BUFFERING_START == what) {
//                        viewHolder.progressBar.setVisibility(View.VISIBLE);
//                    }
//
//                    if (MediaPlayer.MEDIA_INFO_BUFFERING_END == what) {
//                        viewHolder.progressBar.setVisibility(View.VISIBLE);
//                    }
//                    return false;
//                }
//            });




//            String videoURL = getItem(position);
//            Bitmap thumb = ThumbnailUtils.createVideoThumbnail(BASE_URL+"/media/"+videoURL,
//                    MediaStore.Images.Thumbnails.MINI_KIND);
//            Picasso.get().load(BASE_URL+"/media/"+videoURL).error(R.drawable.bookmark).into(viewHolder.imageView);
//            Log.d("PRANIT" ,"Hello "+videoURL);
//
//            Bitmap bMap = ThumbnailUtils.createVideoThumbnail(BASE_URL+"/media/"+videoURL, MediaStore.Video.Thumbnails.MICRO_KIND);
//            Log.d("PRANIT","BTMP: "+bMap);
//            viewHolder.imageView.setImageBitmap(bMap);
//
//            RequestOptions requestOptions = new RequestOptions();
//            requestOptions=requestOptions.placeholder(R.drawable.profile);
//            Glide.with(mContext)
//                    .load(BASE_URL+"/media/"+videoURL)
//                    .into(viewHolder.imageView);
        }
        catch (Exception e){
            Log.e("Pranit", "EERRROOORRR: "+ e.getMessage());
            Crashlytics.logException(e);
        }

        viewHolder.progressBar.setVisibility(View.GONE);

//        ImageLoader imageLoader = ImageLoader.getInstance();
//        imageLoader.displayImage(mAppend + videoUrl, viewHolder.imageView, new ImageLoadingListener() {
//            @Override
//            public void onLoadingStarted(String imageUri, View view) {
//                if(viewHolder.progressBar != null)
//                {
//                    viewHolder.progressBar.setVisibility(View.VISIBLE);
//                }
//            }
//
//            @Override
//            public void onLoadingFailed(String imageUri, View view, FailReason failReason)
//            {
//                if(viewHolder.progressBar != null)
//                {
//                    viewHolder.progressBar.setVisibility(View.GONE);
//                }
//
//            }
//
//            @Override
//            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage)
//            {
//                if(viewHolder.progressBar != null)
//                {
//                    viewHolder.progressBar.setVisibility(View.GONE);
//                }
//            }
//
//            @Override
//            public void onLoadingCancelled(String imageUri, View view)
//            {
//                if(viewHolder.progressBar != null)
//                {
//                    viewHolder.progressBar.setVisibility(View.GONE);
//                }
//            }
//        });

        return convertView;
    }
}
