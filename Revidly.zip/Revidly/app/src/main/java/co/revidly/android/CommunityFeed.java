package co.revidly.android;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.crashlytics.android.Crashlytics;
import com.danikula.videocache.HttpProxyCacheServer;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.JsonParser;
import com.jaeger.library.StatusBarUtil;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.provider.SyncStateContract;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import co.revidly.android.helpers.InternetConnector_Checker;
import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.Utils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static co.revidly.android.UserClans.auth_token_local;
import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerCallback;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerFullScreenListener;
//import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class CommunityFeed extends AppCompatActivity {

    /* Code from Ques and Answer Class Start */
    static int fvi;
    inviteSheet invitesheet;
    private ShimmerFrameLayout mShimmerFrameLayout;
    EditText writeFeed;
    ImageView profilePic;
    ConstraintLayout constraintLayout;
    ImageView pendingPost,blockedPost,setting;
    TextView pendingTitle;
    JSONArray topicArray;
    JSONArray communityTopicJsonArray;
    JSONObject communityTopicJsonObject;
    String rule="",data="";
    public static String topicID;
    String[] rules={"Any User can Post", "Admin will review Post", "Only Admin can Post"};

    private static final String SHOWCASE_ID_QnA = "Simple Showcase Question and Answer Page";

    public static final String COMMUNITY_TOKEN = "COMMUNITY_FEED";

    public static boolean changed = false, main = true, frmain = false, qaup = false,isCurrentTopicAdmin=false,pendingClicked=false;
    private static final int RECOVERY_REQUEST = 1;
    private FirebaseAnalytics mFirebaseAnalytics;
    //YouTubePlayer youTubePlayer;
    String VIDEO_KIND_SELF = "self";
    String VIDEO_KIND_YOUTUBE = "youtube";
    private static final String SHOWCASE_ID = "Simple Showcase";

    public static String auth_token=null;

    ShimmerRecyclerView recyclerView;

    public static AskQuestion fragment;
    ExecutorService service = Executors.newFixedThreadPool(4);
    BottomNavigationView bottomNavigationView;
    public String username, password;


    //for temporary profile page purpose
    public static boolean prof = false;
    //ProgressDialog progDialog;
    private ImageView progloader;

    JSONObject[] questions, answers;


    //AddAnswer addAnswer; //addAnswer was already defined in QuesAndAns hence removed from here
    public static boolean infullscreen=false;

    SeekBar seekbar;
    MediaController mediaController;

    public static HttpProxyCacheServer proxyserver, proxyserver1, proxyserver2;
    String aid;
    String communityTopics,currentrule;

    ImageButton shr;
    TextView upvotes;
    TextView downvotes;
    ImageButton upvt;
    ImageButton dnvt;
    ImageButton cmnt;
    Button answer;

    String url;

    PostFeed postFeed;

    //String nextCachedFileUrl;

    //public static boolean FullscreenActivityVisible; // Variable that will check the current activity state
    //public static boolean isOnline; // Variable that will have the current state of internet connectivity

    //public static boolean interentOkbuttonpressed = true;

    private final BroadcastReceiver internetConnector = new InternetConnector_Checker();

    private static CommunityFeed mInstance;

    ItemTouchHelper itemTouchHelper;
    Button invite;
    boolean checkVerUpdateOnce = false;
    boolean home_flag;

    //public static String userId = "5dee4ecb6548617591b628ea";

    SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        Log.d("function call QandA", "inside onCreate");
        StatusBarUtil.setTransparent(this);

        if(pendingClicked){
            pendingClicked=false;
        }
        if(isCurrentTopicAdmin){
            isCurrentTopicAdmin=false;
        }
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        //Setting view and top bar//
        setContentView(R.layout.community_feed);
        StatusBarUtil.setColor(this, Color.LTGRAY, 2);
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        checkRuleForTopic();
        setGlobals();
        if(LoggedInUser.isTopicAdmin){
            checkPrivileges();
        }
        ConstraintLayout flo = findViewById(R.id.constraintLayout);
        flo.setPadding(0, result, 0, 0);
        setViews();
        BottomNavigationBar();
        setOnClickListeners();

        if(auth_token == null){
            startActivity(new Intent(this, HomeScreen_Activity.class));
            finish();
        }
        //setupPostFeed();
        if(getIntent().hasExtra("Data")){
            data = getIntent().getStringExtra("Data");
        }

        if(data.equalsIgnoreCase("PendingPost")){
            getPendingPost();
        } else {
            getCommunityPosts();
        }
        //postFeed.setTopics("[{\"name\":\"politics\",\"description\":\"Indian Politics\",\"priorityRank\":1,\"popularityRank\":1,\"status\":\"1\",\"_id\":\"5e2ca5e11c85d118de420121\",\"createdBy\":\"5e0f352212817d409d9a596f\"}]");
        //getPosts("[{\"name\":\"politics\",\"description\":\"Indian Politics\",\"priorityRank\":1,\"popularityRank\":1,\"status\":\"1\",\"_id\":\"5e2ca5e11c85d118de420121\",\"createdBy\":\"5e0f352212817d409d9a596f\"}]");
    }

    private void getCommunityPosts() {
        postFeed.getPosts();

    }

    private void getPendingPost(){
        postFeed.getPendingPosts(topicID);
    }

    private void setGlobals() {
        auth_token = null;
        auth_token = Utils.getAuthToken(this);
        if(auth_token == null) {
            startActivity(new Intent(this, HomeScreen_Activity.class));
            finish();
        }
        recyclerView = findViewById(R.id.recvw);
        mInstance = this;
        communityTopics = getIntent().getStringExtra("COMMUNITY_TOKEN");
        // code for add clan to user
        Log.d("topicCommunityLoggedInUSer", String.valueOf(LoggedInUser.userTopics));
        try {
            Log.d("topicCommunityLoggedInUSer", communityTopics);
            communityTopicJsonArray = new JSONArray(communityTopics);
            for (int i=0; i<communityTopicJsonArray.length(); i++) {
                communityTopicJsonObject = communityTopicJsonArray.getJSONObject(i);
            }
            if(!communityTopicJsonObject.has("topicId")) {
            for(int i=0;i<LoggedInUser.userTopics.length();i++){
                JSONObject jsonLoggedInUser = LoggedInUser.userTopics.getJSONObject(i);
                    String commTopic = (String) communityTopicJsonObject.opt("_id");
                    Log.d("communityTopicJsonObject",commTopic);
                    Log.d("communityTopicJsonObject",jsonLoggedInUser.optString("topicId"));
                if (jsonLoggedInUser.optString("topicId").equals(commTopic)) {
                        findViewById(R.id.addClan).setVisibility(View.GONE);
                        Log.d("communityTopicJsonObject","true");
                        break;
                } else {
                        findViewById(R.id.addClan).setVisibility(View.VISIBLE);
                        Log.d("communityTopicJsonObject","false");
                    }
                }
            }
        } catch (JSONException e) {
            Log.d("topicCommunityLoggedInUSer",e.toString());
        }
        home_flag=getIntent().getBooleanExtra("HomeFlag",false);
        Log.d("CommunityFeed -->","Community Topics = " + communityTopics);
        if(PostFeed.timer!=null)    PostFeed.timer.cancel();
        postFeed = new PostFeed(CommunityFeed.this, auth_token, null);
        postFeed.setGlobals();
        postFeed.setTopics(communityTopics);


        setSwipeRefresh();

    }

    private void setViews() {
        try {

            mShimmerFrameLayout = findViewById(R.id.shimmer_qanda);
            mShimmerFrameLayout.setVisibility(View.GONE);
            bottomNavigationView = findViewById(R.id.bottom_navigation);
            TextView question = findViewById(R.id.textView7);
            findViewById(R.id.nullanswers).setVisibility(View.INVISIBLE);

            JSONArray topicsArray = new JSONArray(communityTopics);
            String topics = "";
            for (int i = 0; i <= topicsArray.length() - 1; i++) {
                JSONObject topicsItem = topicsArray.optJSONObject(i);
                if (i == 0)
                    topics = topics + topicsItem.optString("name");
                else
                    topics = topics + ", " + topicsItem.optString("name");
            }
            question.setText(topics);

            writeFeed = findViewById(R.id.writeFeed);
            //recyclerView = findViewById(R.id.recvw);
            answer = findViewById(R.id.qandaanswerbtn);
            invite = findViewById(R.id.qandainvite);

            postFeed.setRecyclerView();
            postFeed.setTopics(communityTopics);
            postFeed.setViews();

            profilePic = findViewById(R.id.propic);
            setProfilePic();

        }catch(Exception e) {
            e.printStackTrace();
            Crashlytics.logException(e);
        }

    }

    private void setSwipeRefresh() {
        // init SwipeRefreshLayout and TextView
        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.simpleSwipeRefreshLayout);
        // implement setOnRefreshListener event on SwipeRefreshLayout
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                // implement Handler to wait for 3 seconds and then update UI means update value of TextView
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // cancle the Visual indication of a refresh
                        swipeRefreshLayout.setRefreshing(false);
                        // Generate a random integer number
                        if(pendingClicked){
//                            if(PostFeed.timer!=null)    PostFeed.timer.cancel();
                            postFeed = new PostFeed(CommunityFeed.this, auth_token, null);
                            getPendingPost();
                        } else {
//                            if(PostFeed.timer!=null)    PostFeed.timer.cancel();
                            postFeed = new PostFeed(CommunityFeed.this, auth_token, null);
//                            postFeed.setGlobals();
                            postFeed.setTopics(communityTopics);
                            getCommunityPosts();
                        }


                    }
                }, 1000);
            }
        });
    }

    private void setOnClickListeners() {

        writeFeed.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                // show interest in events resulting from ACTION_DOWN
                if (event.getAction() == MotionEvent.ACTION_DOWN)
                    return true;

                // don't handle event unless its ACTION_UP so "doSomething()" only runs once.
                if (event.getAction() != MotionEvent.ACTION_UP)
                    return false;

                Log.d("HomeFeed -->", "writeFeed Touched");

                startActivity(new Intent(getApplicationContext(),Add_Answer.class));
                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"writeFeed");
                mFirebaseAnalytics.logEvent("writeFeedClicked",bundle);
                return true;
            }
        });
        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //mShimmerFrameLayout.stopShimmer();
                //mShimmerFrameLayout.setVisibility(View.GONE);

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"answer");
                mFirebaseAnalytics.logEvent("answerClicked",bundle);

            }
        });
        invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                invitesheet = new inviteSheet();
                invitesheet.show(getSupportFragmentManager(), "Invite");

                Bundle bundle = new Bundle();
                bundle.putString(FirebaseAnalytics.Param.ITEM_NAME,"invite");
                mFirebaseAnalytics.logEvent("inviteClicked",bundle);
                //mShimmerFrameLayout.stopShimmer();
                //mShimmerFrameLayout.setVisibility(View.GONE);
            }
        });
        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CommunityFeed.this, ProfilePage.class);
                intent.putExtra("USER_ID", LoggedInUser.userId);
                startActivityForResult(intent, 0);
                finish();
            }
        });

        findViewById(R.id.addClan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveClan();
            }
        });
    }

    private void saveClan() {
        findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
        MediaType mediaType = MediaType.parse("application/json");
//        JSONArray arr = new JSONArray();
//        for(int i=0;i<LoggedInUser.userTopics.length();i++){
//        }
        JSONObject obj = new JSONObject();
        String addClanId = (String) communityTopicJsonObject.opt("_id");
        try {
            obj.put("topicIds", addClanId);
            Log.d("JSONTopicsObjectFinal",obj.toString());
        } catch (JSONException e) {
            Log.d("CommunityFeedJSONException",e.toString());
        }
        RequestBody body = RequestBody.create(mediaType, obj.toString());
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/user/updateTopics")
                .post(body)
                .addHeader("Authorization", LoggedInUser.auth_token_global)
                .addHeader("Host", BASE_HOST)
                .addHeader("Connection", "keep-alive")
                .build();
        Call call = client.newCall(request);
        call.enqueue(new Callback(){
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
                findViewById(R.id.progressBar).setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(),"Something Went Wrong",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("CommunityFeedSave", "Response " + response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    findViewById(R.id.progressBar).setVisibility(View.GONE);
                    Toast.makeText(getApplicationContext(),"Something Went Wrong",Toast.LENGTH_SHORT).show();
                    throw new IOException("Unexpected code " + response);
                } else {
                    final String resp = response.body().string();
                    //mlist.clear();
                    try {
                        JSONObject resultObject = new JSONObject(resp);
                        Log.d("CommunityFeedSave", "insertUsertTopics-->" + resultObject.toString());
                        JSONArray topics = LoggedInUser.userTopics;
                        for (int i = 0; i < topics.length(); i++) {
                            JSONObject data = topics.getJSONObject(i);
                            Log.d("InsertUserTopics", "Unsubscribed to Topic ID: " + data.getString("name"));
                            FirebaseMessaging.getInstance().unsubscribeFromTopic("notification-post_trending-" + data.getString("topicId"));
                        }
                        LoggedInUser.userTopics = resultObject.getJSONArray("message");
                        for (int i = 0; i < LoggedInUser.userTopics.length(); i++) {
                            JSONObject data = LoggedInUser.userTopics.getJSONObject(i);

                            Log.d("InsertUserTopics", "Subscribed to Topic ID: " + data.getString("name"));
                            FirebaseMessaging.getInstance().subscribeToTopic("notification-post_trending-" + data.getString("topicId"));
                        }
                       runOnUiThread(new Runnable() {
                           @Override
                           public void run() {
                               findViewById(R.id.progressBar).setVisibility(View.GONE);
                               startActivity(new Intent(CommunityFeed.this,HomeFeed.class));

                           }
                       });
                         Log.d("InsertUserTopics", "insertUsertTopics-->" + LoggedInUser.userTopics.toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                }
            }
        });
    }


    PostFeed getPostFeedClass() {
        return postFeed;
    }

    private void BottomNavigationBar() {
        bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                View view = findViewById(R.id.constraintLayout);
                switch (item.getItemId()) {
                    case R.id.action_home:
                        //finish();
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
                        Intent intent1 = new Intent(CommunityFeed.this, HomeFeed.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent1);
                        break;
                    /*case R.id.action_discover:
                        finish();
                        Intent discover = new Intent(view.getContext(), searchView.class);
                        startActivityForResult(discover, 0);
                        break;

                     */
                    /*
                    case R.id.action_video:
                        //bottomNavigationView.getMenu().findItem(R.id.action_video).setEnabled(true);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        Intent videoScreen = new Intent(view.getContext(), FullscreenActivity.class);
                        startActivityForResult(videoScreen, 0);
                        break;

                     */
                    /*
                    case R.id.action_answer:
                        bottomNavigationView.getMenu().findItem(R.id.action_answer).setEnabled(false);
                        finish();
                        Intent myIntent = new Intent(view.getContext(), quesandansreq.class);
                        startActivityForResult(myIntent, 0);
                        break;
                     */
                    case R.id.action_post:
                        //bottomNavigationView.getMenu().findItem(R.id.action_post).setEnabled(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        //fragment.show(getSupportFragmentManager(), "TAG");
                        startActivity(new Intent(getApplicationContext(),Add_Answer.class));
                        bottomNavigationView.getMenu().findItem(R.id.action_post).setCheckable(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setCheckable(true);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);

                        break;
                    /*
                    case R.id.action_ask_ques:
                        qaup = true;
                        finish();
                        //fragment.show(getSupportFragmentManager(), "TAG");
                        break;
                     */
                    case R.id.action_profile:
                        //bottomNavigationView.getMenu().findItem(R.id.action_profile).setEnabled(false);
                        //bottomNavigationView.getMenu().findItem(R.id.action_home).setEnabled(true);
                        //finish();
                        Intent intent = new Intent(view.getContext(), ProfilePage.class);
                        intent.putExtra("USER_ID", LoggedInUser.userId);
                        startActivityForResult(intent, 0);
//                        startActivity(intent);
//                        finish();

                        break;
                }
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("function call: ", "onResume");

        /* Registering Broadcast receiver */
        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        this.registerReceiver(internetConnector, intentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(internetConnector);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        BottomNavigationBar();
        if (LoggedInUser.updateClans) {
            findViewById(R.id.nopost).setVisibility(View.GONE);
            LoggedInUser.updateClans = false;
            setUserTopics();
        }
    }

    public void setUserTopics() {
        // Begin the transaction
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        // Replace the contents of the container with the new fragment
        ft.replace(R.id.user_clans_fragment_manager, UserClans.newInstance1(auth_token));
        // or ft.add(R.id.your_placeholder, new FooFragment());
        // Complete the changes added above
        ft.commit();
        hideViews();
    }

    private void hideViews() {
        Log.d("CommunityFeed", "hideView() I am running");
        writeFeed.setVisibility(View.GONE);
//        findViewById(R.id.search).setVisibility(View.GONE);
        //question.setVisibility(View.GONE);
        profilePic.setVisibility(View.GONE);
        bottomNavigationView.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        if (isCurrentTopicAdmin) {
            setting.setVisibility(View.GONE);
            pendingPost.setVisibility(View.GONE);
        }
        if(pendingTitle!=null && pendingTitle.getVisibility()==View.VISIBLE){
            pendingTitle.setVisibility(View.GONE);
        }
    }
    //fragmentUserClans.setVisibility(View.GONE);

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //Toast.makeText(this, "onDestroy "+aid, Toast.LENGTH_LONG).show();
        Log.d("function call: ", "onDestroy");
        clearApplicationData();
        //youTubePlayerView.release();
    }

    public void clearApplicationData() {
        Log.d("function call ", "clearApplicationData");
        File cache = getCacheDir();
        //File appDir = new File(cache.getParent());
        File appDir = new File(cache.getPath());
        if (appDir.exists()) {
            String[] children = appDir.list();
            for (String s : children) {
                if (!s.equals("lib")) {
                    deleteDir(new File(appDir, s));
                    Log.i("EEERRRRRRROOOOOOOR", "**************** File /data/data/APP_PACKAGE/" + s + " DELETED *******************");
                }
            }
        }
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }

        return dir.delete();
    }
    /* Tutorial Sequence commented out */
    /*
    private void showTutorSequenceQuesAndAns(int millis) {

        Log.d("showtutor", "In showTutorSequence function");
        ShowcaseConfig config = new ShowcaseConfig(); //create the showcase config
        config.setDelay(millis); //set the delay of each sequence using millis variable

        MaterialShowcaseSequence sequence = new MaterialShowcaseSequence(this, SHOWCASE_ID_QnA); // create the material showcase sequence

        sequence.setConfig(config); //set the showcase config to the sequence.

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.textView7))
                        .setTitleText("Question asked by user")
                        .setDismissText("Click Here : Next")
                        //.setDismissOnTargetTouch(false)
                        //.setContentText("Click on Next")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withRectangleShape(true)
                        .build()
        );

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.nullanswers))
                        .setTitleText("\nList of video answers")
                        .setDismissText("Click Here : Next")
                        //.setContentText("This video is uploaded by another user in response to the Question")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape(true)
                        //.withoutShape()
                        .setShapePadding(-300)
                        .build()
        ); // add view for the second sequence, in this case it is a textview.
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.qandaanswerbtn))
                        .setTitleText("Upload your Video Opinion from here")
                        .setDismissText("Click Here : Next")
                        //.setDismissOnTargetTouch(false)
                        .setContentText("")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape()
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.qandainvite))
                        .setTitleText("Want to ask others for an answer?")
                        .setDismissText("Click Here : End Tutorial")
                        //.setDismissOnTargetTouch(false)
                        .setContentText("Ask from here")
                        //.setSkipText("Skip Revidly Tutorial")
                        //.setContentTextColor(Color.WHITE)
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        //.withRectangleShape(true)
                        .build()
        );

        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.propic))
                        .setTitleText("Profile Picture")
                        .setDismissText("Click Here : Next")
                        //.setContentText("The DP of the person who has uploaded the Video")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        ); // add view for the third sequence, in this case it is a checkbox.
         */
        /*
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.upvote))
                        .setTitleText("UpVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Like the video? UpVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.downvote))
                        .setTitleText("DownVote")
                        .setDismissText("Click Here : Next")
                        .setContentText("Did not like the video? DownVote it")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.comment))
                        .setTitleText("Comment on the Video")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Provide your views by commenting on the video")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.share))
                        .setTitleText("Share this video with your Friends")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Share this video with your friends.")
                        .setSkipText("Skip Tutorial")
                        .withCircleShape()
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_home))
                        .setTitleText("Home Feed")
                        .setDismissText("Click Here : Next")
                        .setContentText("See videos uploaded by users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_discover))
                        .setTitleText("Search for Questions")
                        .setDismissText("Click Here : Next")
                        //.setContentText("Search for questions asked by other users on Revidly")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_answer))
                        .setTitleText("Questions Tabs")
                        .setDismissText("Click Here : Next")
                        .setContentText("More Questions for you to browse")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.action_ask_ques))
                        .setTitleText("Want to ask a Question?")
                        .setDismissText("Click Here : Next")
                        .setContentText("Ask it from here")
                        .withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .build()
        );

        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Scroll Down")
                        .setDismissText("Click Here : Next")
                        .setContentText("Scroll down for more videos on questions")
                        //.withCircleShape()
                        .setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );
        sequence.addSequenceItem(
                new MaterialShowcaseView.Builder(this)
                        .setTarget(findViewById(R.id.hashtags))
                        .setTitleText("Swipe Right for list of videos")
                        .setDismissText("Click Here : End Tutorial & Swipe Right")
                        //.setContentText("Swipe right for list of videos for the same question")
                        //.withCircleShape()
                        //.setSkipText("Skip Tutorial")
                        .setMaskColour(Color.argb(240,255, 165, 80))
                        .withoutShape()
                        .build()
        );
        */
        /*
        sequence.start(); //start the sequence showcase
        Log.d("showtutor", "at end of ShowTutor Function");
    }
    */

    /* Remove comments to show Tutorial */


    @Override
    public void finish() {
        super.finish();
        //youTubePlayerView.release();
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
    }

    public static synchronized CommunityFeed getInstance() {
        return mInstance;
    }

    public void displayInternetDialogue(){
        try {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();

            alertDialog.setTitle("No Conncetion");
            alertDialog.setMessage("Internet not available, Cross check your internet connection and try again");
            alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Log.d("FullScreenActivity", "I am finishing");
                    finish();
                    //new FullscreenActivity().isOnline();
                }
            });

            alertDialog.show();
        } catch (Exception e) {
            Log.d(SyncStateContract.Constants._ID, "Show Dialog: " + e.getMessage());
            Crashlytics.logException(e);
        }
    }

    private void setProfilePic() {
        if (LoggedInUser.userProfileImage != "null" && !LoggedInUser.userProfileImage.isEmpty()) {
            Picasso.get()
                    .load(LoggedInUser.userProfileImage)
                    .into(profilePic);
            profilePic.setPadding(0, 0, 0, 0);
        }
    }

    public void checkPrivileges(){
        try{
            JSONArray jsonArray = LoggedInUser.topicAdmin;
            Log.d("LOG_DATA","jsonArray: "+ LoggedInUser.topicAdmin);
            JSONArray communityTopic = new JSONArray(communityTopics);
            String id = communityTopic.optJSONObject(0).optString("topicId");
            if(id.isEmpty()){
                id = communityTopic.optJSONObject(0).getString("_id");
            }
            for(int i = 0; i<jsonArray.length(); i++){
                if(jsonArray.optJSONObject(i).optString("topicId")
                        .equals(id)){
                    topicID=id;
                    isCurrentTopicAdmin=true;
                    viewAdminToolbar();
                }
            }
        } catch (Exception e) {
            Log.d("LOG_DATA",e.getMessage());
            e.printStackTrace();
        }
    }

    private void viewAdminToolbar(){
        Log.d("LOG_DATA","User is admin");
        constraintLayout = findViewById(R.id.admin_toolBar);
        pendingPost = findViewById(R.id.pending);
        blockedPost = findViewById(R.id.blocked);
        setting = findViewById(R.id.setting);
        pendingTitle = findViewById(R.id.pendingTitle);
        constraintLayout.setVisibility(View.VISIBLE);
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createCustomDialog();
            }
        });

        pendingPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pendingClicked=true;
                pendingTitle.setVisibility(View.VISIBLE);
                postFeed.getPendingPosts(topicID);
            }
        });
        blockedPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    private void createCustomDialog(){
        AlertDialog.Builder customAlert = new AlertDialog.Builder(CommunityFeed.this);
        View view = getLayoutInflater().inflate(R.layout.cummunity_admin_setting_layout,null);
        final Spinner ruleSpinner = view.findViewById(R.id.rule);
        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(),R.layout.support_simple_spinner_dropdown_item,
                rules);
        ruleSpinner.setAdapter(arrayAdapter);
        if(currentrule!=null && currentrule != ""){
            ruleSpinner.setSelection(Integer.parseInt(currentrule));
        }
        ruleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l){
                rule=ruleSpinner.getSelectedItem().toString();
                Log.d("LOG_DATA",rule+ " selected");

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        customAlert.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });

        customAlert.setView(view);
        final AlertDialog alertDialog = customAlert.create();
        alertDialog.show();
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(rule.equalsIgnoreCase("Select a Rule")){
                    Toast.makeText(getApplicationContext(), "Please select any one Rule", Toast.LENGTH_SHORT).show();
                } else {
                    updateRule();
                    alertDialog.dismiss();
                }

            }
        });
    }

    private void updateRule(){
        try{
            String ruleId="";
            if(rule.equalsIgnoreCase(rules[0])){
                ruleId="0";
            } else if (rule.equalsIgnoreCase(rules[1])) {
                ruleId="1";
            } else if (rule.equalsIgnoreCase(rules[2])) {
                ruleId="2";
            } else {
            }

            String url = BASE_URL+"/api/topic/changeRule";
            Log.d("LOG_DATA","Topic ID: "+topicID+"Rule Id: "+ ruleId);
            OkHttpClient client = new OkHttpClient().newBuilder()
                    .build();
            MediaType mediaType = MediaType.parse("application/json");
            RequestBody body = RequestBody.create(mediaType, "{\n\t\"topicId\":\""+topicID+"\",\n\t\"rule\":\""+ruleId+"\"\n}");
            final Request request = new Request.Builder()
                    .url(url)
                    .method("POST", body)
                    .addHeader("Authorization", Utils.getAuthToken(getApplicationContext()))
                    .addHeader("Content-Type", "application/json")
                    .build();
            Call call = client.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    Log.d("LOG_DATA","Inside updateRule-->"+e.getMessage());
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    try{
                        if(response.isSuccessful()){
                            String res = response.body().string();
                            Log.d("LOG_DATA","Community Rule Changed: "+res);
                            JSONObject jsonObject = new JSONObject(res);
                            Log.d("LOG_DATA","Community Rule Changed: "+jsonObject.toString());
                            response.body().close();
                        }
                    } catch (Exception e) {
                        Log.d("LOG_DATA","Inside updateRule-->"+e.getMessage());
                        e.printStackTrace();
                    }

                }
            });
        } catch (Exception e) {
            Log.d("LOG_DATA","Inside updateRule-->"+e.getMessage());
            e.printStackTrace();
        }
    }

    private void checkRuleForTopic(){
        String url = BASE_URL + "/api/topic";
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(url)
                .method("GET", null)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization",Utils.getAuthToken(getApplicationContext()))
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if(response.isSuccessful()) {
                    try {
                        String result = response.body().string();
                        JSONObject jsonObject = new JSONObject(result);
                        JSONArray data = jsonObject.optJSONArray("data");
                        currentrule = "";
                        for (int i = 0; i < data.length(); i++) {
                            JSONObject topic = data.getJSONObject(i);
                            if (topic.optString("_id").equalsIgnoreCase(topicID)) {
                                currentrule = topic.getString("allowPosts");
                                Log.d("LOG_DATA", "Current Rule: " + currentrule);
                            }
                        }
                        response.body().close();
                    } catch (Exception e) {
                        Log.e("LOG_DATA", e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        });
    }

//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//        if(home_flag) {
//            Intent intent = new Intent(CommunityFeed.this, HomeFeed.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//            startActivity(intent);
//        }
//    }
}

