package co.revidly.android;

import android.util.Log;

import com.crashlytics.android.Crashlytics;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JSONArrayTesting {
    //List<JSONObject> mlist;


    public void getHomeFeedList()
    {
        JSONObject PostObj = new JSONObject();
        ArrayList mediaList = new ArrayList();
        ///First Object
        try {
            // Here we convert Java Object to JSON

            //Assigning key -> value pairs to post
            PostObj.put("title", "optional");
            PostObj.put("description", "How to do this, how to do that, how to do anything"); // Set the first name/pair
            PostObj.put("lang", "English"); // Set the first name/pair

            //jsonObj.put("topic", "default");

            JSONArray media = new JSONArray();

            //Creating Media JSON Array of inidividual media assets
            for (int i=0; i<=5; i++)
            {
                JSONObject tempObj = new JSONObject();
                tempObj.put("loc", "https://homepages.cae.wisc.edu/~ece533/images/airplane.png");
                tempObj.put("kind", "image");
                media.put(tempObj);
            }
            //adding array to post
            PostObj.put("media",media);

            //Adding topic objects to topics array
            JSONArray topics = new JSONArray();

            //Adding topic 1
            JSONObject tempObj1 = new JSONObject();
            tempObj1.put("name", "politics");
            topics.put(tempObj1);
            //Adding topic 2
            JSONObject tempObj2 = new JSONObject();
            tempObj2.put("name", "Technology");
            topics.put(tempObj2);

            //adding aaray to post
            PostObj.put("topics", topics);

            Log.d("Post Object ------> ", "Post = " + PostObj.toString());

        }
        catch (Exception e)
        {
            e.printStackTrace();
            Crashlytics.logException(e);
        }
        //return mlist;
    }
}
