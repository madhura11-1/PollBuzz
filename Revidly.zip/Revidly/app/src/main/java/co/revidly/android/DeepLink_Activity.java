package co.revidly.android;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import co.revidly.android.ui.Utils;

public class DeepLink_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d("function call : ", "deep link=inside On Create");
        //Toast.makeText(this, "DeepLink : OnCreate ", Toast.LENGTH_SHORT).show();

        String ID = GetPostID(getIntent().getData());
       //Intent intent = new Intent()
       //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

       if (!TextUtils.isEmpty(ID)) {
           Utils.moveToHomeFeed(this,ID);
       }else {
           Utils.moveToHomeFeed(this,null);
       }
       finish();
    }
    /*
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d("DeepLink : ", "inside onNewIntent");
        Toast.makeText(this, "DeepLink : onNewIntent ", Toast.LENGTH_SHORT).show();

    }
     */
    private String GetPostID(Uri data) {
        if (data != null && data.isHierarchical()) {
            String url = data.toString();
            Log.d("DeepLink" , "url is = " + url);
            int lastindex = url.lastIndexOf("/");
            String postId = url.substring(lastindex+1, url.length());
            Log.d("DeepLink", "postId is = " + postId);
            return postId;
            //return data.getQueryParameter("aid");
        }
        return null;
    }
}
