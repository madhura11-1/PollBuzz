package co.revidly.android;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.crashlytics.android.Crashlytics;
import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import co.revidly.android.helpers.LoggedInUser;
import co.revidly.android.ui.HomeScreen_Activity;
import co.revidly.android.ui.SplashScreenActivity;
import co.revidly.android.ui.Utils;
import io.fabric.sdk.android.services.common.Crash;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static co.revidly.android.helpers.Config.BASE_HOST;
import static co.revidly.android.helpers.Config.BASE_URL;

public class UserDetails {

ProgressDialog progressDialog;
Context mContext;
String auth_token;
JSONArray topics;
public static boolean userDetailsExecuted = false;

    public UserDetails(Context mContext, String auth_token, boolean userDetailsExecuted)
    {
        this.mContext = mContext;
        this.auth_token = auth_token;
        this.userDetailsExecuted = userDetailsExecuted;
    }


    public void getUserDetails() {
        OkHttpClient client = new OkHttpClient();

        if(mContext instanceof HomeFeed) {
            Handler mainHandler;
            mainHandler = new Handler(mContext.getMainLooper());
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    progressDialog = ProgressDialog.show(mContext,
                            "Loading..",
                            "We are just getting started.\n Please Wait...");
                }
            });
        }


        Request request = new Request.Builder()
                .url(BASE_URL+"/api/user/me")
                .get()
                .addHeader("Authorization", auth_token)
                .addHeader("Host", BASE_HOST)
                .addHeader("Connection", "keep-alive")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                                /*getActivity().runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(getContext(),"Network Error",Toast.LENGTH_SHORT).show();
                                                    }
                                                });*/
                Handler mainHandler;
                mainHandler = new Handler(mContext.getMainLooper());
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {

                        //mShimmerFrameLayout.stopShimmer();
                        //mShimmerFrameLayout.setVisibility(View.GONE);
                        try {
                            if (progressDialog != null && progressDialog.isShowing())
                                progressDialog.dismiss();

                            final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                            builder.setTitle("Something\'s Wrong");
                            builder.setMessage("Something does not seem to be right. If the problem continues, close the app and start it again.");
                            builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //Click button action
                                    getUserDetails();
                                    dialog.dismiss();

                                }
                            });
                            builder.setCancelable(false);
                            builder.show();

                        } catch (Exception e) {
                            e.printStackTrace();
                            Crashlytics.log(e.toString());
                        }
                    }
                });
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ",response.toString());
                                                    /*getActivity().runOnUiThread(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                        }
                                                    });*/
                    if(response.message().equalsIgnoreCase("Forbidden"))
                    {
                        logout();
                    }
                    else
                    {
                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                                //mShimmerFrameLayout.stopShimmer();
                                //mShimmerFrameLayout.setVisibility(View.GONE);
                                try {
                                    if (progressDialog != null && progressDialog.isShowing())
                                        progressDialog.dismiss();

                                    final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                                    builder.setTitle("Something\'s Wrong");
                                    builder.setMessage("Close the app and start it again.");
                                    builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            //Click button action
                                            getUserDetails();
                                            dialog.dismiss();

                                        }
                                    });
                                    builder.setCancelable(false);
                                    builder.show();

                                } catch (Exception e) {
                                    e.printStackTrace();
                                    Crashlytics.log(e.toString());
                                }
                            }
                        });

                        //Crashlytics.log(response.toString());
                        throw new IOException("Unexpected code " + response);
                    }

                } else {
                    final String resp = response.body().string();
                    //mlist.clear();
                    try {
                        JSONObject resultObject = new JSONObject(resp);
                        Log.d("HF getUserDetails --> ", resultObject.toString());
                        JSONObject result = resultObject.getJSONObject("data");
                        JSONObject metaData = resultObject.getJSONObject("metaData");

                        //for (int i = 0; i < result.length(); i++)
                        //{
                        //final JSONObject obj = result.getJSONObject(i);
                        //mlist.add(obj);
                        LoggedInUser.userName = result.optString("name");
                        LoggedInUser.userId = result.optString("_id");
                        Log.d("LOG_MSG","revidly-user-"+LoggedInUser.userId);
                        FirebaseMessaging.getInstance().subscribeToTopic("revidly-user-"+LoggedInUser.userId);

                        if(result.has("avatar"))
                            LoggedInUser.userProfileImage = result.optString("avatar");
                        else
                            LoggedInUser.userProfileImage = "";

                        LoggedInUser.userTopics = result.optJSONArray("topics");
                        Log.d("UserTopics",LoggedInUser.userTopics.toString());
                        topics = result.optJSONArray("topics");
                        Log.d("LOG_DATA","notification-follow_recieved-"+LoggedInUser.userId);
//                        FirebaseMessaging.getInstance().subscribeToTopic("notification-follow_recieved-"+LoggedInUser.userId);
                        AsyncTask.execute(new Runnable() {
                            @Override
                            public void run(){
                                Log.d("getUserDetails Aysnc()", "running");
                                subscribeToClans();
                                subscribeToUsersIAmFollowing();
                            }

                        });
                        LoggedInUser.followers = result.optInt("followers");
                        LoggedInUser.following = result.optInt("following");
                        LoggedInUser.totalUpvotes = metaData.getInt("upvotes");
                        LoggedInUser.auth_token_global = auth_token;
                        //LoggedInUser.totalUpvotes = result.optInt("upvotes");
                        Log.d("HomeFeed->UserDetails", "After adding object to obj");
                        Log.d("HomeFeed->UserDetails", "LoggedIn User profile pic = " + LoggedInUser.userProfileImage);

                        Log.d("User Name : ", LoggedInUser.userName);
                        Log.d("User ID: ", LoggedInUser.userId);
                        Log.d("User Topics : ", "" + LoggedInUser.userTopics);
                        Log.d("User Profile Image : ", LoggedInUser.userProfileImage);
                        LoggedInUser.topicAdmin = result.optJSONArray("topicAdmin");
                        Log.d("LOG_DATA","TopicAdmin: "+ LoggedInUser.topicAdmin);
                        LoggedInUser.auth_token_global = auth_token;
                        Log.d("LOG_DATA","topicAdminSize: " +LoggedInUser.topicAdmin.length());
                        if(LoggedInUser.topicAdmin.length()!=0){
                            LoggedInUser.isTopicAdmin = true;
                        }
                        else{
                            LoggedInUser.isTopicAdmin = false;
                        }
                        Log.d("LOG_DATA","Is Topic Admin?: "+ LoggedInUser.isTopicAdmin);


                        //}
                        //clanSelector.setAllTopics(mlist);

                        Handler mainHandler;
                        mainHandler = new Handler(mContext.getMainLooper());
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {

                                //mShimmerFrameLayout.stopShimmer();
                                //mShimmerFrameLayout.setVisibility(View.GONE);
                                //progressDialog.dismiss();
                                //adapter.notifyDataSetChanged();
                                if(mContext instanceof HomeFeed) {
                                    if (progressDialog != null && progressDialog.isShowing())
                                        progressDialog.dismiss();
                                }
                                if(mContext instanceof HomeFeed)
                                {
                                    if (LoggedInUser.userTopics.length() == 0) {
                                        ((HomeFeed) mContext).getInstance().setUserTopics();
                                        ((HomeFeed) mContext).getInstance().setProfilePic();
                                    }
                                    else{
                                        ((HomeFeed) mContext).getInstance().setHomeFeed();
                                        ((HomeFeed) mContext).getInstance().setProfilePic();
//                                        Intent intent=new Intent(mContext,newHomeFeed.class);
                                        Log.d("NewHomeFeed","UserDetails1st");
//                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
//                                        mContext.startActivity(intent);
                                    }
                                }
                                else if(mContext instanceof SplashScreenActivity)
                                {
                                    Intent i = new Intent(mContext, HomeFeed.class);
                                    Log.d("NewHomeFeed","UserDetails2nd");
                                    i.putExtra("newHomeFeed",true);
                                    ((SplashScreenActivity) mContext).startActivity(i);
                                    ((SplashScreenActivity) mContext).overridePendingTransition(R.anim.slide_out_left, R.anim.slide_in_right);
                                    ((SplashScreenActivity) mContext).finish();
                                }


                            }
                        });
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Crashlytics.logException(e);
                    }
                    Log.i("Response:", response.toString());
                    Log.i("Response body:", response.body().toString());
                    Log.i("Response String: ", resp);
                    Log.i("Response message:", response.message());
                    response.body().close();
                }
            }
        });
    }
    private void subscribeToClans(){
        try{
            if(topics.length()!=0){
                for(int i=0;i<topics.length();i++){
                    JSONObject data = topics.getJSONObject(i);
                    Log.d("SubscribeToClans()","data object = " + data.toString());
                    Log.d("LOG_DATA","Topic ID: "+data.getString("topicId"));
//                    FirebaseMessaging.getInstance().subscribeToTopic("notification-post_trending-"+data.getString("topicId"));
                    Log.d("SubscribeToClans()","notification-post_trending-"+data.getString("topicId"));
                }
            }
        }
        catch (Exception e){
            Log.e("LOG_DATA",e.getMessage());
        }
    }
    private void subscribeToUsersIAmFollowing()
    {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url(BASE_URL+"/api/follow/followedBy?userId="+LoggedInUser.userId)
                .method("GET", null)
                .addHeader("Authorization", auth_token)
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {

            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    // You can also throw your own custom exception
                    Log.i("Response ", response.toString());
                                                 /*getActivity().runOnUiThread(new Runnable() {
                                                     @Override
                                                     public void run() {
                                                         Toast.makeText(getContext(),"Unsuccesful in posting question",Toast.LENGTH_SHORT).show();
                                                     }
                                                 });*/
                    throw new IOException("Unexpected code " + response);
                } else {
                    final String resp = response.body().string();
                    //mlist.clear();
                    try {
                        JSONObject resultObject = new JSONObject(resp);

                        Log.d("LOG_DATA", "Result: " + resultObject.toString());
                        JSONArray jsonArray = resultObject.getJSONArray("data");
                        Log.d("LOG_DATA", "SIZE: " + jsonArray.length());
                        if (jsonArray.length() != 0){
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject data = new JSONObject(String.valueOf(jsonArray.getJSONObject(i)));
                                Log.d("LOG_DATA", "ID: " + data.getString("subject"));
                                Log.d("LOG_DATA", "notification-user_following-" + data.getString("subject"));
//                                FirebaseMessaging.getInstance().subscribeToTopic("notification-user_following-" + data.getString("subject"));
                            }
                        }
                        response.body().close();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.e("LOG_DATA",e.getMessage());
                    }
                }
            }
        });


    }
    private void logout(){
        Utils.removeLoginAuthToken(mContext);
        mContext.startActivity(new Intent(mContext, SplashScreenActivity.class));
        Log.d("UserDetails", "logout Called");
        AccessToken fbAccessToken = AccessToken.getCurrentAccessToken();
        if(fbAccessToken != null){
            Log.d("LOG_DATA", "Logged out");
            LoginManager.getInstance().logOut();
        }
    }

}
